package me.bebeli555.cookieclient.events.block;

public class GetBlockReachDistanceEvent {
	public float reach;
}
