package me.bebeli555.cookieclient.events.bus;

/**
 * The state of an event
 *
 * @author Brady
 * @since 2/10/2017 12:00 PM
 */
public enum EventState {

    PRE, POST
}
