package me.bebeli555.cookieclient.events.player;

import me.bebeli555.cookieclient.events.bus.Cancellable;

public class PlayerUpdateMoveStatePostEvent extends Cancellable {

}
