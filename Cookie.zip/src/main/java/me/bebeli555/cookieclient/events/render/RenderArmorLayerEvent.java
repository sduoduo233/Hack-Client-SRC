package me.bebeli555.cookieclient.events.render;

import me.bebeli555.cookieclient.events.bus.Cancellable;

public class RenderArmorLayerEvent extends Cancellable {

}
