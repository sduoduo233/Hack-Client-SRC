package me.rigamortis.faurax.module;

public enum ModuleType
{
    COMBAT, 
    WORLD, 
    RENDER, 
    PLAYER, 
    MOVEMENT, 
    MISC, 
    UI;
}
