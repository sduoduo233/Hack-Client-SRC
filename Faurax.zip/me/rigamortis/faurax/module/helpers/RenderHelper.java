package me.rigamortis.faurax.module.helpers;

import me.rigamortis.faurax.utils.*;

public interface RenderHelper
{
    public static final GuiUtils guiUtils = new GuiUtils();
}
