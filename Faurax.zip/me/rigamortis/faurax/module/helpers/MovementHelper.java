package me.rigamortis.faurax.module.helpers;

import me.rigamortis.faurax.utils.*;

public interface MovementHelper
{
    public static final MovementUtils movementUtils = new MovementUtils();
}
