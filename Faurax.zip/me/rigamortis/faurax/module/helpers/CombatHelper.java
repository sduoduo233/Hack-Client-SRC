package me.rigamortis.faurax.module.helpers;

public interface CombatHelper
{
}
