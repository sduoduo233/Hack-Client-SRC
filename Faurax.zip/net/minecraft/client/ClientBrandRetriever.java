package net.minecraft.client;

public class ClientBrandRetriever
{
    private static final String __OBFID = "CL_00001460";

    public static String getClientModName()
    {
        return "vanilla";
    }
}
