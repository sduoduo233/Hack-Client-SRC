/*
 * Decompiled with CFR 0.150.
 */
package delta.utils;

public class Infos {
    public static final String breath$ = "Delta";
    public static final String lives$ = "b3.7";
    public static final String eight$ = "3.7";
    public static final String reveal$ = "RELEASE";
    public static final String arrested$ = "xTrM_";
}

