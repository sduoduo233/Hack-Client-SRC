/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  me.xtrm.delta.api.module.Category
 *  me.xtrm.delta.api.module.Module
 */
package delta;

import me.xtrm.delta.api.module.Category;
import me.xtrm.delta.api.module.Module;

public class Class205
extends Module {
    public Class205() {
        super("Triggerbot", Category.Combat);
    }
}

