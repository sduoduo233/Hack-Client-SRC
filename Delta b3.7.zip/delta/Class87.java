/*
 * Decompiled with CFR 0.150.
 */
package delta;

import delta.Class3;
import delta.Class6;

public class Class87<T extends Number>
extends Class3<Number> {
    public Class6<T> _refund() {
        return new Class6(this._poster(), this._aspects(), this._nervous());
    }

    public Class87(T t, T t2) {
        super(t, t2, 202 - 253 + 91 - 82 + 42);
    }
}

