/*
 * Decompiled with CFR 0.150.
 */
package delta;

public interface Class80 {
    public static final boolean shoes$;

    public void _courts(int var1, int var2);

    public void _drugs();
}

