/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.ScaledResolution
 */
package delta;

import delta.utils.Wrapper;
import net.minecraft.client.gui.ScaledResolution;

public class Class22 {
    public static ScaledResolution _remedy() {
        return new ScaledResolution(Wrapper.mc, Wrapper.mc.displayWidth, Wrapper.mc.displayHeight);
    }
}

