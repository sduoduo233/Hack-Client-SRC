package cedo.events;

public enum EventDirection {
    INCOMING,
    OUTGOING
}
