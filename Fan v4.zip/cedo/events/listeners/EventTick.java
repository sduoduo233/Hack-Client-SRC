package cedo.events.listeners;

import cedo.events.Event;

public class EventTick extends Event<EventTick> {
}
