package cedo.events.listeners;

import cedo.events.Event;

public class EventDoRender extends Event<EventDoRender> {
}
