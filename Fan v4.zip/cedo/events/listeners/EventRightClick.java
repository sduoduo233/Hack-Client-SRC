package cedo.events.listeners;

import cedo.events.Event;

public class EventRightClick extends Event<EventRightClick> {


}
