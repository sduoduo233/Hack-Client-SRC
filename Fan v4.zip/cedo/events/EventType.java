package cedo.events;

public enum EventType {
    PRE,
    POST
}
