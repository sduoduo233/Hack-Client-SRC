package cedo.ui.notifications;

public enum NotificationType {
    SUCCESS,
    DISABLE,
    INFO,
    WARNING
}
