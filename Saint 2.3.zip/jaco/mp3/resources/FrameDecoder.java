package jaco.mp3.resources;

public interface FrameDecoder {
   void decodeFrame() throws DecoderException;
}
