package jaco.mp3.resources;

public interface JavaLayerErrors {
   int BITSTREAM_ERROR = 256;
   int DECODER_ERROR = 512;
}
