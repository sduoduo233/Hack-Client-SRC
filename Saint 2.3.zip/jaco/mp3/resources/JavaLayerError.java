package jaco.mp3.resources;

public class JavaLayerError extends Error {
}
