package javassist.util;

class Trigger {
   void doSwap() {
   }
}
