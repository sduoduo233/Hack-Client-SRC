package cheatware.event.events;

import cheatware.event.Event;

public class EventPostMotionUpdate extends Event {}
