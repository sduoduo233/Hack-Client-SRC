package cheatware.event.events;

import cheatware.event.Event;

public class EventUpdate extends Event {}
