package com.ihl.client.event;

public class EventPlayerMotion extends Event {

    public EventPlayerMotion(Type type) {
        super(type);
    }

}
