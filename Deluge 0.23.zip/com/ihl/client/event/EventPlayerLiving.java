package com.ihl.client.event;

public class EventPlayerLiving extends Event {

    public EventPlayerLiving(Type type) {
        super(type);
    }

}
