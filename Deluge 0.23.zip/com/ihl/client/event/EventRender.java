package com.ihl.client.event;

public class EventRender extends Event {

    public EventRender(Type type) {
        super(type);
    }

}
