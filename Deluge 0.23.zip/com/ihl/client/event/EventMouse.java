package com.ihl.client.event;

public class EventMouse extends Event {

    public EventMouse(Type type) {
        super(type);
    }

}
