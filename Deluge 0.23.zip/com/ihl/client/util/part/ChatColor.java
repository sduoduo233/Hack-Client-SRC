package com.ihl.client.util.part;

public class ChatColor {

    public String color;
    public String regex;

    public ChatColor(String color, String regex) {
        this.color = color;
        this.regex = regex;
    }

}
