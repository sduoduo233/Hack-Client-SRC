package com.ihl.client.commands.exceptions;

public class ArgumentException extends CommandException {

}
