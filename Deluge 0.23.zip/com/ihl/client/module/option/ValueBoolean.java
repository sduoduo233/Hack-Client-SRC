package com.ihl.client.module.option;

public class ValueBoolean extends Value {

    public ValueBoolean(boolean value) {
        super(value);
    }

}
