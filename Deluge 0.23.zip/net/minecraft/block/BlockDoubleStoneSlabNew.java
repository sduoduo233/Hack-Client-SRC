package net.minecraft.block;

public class BlockDoubleStoneSlabNew extends BlockStoneSlabNew
{
    private static final String __OBFID = "CL_00002114";

    public boolean isDouble()
    {
        return true;
    }
}
