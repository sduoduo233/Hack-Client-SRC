package net.minecraft.client.gui.spectator;

import net.minecraft.util.IChatComponent;

public interface ISpectatorMenuObject
{
    void func_178661_a(SpectatorMenu var1);

    IChatComponent func_178664_z_();

    void func_178663_a(float var1, int var2);

    boolean func_178662_A_();
}
