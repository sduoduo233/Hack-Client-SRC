package com.gamesense.client.module.modules.misc;

import com.gamesense.client.module.Category;
import com.gamesense.client.module.Module;

@Module.Declaration(name = "MultiTask", category = Category.Misc)
public class MultiTask extends Module {

}