package com.gamesense.api.event.events;

import com.gamesense.api.event.GameSenseEvent;

public class EntityCollisionEvent extends GameSenseEvent {

}