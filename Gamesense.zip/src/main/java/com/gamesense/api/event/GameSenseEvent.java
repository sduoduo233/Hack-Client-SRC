package com.gamesense.api.event;

import me.zero.alpine.type.Cancellable;

public class GameSenseEvent extends Cancellable {

}