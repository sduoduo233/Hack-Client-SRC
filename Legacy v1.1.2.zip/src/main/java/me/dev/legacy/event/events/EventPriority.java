package me.dev.legacy.event.events;

public enum EventPriority {
    HIGH,
    NONE,
    LOW
}
