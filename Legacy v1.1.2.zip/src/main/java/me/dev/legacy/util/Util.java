package me.dev.legacy.util;

import net.minecraft.client.Minecraft;

public interface Util {
    Minecraft mc = Minecraft.getMinecraft();
}

