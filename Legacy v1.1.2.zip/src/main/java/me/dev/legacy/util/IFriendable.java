package me.dev.legacy.util;

public interface IFriendable {
    String getAlias();
    void setAlias(String alias);
}
