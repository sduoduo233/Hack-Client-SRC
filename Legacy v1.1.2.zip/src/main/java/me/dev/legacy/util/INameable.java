package me.dev.legacy.util;

public interface INameable {

    String getName();
    String getDisplayName();
    void setName(String name);
    void setDisplayName(String displayName);

}
