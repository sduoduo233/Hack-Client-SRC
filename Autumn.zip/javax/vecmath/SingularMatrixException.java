package javax.vecmath;

public class SingularMatrixException extends RuntimeException {
   public SingularMatrixException() {
   }

   public SingularMatrixException(String var1) {
      super(var1);
   }
}
