package net.minecraft.block;

public class BlockHalfStoneSlab extends BlockStoneSlab {
   public boolean isDouble() {
      return false;
   }
}
