import java.awt.Color;
import org.lwjgl.input.Keyboard;

public class Kasee extends Fanny {
   private Ellena creator$;

   public Kasee() {
      super("InvWalk", (new Color(193, 113, 0)).getRGB(), Ayonna.lyrics$, "Walk and look around in UI's\nUse arrow keys to look around\nDoes not bypass some anti-cheats!");
      taking.creator$ = Ellena._designs(taking, "Sneak", true, "Takes sneaking input");
      taking._actions(new Albert[]{taking.creator$});
   }

   public boolean _industry() {
      return true;
   }

   public void _retailer(Chikita deaths) {
      if (deaths._adaptor()) {
         Object textile = Alondra._inserted();
         if (Alondra._position()._trustees() && !Alondra._position()._gotta(Akeia.carmen$)) {
            if (Keyboard.isKeyDown(200) && textile._glasses() - 3.0F > -90.0F) {
               textile._thick(textile._glasses() - 3.0F);
            }

            if (Keyboard.isKeyDown(208) && textile._glasses() + 3.0F < 90.0F) {
               textile._thick(textile._glasses() + 3.0F);
            }

            if (Keyboard.isKeyDown(203)) {
               textile._exciting(textile._armed() - 5.0F);
            }

            if (Keyboard.isKeyDown(205)) {
               textile._exciting(textile._armed() + 5.0F);
            }
         }
      }

   }

   private void _scenes(Micholas therapy) {
      if (Keyboard.isKeyDown(therapy._performs())) {
         Micholas._lingerie(therapy._performs(), true);
         Micholas._trace(therapy._performs());
      } else if (therapy._autos()) {
         Micholas._lingerie(therapy._performs(), false);
         Micholas._trace(therapy._performs());
      }

   }

   public void _realtor(Thorn yomipunu) {
      if (yomipunu._should()._gotta(Akeia.yearly$) && Alondra._position()._trustees() && !Alondra._position()._gotta(Akeia.carmen$)) {
         Object edarorep = Alondra._surfaces();
         zifalulu._scenes(edarorep._emission());
         zifalulu._scenes(edarorep._swingers());
         zifalulu._scenes(edarorep._stars());
         zifalulu._scenes(edarorep._interval());
         zifalulu._scenes(edarorep._valued());
         if (zifalulu.creator$._sounds().booleanValue()) {
            zifalulu._scenes(edarorep._guilty());
         }
      }

   }
}
