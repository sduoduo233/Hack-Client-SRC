import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Shehzad extends Matthieu {
   private final Map vedogeyu$ = new HashMap();
   private Trinette[] vilocodo$;
   private Trinette lotetuva$;
   private Trinette tefububa$;
   private Trinette epufotec$;
   private Trinette bomicero$;
   private Verne togepogu$ = new Verne();
   private Ashley gometemi$;
   private Ellena avigonob$;
   private Ellena cugecevu$;
   private Ellena sufutazo$;
   private Ellena azafulib$;
   private Tashenna mifagegi$;
   private Tashenna ulododid$;

   public Shehzad() {
      super("InvCleaner", "Cleans blacklisted items from your inventory.\nDoes not throw out whitelisted items.");
      gaming.gometemi$ = Ashley._laptop(gaming, "Delay", "#", "", 1.0D, 60.0D, 80.0D, 200.0D);
      gaming.avigonob$ = Ellena._designs(gaming, "Best Items", true, "Keeps the best set of armor, sword, axe, pickaxe and bow");
      gaming.cugecevu$ = Ellena._designs(gaming, "Remove Negative Potions", true, "Will always throw out negative potions");
      gaming.sufutazo$ = Ellena._designs(gaming, "Remove Food", true, "Remove Food except for Golden Apples");
      gaming.azafulib$ = Ellena._designs(gaming, "Open Inventory", true, "Opens your inventory when cleaning.");
      gaming.mifagegi$ = Tashenna._figures(gaming, "invcleaner-whitelisted", "Whitelisted", Tashenna.nifurine$, 1, Collections.emptyList());
      gaming.ulododid$ = Tashenna._mother(gaming, "invcleaner-blacklisted", "Blacklisted", Tashenna.botizide$, Collections.emptyList());
      gaming._actions(new Albert[]{gaming.gometemi$, gaming.azafulib$, gaming.avigonob$, gaming.cugecevu$, gaming.sufutazo$, gaming.mifagegi$, gaming.ulododid$});
   }

   public void _senator() {
      super._senator();
      andreas.mifagegi$._danger("344", 1);
      andreas.mifagegi$._danger("384", 1);
      andreas.mifagegi$._danger("332", 1);
      andreas.mifagegi$._danger("346", 1);
      andreas.mifagegi$._danger("368", 1);
      andreas.ulododid$._danger("280", -1);
      andreas.ulododid$._danger("287", -1);
      andreas.ulododid$._danger("318", -1);
      andreas.ulododid$._danger("345", -1);
      andreas.ulododid$._danger("288", -1);
      andreas.ulododid$._danger("374", -1);
      andreas.ulododid$._danger("116", -1);
      andreas.ulododid$._danger("54", -1);
      andreas.ulododid$._danger("145", -1);
   }

   public void _ghana() {
      livalago.vedogeyu$.clear();
   }

   public void _strings(Neill zudizofa) {
      Object fipofayu = Alondra._inserted();
      if (!Alondra._position()._gotta(Akeia.hotel$) && vosidive.azafulib$._sounds().booleanValue()) {
         Object yamalemu = Alondra._surfaces()._genres()._performs();
         Micholas._lingerie(yamalemu, true);
         Micholas._trace(yamalemu);
         Micholas._lingerie(yamalemu, false);
      } else {
         if (vosidive.togepogu$._basename((long)vosidive.gometemi$._kinds())) {
            vosidive.vedogeyu$.clear();
            vosidive.vilocodo$ = vosidive._modules();
            vosidive.lotetuva$ = vosidive._patches(Akeia.berkeley$, new Reiko(vosidive));
            vosidive.tefububa$ = vosidive._patches(Akeia.bases$, new Shermaine(vosidive));
            vosidive.bomicero$ = vosidive._patches(Akeia.bases$, new Krystelle(vosidive));
            vosidive.epufotec$ = vosidive._patches(Akeia.newport$, new Nykia(vosidive));
            Object yamalemu = false;
            if (fipofayu._discs()._warner()) {
               return;
            }

            Iterator tevudoyu = fipofayu._discs()._eastern().iterator();

            label119:
            while(tevudoyu.hasNext()) {
               Cari potemano = (Cari)tevudoyu.next();

               try {
                  if (potemano._ports() && !potemano._monthly()._warner()) {
                     Object ezatesec = fipofayu._ordering()._salary();
                     Object mufoleri = ezatesec.length;

                     for(int latizuvo = 0; latizuvo < mufoleri; ++latizuvo) {
                        Object getiyaga = ezatesec[latizuvo];
                        if (getiyaga != null && getiyaga.equals(potemano._monthly())) {
                           continue label119;
                        }
                     }

                     Object ezatesec = potemano._monthly()._educated();
                     mufoleri = Gianfranco._laser(ezatesec);
                     Object latizuvo = vosidive.mifagegi$._gratuit(potemano._monthly()._educated()._factors() + "");
                     if (latizuvo == null) {
                        latizuvo = vosidive.mifagegi$._gratuit(potemano._monthly()._educated()._remix(potemano._monthly()));
                     }

                     if (latizuvo != null && latizuvo._hybrid()) {
                        Object getiyaga = (Set)vosidive.vedogeyu$.get(mufoleri);
                        if (getiyaga == null) {
                           Object getiyaga = new HashSet();
                           getiyaga.add(potemano._stopped());
                           vosidive.vedogeyu$.put(mufoleri, getiyaga);
                           continue;
                        }

                        getiyaga.add(potemano._stopped());
                        if (potemano._monthly().equals(fipofayu._remains())) {
                           continue;
                        }

                        if (getiyaga.size() > latizuvo._album()) {
                           Iterator yidosine = getiyaga.iterator();

                           label101:
                           while(true) {
                              Integer beficoli;
                              do {
                                 do {
                                    if (!yidosine.hasNext()) {
                                       break label101;
                                    }

                                    beficoli = (Integer)yidosine.next();
                                 } while(beficoli.intValue() == potemano._stopped());
                              } while(getiyaga.size() <= latizuvo._album());

                              Trinette var12 = fipofayu._discs()._compact(beficoli.intValue())._monthly();
                              if (!var12.equals(fipofayu._remains()) && vosidive._reform(potemano._monthly()) >= vosidive._reform(var12)) {
                                 vosidive._price(beficoli.intValue());
                              } else {
                                 vosidive._price(potemano._stopped());
                              }

                              yamalemu = true;
                           }
                        }
                     }

                     if (vosidive._invite(potemano._monthly())) {
                        vosidive._price(potemano._stopped());
                        yamalemu = true;
                        break;
                     }
                  }
               } catch (Exception var13) {
                  ;
               }
            }

            vosidive._symphony(false);
            if (vosidive.azafulib$._sounds().booleanValue()) {
               fipofayu._lighting();
            }

            if (fipofayu._worker()._doors() && Alondra._position()._gotta(Akeia.hotel$)) {
               vosidive._symphony(false);
            }

            vosidive.togepogu$._cards();
         }

      }
   }

   private void _price(int dezenonu) {
      Object bitovipi = Alondra._inserted();
      Alondra._emacs()._worst(bitovipi._discs()._spoken(), dezenonu, 0, 0, bitovipi);
      Alondra._emacs()._worst(bitovipi._discs()._spoken(), -999, 0, 0, bitovipi);
   }

   private boolean _invite(Trinette izizitim) {
      Object erupocem = izizitim._educated();
      if (erupocem._gotta(Akeia.tattoo$)) {
         Object direnase = new Kieran(erupocem);
         if (vegaduze.vilocodo$[direnase._uniform()] != null && !vegaduze.vilocodo$[direnase._uniform()].equals(izizitim)) {
            return true;
         }
      }

      Object direnase = true;
      if (vegaduze.avigonob$._sounds().booleanValue()) {
         boolean var10000;
         if ((!erupocem._gotta(Akeia.holly$) || vegaduze.bomicero$.equals(izizitim)) && (!erupocem._gotta(Akeia.bases$) || vegaduze.tefububa$.equals(izizitim)) && (!erupocem._gotta(Akeia.berkeley$) || vegaduze.lotetuva$.equals(izizitim)) && (!erupocem._gotta(Akeia.newport$) || vegaduze.epufotec$.equals(izizitim))) {
            var10000 = false;
         } else {
            var10000 = true;
         }
      }

      if (!vegaduze.ulododid$._please(izizitim)) {
         ;
      }

      return true;
   }

   private Trinette _patches(Class firewall, Comparator wages) {
      Object streets = new ArrayList();
      Iterator sandra = Alondra._inserted()._discs()._eastern().iterator();

      while(sandra.hasNext()) {
         Object springs = (Cari)sandra.next();
         if (springs._ports() && springs._monthly()._trustees() && springs._monthly()._educated()._gotta(firewall)) {
            streets.add(springs._monthly());
         }
      }

      streets.sort(wages);
      Collections.reverse(streets);
      if (streets.isEmpty()) {
         return null;
      } else {
         return (Trinette)streets.get(0);
      }
   }

   private Trinette[] _modules() {
      Object islam = new Trinette[4];
      Object profiles = new ArrayList();
      Object boating = Alondra._inserted()._discs()._eastern();
      Iterator pressure = boating.iterator();

      while(pressure.hasNext()) {
         Object solution = (Cari)pressure.next();
         if (solution._ports() && solution._monthly()._educated()._gotta(Akeia.tattoo$)) {
            profiles.add(solution._monthly());
         }
      }

      pressure = profiles.iterator();

      while(true) {
         Kieran explicit;
         Trinette resorts;
         Trinette solution;
         do {
            if (!pressure.hasNext()) {
               return islam;
            }

            solution = (Trinette)pressure.next();
            explicit = new Kieran(solution._educated());
            resorts = islam[explicit._uniform()];
         } while(resorts != null && desert._physical(solution) <= desert._physical(resorts));

         islam[explicit._uniform()] = solution;
      }
   }

   private double _physical(Trinette dalozeya) {
      Object ayonevem = 0;
      if (dalozeya._educated()._gotta(Akeia.tattoo$)) {
         Object sutelazu = new Kieran(dalozeya._educated());
         ayonevem = sutelazu._reported();
      }

      ayonevem += Dayana._means(new Trinette[]{dalozeya}, Verna._plasma(Alondra._inserted()));
      return (double)ayonevem;
   }

   private boolean _replica(Trinette securely) {
      if (!securely._educated()._gotta(Akeia.width$)) {
         return false;
      } else {
         Object faced = new Hakim(securely._educated());
         Object postcard = faced._flyer(securely);
         Iterator pointed = postcard.iterator();

         Terresa manitoba;
         do {
            if (!pointed.hasNext()) {
               return false;
            }

            Object worldcat = (Amilcar)pointed.next();
            manitoba = Terresa._belfast(worldcat._trends());
         } while(!manitoba._taken());

         return true;
      }
   }

   private double _reform(Trinette yupirigo) {
      Object vavorege = labolaca._physical(yupirigo);
      vavorege += (double)Dayana._seller(32, yupirigo);
      vavorege += (double)Dayana._seller(16, yupirigo);
      vavorege += (double)Dayana._seller(19, yupirigo);
      vavorege += (double)Dayana._seller(20, yupirigo);
      vavorege += (double)Dayana._seller(48, yupirigo);
      vavorege += (double)Dayana._seller(34, yupirigo);
      return vavorege;
   }

   public Tashenna _jordan() {
      return epobipap.mifagegi$;
   }

   public Tashenna _scroll() {
      return retain.ulododid$;
   }

   public void _handy(JsonObject ezonubov) {
      super._handy(ezonubov);
      JsonArray bezonume;
      JsonObject sinedolo;
      if (ezonubov.get("whitelisted-items") != null) {
         bezonume = ezonubov.get("whitelisted-items").getAsJsonArray();
         sinedolo = new JsonObject();
         sinedolo.addProperty("id", nirofoli.mifagegi$._shower());
         sinedolo.add("value", bezonume);
         nirofoli.mifagegi$._radar(sinedolo);
      }

      if (ezonubov.get("blacklisted-items") != null) {
         bezonume = ezonubov.get("blacklisted-items").getAsJsonArray();
         sinedolo = new JsonObject();
         sinedolo.addProperty("id", nirofoli.ulododid$._shower());
         sinedolo.add("value", bezonume);
         nirofoli.ulododid$._radar(sinedolo);
      }

   }
}
