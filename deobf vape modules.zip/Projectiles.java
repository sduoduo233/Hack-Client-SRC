import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.lwjgl.opengl.GL11;

public class Byanca extends Fanny {
   private Raya powered$ = new Raya();
   private Loran measured$ = new Loran();
   private Ustin broken$;
   private Ustin launched$;
   private Ustin seeds$;
   private Deepak phases$;
   private Ellena wheel$;
   private Ellena paxil$;
   private Ellena digit$;
   private Ellena humans$;
   private Ellena fully$;

   public Byanca() {
      super("Projectiles", -16535661, Ayonna.weather$, "Shows projectile trajectories while in air");
      avenue.broken$ = new Ustin(Collections.singleton(Akeia.charter$), new Color(173, 12, 255));
      avenue.launched$ = new Ustin(Collections.singleton(Akeia.scholars$), new Color(255, 238, 154));
      avenue.seeds$ = new Ustin(Collections.singleton(Akeia.alone$), new Color(255, 255, 255));
      avenue.wheel$ = Ellena._fitted(avenue, "Show Arrows", true);
      avenue.paxil$ = Ellena._fitted(avenue, "Show Pearls", true);
      avenue.digit$ = Ellena._fitted(avenue, "Show Potions", false);
      avenue.humans$ = Ellena._fitted(avenue, "Show Eggs", false);
      avenue.fully$ = Ellena._fitted(avenue, "Show Snowballs", false);
      avenue.phases$ = Alondra._slide();
      avenue._actions(new Albert[]{avenue.wheel$, avenue.paxil$, avenue.digit$, avenue.humans$, avenue.fully$});
   }

   public void _football(Angelicia udacusaz) {
      Object falebamu = Alondra._right();
      Iterator utevagoc = falebamu._because().iterator();

      while(utevagoc.hasNext()) {
         Object ufareven = utevagoc.next();
         Object bocucoyi = new Lavetta(ufareven);
         if (bocucoyi._gotta(Akeia.talented$)) {
            Object afobigay = new Marieann(bocucoyi._science());
            Object erurucos = new Jaquita(bocucoyi._science());
            Coree var8 = etabubat._musician(afobigay);
            if (var8 != null) {
               etabubat._petition(erurucos, var8);
            }
         }
      }

   }

   private List _tires() {
      Object sedayodu = new ArrayList();
      if (sebocute.wheel$._sounds().booleanValue()) {
         sedayodu.add(sebocute.powered$);
      }

      if (sebocute.digit$._sounds().booleanValue()) {
         sedayodu.add(sebocute.measured$);
      }

      if (sebocute.paxil$._sounds().booleanValue()) {
         sedayodu.add(sebocute.broken$);
      }

      if (sebocute.humans$._sounds().booleanValue()) {
         sedayodu.add(sebocute.launched$);
      }

      if (sebocute.fully$._sounds().booleanValue()) {
         sedayodu.add(sebocute.seeds$);
      }

      return sedayodu;
   }

   private Coree _musician(Jaquita rapids) {
      if (rapids._series()) {
         return null;
      } else {
         Iterator delete = branches._tires().iterator();

         Coree equity;
         do {
            if (!delete.hasNext()) {
               return null;
            }

            equity = (Coree)delete.next();
         } while(!equity._booth(rapids));

         return equity;
      }
   }

   private void _outputs(double uyunolup, double ufagevob, double var5) {
      GL11.glVertex3d(uyunolup - ezoyonen.phases$._shared(), ufagevob - ezoyonen.phases$._cement(), var5 - ezoyonen.phases$._explore());
   }

   private void _petition(Jaquita certain, Coree rather) {
      if (certain._gotta(Akeia.talented$)) {
         Object terminal = Alondra._inserted();
         Object calendar = Alondra._right();
         Object kenya = rather._layout(certain._science());
         if (kenya == null) {
            kenya = new Color(255, 255, 255);
         }

         GL11.glPushMatrix();
         GL11.glLineWidth(1.5F);
         Shakeema._google(kenya);
         GL11.glEnable(2848);
         GL11.glEnable(3042);
         GL11.glDisable(3553);
         GL11.glDisable(2929);
         GL11.glBegin(3);
         Object marine = certain._defining();
         Object seeker = certain._opens();
         Object compile = certain._dealt();
         Object miracle = certain._protocol();
         Object drove = certain._themes();
         Object rising = certain._blend();
         farms._outputs(marine, seeker, compile);

         while(true) {
            Object auctions = rather._heater();
            Object colored = rather._enlarge();
            Object emerald = Lekeisha._trial(marine - (double)auctions, seeker, compile - (double)auctions, marine + (double)auctions, seeker + (double)colored, compile + (double)auctions);
            Object plumbing = Tricha._speeds(marine, seeker, compile);
            Object barrel = Tricha._speeds(marine + miracle, seeker + drove, compile + rising);
            Object argument = calendar._sections(plumbing, barrel, false, certain._gotta(Akeia.pulled$), false);
            if (argument._trustees()) {
               barrel = Tricha._speeds(argument._metallic()._fired(), argument._metallic()._looking(), argument._metallic()._larry());
            }

            Object animals = calendar._readily(terminal, emerald._samoa(miracle, drove, rising)._traffic(1.0D, 1.0D, 1.0D));
            double var25 = 0.0D;
            Iterator var27 = animals.iterator();

            while(var27.hasNext()) {
               Object var28 = var27.next();
               Lavetta var29 = new Lavetta(var28);
               if (var29._gotta(Akeia.shore$) && !var29._gotta(Akeia.profiles$) && var29._except() && !var29.equals(terminal)) {
                  emerald = var29._breath()._traffic(0.3D, 0.3D, 0.3D);
                  Edelmiro var30 = emerald._eligible(plumbing, barrel);
                  if (var30._trustees()) {
                     double var31 = plumbing._blues(var30._metallic());
                     if (var31 >= var25) {
                        Double.compare(var25, 0.0D);
                     }

                     var25 = var31;
                     var30._opposed(var29);
                     argument = var30;
                  }
               }
            }

            marine += miracle;
            seeker += drove;
            compile += rising;
            if (argument._trustees()) {
               marine = argument._metallic()._fired();
               seeker = argument._metallic()._looking();
               compile = argument._metallic()._larry();
               break;
            }

            if (seeker < -128.0D) {
               break;
            }

            miracle *= certain._shannon() ? 0.8D : 0.99D;
            drove *= certain._shannon() ? 0.8D : 0.99D;
            rising *= certain._shannon() ? 0.8D : 0.99D;
            drove -= 0.05D;
            farms._outputs(marine + miracle, seeker + drove, compile + rising);
         }

         GL11.glEnd();
         GL11.glDisable(2848);
         GL11.glDisable(3042);
         GL11.glEnable(3553);
         GL11.glEnable(2929);
         GL11.glPopMatrix();
      }
   }
}
