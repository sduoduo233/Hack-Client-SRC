import java.util.Iterator;

public class Daphnee extends Hanna {
   private final Bevin looked$;
   private final Verne specs$ = new Verne();
   private Jalene infrared$;

   public Daphnee() {
      super("InvCleaner", false);
      ocean._troops()._sports(new June(0.0D, 0.0D, 5000, 1, new Brently(0, 0, 0, 0)));
      ocean._testing(100.0D);
      ocean._arrives(20.0D);
      Object outreach = (Shehzad)Dyesha.banodage$._provider()._dynamic(Shehzad.class);
      Object hospital = new Darick(false);
      hospital._sports(new June(0.0D, 3.0D, 5000, 1, new Brently(0, 2, 2, 2)));
      hospital._testing(ocean._explain());
      ocean._notices(hospital);
      Object lucky = hospital._explain() - 8.0D;
      hospital._clara(new Mahlon(Dyesha.banodage$._provider()._dynamic(Shehzad.class)))._testing(lucky);
      Object kinds = new Eira(64);
      kinds._testing(lucky);
      kinds._arrives(12.0D);
      kinds._purchase("<item name>");
      hospital._clara(kinds);
      Object complex = new Marvin(10.0D, 1.0D, "", " stacks", "Allowed Stacks");
      complex._python(1.0D);
      complex._testing(lucky);
      complex._arrives(8.0D);
      hospital._clara(complex);
      Object includes = new Darick(false);
      includes._columns(false);
      includes._swiss(k);
      includes._sports(new June(2.0D, 0.0D, 1, 2, new Brently(0, 0, 0, 0)));
      includes._testing(lucky);
      hospital._clara(includes);
      Object moving = new Harout("Whitelist", true);
      moving._testing(includes._explain() / 2.0D);
      moving._arrives(12.0D);
      moving._headline()._columns(false);
      moving._almost("Allow the item to be in your inventory.\nIt will only drop if it exceeds the allowed stack limits.");
      moving._leaves(new iReSqtkUVgEyMiReSqtkUVg(ocean, kinds, outreach, complex));
      includes._clara(moving);
      Harout var9 = new Harout("Blacklist", true);
      var9._testing(includes._explain() / 2.0D - 2.0D);
      var9._arrives(12.0D);
      var9._headline()._columns(false);
      var9._almost("Always remove this item from your inventory,\nregardless of item stacks");
      var9._leaves(new Jenae(ocean, kinds, outreach));
      includes._clara(var9);
      ocean.infrared$ = new Jalene(false);
      ocean.infrared$._arrives(80.0D);
      ocean.infrared$._testing(lucky - 2.0D);
      ocean._notices(ocean.infrared$);
      ocean.looked$ = new Bevin("", Hadiya.others$, 0.8D);
      ocean.looked$._testing(lucky);
      ocean.looked$._arrives(15.0D);
      ocean.looked$._torture(false);
      ocean._notices(ocean.looked$);
   }

   public void _scotland() {
      super._scotland();
      if (utapidus.looked$._notify() && utapidus.specs$._basename(2000L)) {
         utapidus.looked$._hotels("");
         utapidus.specs$._cards();
      }

      if (utapidus.looked$._edges().isEmpty()) {
         utapidus.looked$._torture(false);
      } else {
         utapidus.looked$._torture(true);
      }

   }

   public void _solution(Artemus luther) {
      Object oliver = adware._explain() - 24.0D;
      Darick var4 = new Darick(false);
      var4._testing(oliver);
      var4._sports(new June(1.0D, 1.0D, 2, 2, new Brently(0, 2, 0, 0)));
      adware.infrared$._riders(var4);
   }

   public void _special(Artemus vuvufeno) {
      Object nasiramo = null;
      Iterator utamuzog = zilozumo.infrared$._facility()._manage().iterator();

      while(true) {
         while(true) {
            Jeanpaul oduroziv;
            do {
               if (!utamuzog.hasNext()) {
                  if (nasiramo != null) {
                     zilozumo.infrared$._facility()._checks(nasiramo);
                  }

                  return;
               }

               oduroziv = (Jeanpaul)utamuzog.next();
            } while(!(oduroziv instanceof Darick));

            Object ayaveluf = (Darick)oduroziv;
            Iterator itigebag = ayaveluf._manage().iterator();

            while(itigebag.hasNext()) {
               Object dutubipi = (Jeanpaul)itigebag.next();
               if (dutubipi instanceof Shereen) {
                  Object gasupima = (Shereen)dutubipi;
                  if (gasupima._incoming().equals(vuvufeno) || gasupima._incoming()._stocks().equalsIgnoreCase(vuvufeno._stocks())) {
                     nasiramo = oduroziv;
                     break;
                  }
               }
            }
         }
      }
   }

   static Verne _wealth(Daphnee custom) {
      return custom.specs$;
   }

   static Bevin _polymer(Daphnee dosarobo) {
      return dosarobo.looked$;
   }
}
