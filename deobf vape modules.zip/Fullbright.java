public class Gaston extends Fanny {
   private Dusti icunolad$ = new Dusti("Night Vision");
   private Dusti musofube$ = new Dusti("Gamma");
   private Franciso vobasome$;
   private float bamoteru$;

   public Gaston() {
      super("Fullbright", -256, Ayonna.weather$);
      projects.vobasome$ = Franciso._polar(projects, "Mode", projects.icunolad$, projects.icunolad$, projects.musofube$);
      projects.bamoteru$ = -1.0F;
      projects._actions(new Albert[]{projects.vobasome$});
      ((Jinny)projects.vobasome$._columbus())._fancy(new Emilene(projects));
   }

   public void _strings(Neill var1) {
      if (planets.vobasome$._young().equals(planets.icunolad$)) {
         Alondra._inserted()._truth(Amilcar._actress(16, 5220, 0));
      } else {
         Alondra._surfaces()._lessons(10.0F);
      }

   }

   public void _niger() {
      rural.bamoteru$ = Alondra._surfaces()._string();
   }

   public void _ghana() {
      Alondra._inserted()._lecture(16);
      Alondra._surfaces()._lessons(alpha.bamoteru$);
   }

   static Dusti _prairie(Gaston yoluvile) {
      return yoluvile.musofube$;
   }

   static Franciso _genre(Gaston barriers) {
      return barriers.vobasome$;
   }

   static float _segments(Gaston orucubip) {
      return orucubip.bamoteru$;
   }
}
