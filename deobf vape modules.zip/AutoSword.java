public class Texas extends Fanny {
   private Ellena handed$;
   private Ellena steven$;

   public Texas() {
      super("AutoSword", 6485058, Ayonna.lyrics$, "Automatically equips your sword when attacking entities.");
      route.handed$ = Ellena._designs(route, "Players only", true, "Only swap when attacking players.");
      route.steven$ = Ellena._designs(route, "Hand only", false, "Only swap when holding nothing.");
      route._actions(new Albert[]{route.handed$, route.steven$});
   }

   public boolean _industry() {
      return true;
   }

   public void _refine(Crawford vuniparu) {
      if ((!ofavolon.handed$._sounds().booleanValue() || vuniparu._silence()._gotta(Akeia.mapping$)) && !vuniparu._adaptor() && Alondra._position()._warner()) {
         Object vinuzota = Alondra._inserted();
         if (!ofavolon.steven$._sounds().booleanValue() || vinuzota._remains()._warner() || vinuzota._remains()._educated()._warner()) {
            int tufimicu = 36;

            while(true) {
               boolean var10001 = true;
               if (vinuzota._discs()._compact(tufimicu)._ports()) {
                  Object igitocum = vinuzota._discs()._compact(tufimicu)._monthly()._educated();
                  if (igitocum._gotta(Akeia.berkeley$) && vinuzota._ordering()._products() != tufimicu - 36) {
                     vinuzota._ordering()._steal(tufimicu - 36);
                     vinuzota._witch()._teddy(Camron._handle(tufimicu - 36));
                     Alondra._emacs()._notes();
                     break;
                  }
               }

               ++tufimicu;
            }
         }
      }

   }
}
