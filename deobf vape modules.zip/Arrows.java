import java.awt.Color;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.lwjgl.opengl.GL11;

public class Whisper extends Fanny {
   private Ricahrd cisavafa$;
   private Ellena litovuca$;
   private Ellena ucucayal$;
   private Ellena yatalage$;
   private Dustun recinudo$;
   private Map ibilofel$;

   public Whisper() {
      super("Arrows", 14223934, Ayonna.weather$, "Draws arrows on screen when players\nare out of your field of view.");
      prepaid.cisavafa$ = Ricahrd._strike(prepaid, "Color", new Color(255, 0, 0));
      prepaid.litovuca$ = Ellena._designs(prepaid, "Show Distance", false, "Renders the distance next to the arrow.");
      prepaid.ucucayal$ = Ellena._designs(prepaid, "Scale Opacity", false, "Lowers the opacity the farther they are.");
      prepaid.yatalage$ = Ellena._designs(prepaid, "Healthbar", false, "Renders a healthbar under the distance.");
      prepaid.recinudo$ = Dustun._gentle(prepaid, "Radius Scale", "#.##", "%", 0.0D, 0.5D, 1.0D, 0.05D);
      prepaid.ibilofel$ = new HashMap();
      prepaid._actions(new Albert[]{prepaid.cisavafa$, prepaid.recinudo$, prepaid.litovuca$, prepaid.ucucayal$});
   }

   public void _football(Angelicia gasuyiri) {
      orutociy.ibilofel$.clear();
      Object puzuneti = Alondra._slide();
      Iterator nosoyayo = Alondra._right()._lambda().iterator();

      while(nosoyayo.hasNext()) {
         Object gebinogu = nosoyayo.next();
         if (Akeia.shipping$.isAssignableFrom(gebinogu.getClass()) && !Akeia.yearly$.isAssignableFrom(gebinogu.getClass())) {
            Object otiridac = new Maxamillion(gebinogu);
            Object logatapa = otiridac._bouquet() + (otiridac._defining() - otiridac._bouquet()) * (double)gasuyiri._bureau() - puzuneti._shared();
            Object dodizitu = otiridac._proved() + (otiridac._opens() - otiridac._proved()) * (double)gasuyiri._bureau() - puzuneti._cement();
            double var10 = otiridac._eagle() + (otiridac._dealt() - otiridac._eagle()) * (double)gasuyiri._bureau() - puzuneti._explore();
            double[] var12 = Taci._ships(logatapa, dodizitu, var10);
            orutociy.ibilofel$.put(otiridac, var12);
         }
      }

   }

   public void _senate(Antwan fanipezi) {
      if (!Alondra._right()._warner()) {
         Object osorolec = fanipezi._lined();
         if (osorolec._gotta(Akeia.shipping$)) {
            if (!Tamirra.divine$ || !osorolec._gotta(Akeia.whats$)) {
               Object ayeyapil = new Maxamillion(osorolec._science());
               Object avoyimob = fanipezi._tanzania();
               Object ufucemip = fanipezi._stanley();
               double var8 = fanipezi._analyst();
               double[] var10 = Taci._ships(avoyimob, ufucemip, var8);
               azogidid.ibilofel$.put(ayeyapil, var10);
            }
         }
      }
   }

   public void _evidence(Loma gigumazo) {
      Object molulabi = Alondra._inserted();
      if (!molulabi._warner() && !molulabi._cream()._warner()) {
         if (!gigumazo._chances() && gigumazo._bubble()) {
            Object pigepivo = Maila._tiffany(new Alondra(), Alondra._charger(), Alondra._bunch());
            Object yolacila = (float)(pigepivo._leisure() / 2);
            Object upeyayin = (float)(pigepivo._obvious() / 2);
            Object uficulas = (double)upeyayin * omuyemun.recinudo$._cingular().doubleValue();
            Shakeema._abraham(Color.WHITE, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D);
            Object emozogun = Alondra._examined();
            Iterator yebigenu = omuyemun.ibilofel$.keySet().iterator();

            while(true) {
               Lavetta nisolotu;
               double[] yibotifu;
               double orupuros;
               double rofinate;
               do {
                  if (!yebigenu.hasNext()) {
                     omuyemun.ibilofel$.clear();
                     return;
                  }

                  nisolotu = (Lavetta)yebigenu.next();
                  yibotifu = (double[])omuyemun.ibilofel$.get(nisolotu);
                  orupuros = yibotifu[0];
                  rofinate = (double)Alondra._bunch() - yibotifu[1];
               } while(yibotifu[2] < 1.0D && omuyemun._criminal(orupuros, rofinate, pigepivo));

               Object tesuvega = omuyemun._place((double)yolacila, orupuros / (double)pigepivo._multiple(), (double)upeyayin, rofinate / (double)pigepivo._multiple()) + (float)(yibotifu[2] > 1.0D ? 180 : 0);
               Object coyuyizi = uficulas * Math.cos(Math.toRadians((double)tesuvega));
               double var19 = uficulas * Math.sin(Math.toRadians((double)tesuvega));
               int var21 = (int)(molulabi._header(nisolotu) * 2.0F);
               if (var21 > 255) {
                  var21 = 255;
               }

               Color var23;
               if (omuyemun.litovuca$._sounds().booleanValue() && var21 < 225) {
                  GL11.glPushMatrix();
                  String var22 = (int)molulabi._header(nisolotu) + "m";
                  GL11.glTranslated(coyuyizi + (double)(pigepivo._leisure() / 2), var19 + (double)(pigepivo._obvious() / 2), 0.0D);
                  GL11.glScaled(0.5D, 0.5D, 0.0D);
                  Marlea._linda();
                  var23 = new Color(255, 255, 255, 255 - (omuyemun.ucucayal$._sounds().booleanValue() ? var21 : 0));
                  emozogun._aging(var22, (double)(-emozogun._enabling(var22) / 2), -emozogun._reynolds(var22), Nida._quickly(var23.getRed(), var23.getGreen(), var23.getBlue(), var23.getAlpha()));
                  Marlea._bedding();
                  GL11.glPopMatrix();
               }

               GL11.glPushMatrix();
               GL11.glTranslated(coyuyizi + (double)(pigepivo._leisure() / 2), var19 + (double)(pigepivo._obvious() / 2), 0.0D);
               GL11.glRotatef(tesuvega - 90.0F, 0.0F, 0.0F, 1.0F);
               GL11.glScaled(0.375D, 0.5D, 0.0D);
               Color var24 = omuyemun.cisavafa$._depends();
               var23 = new Color(var24.getRed(), var24.getGreen(), var24.getBlue(), 255 - (omuyemun.ucucayal$._sounds().booleanValue() ? var21 : 0));
               Keianna._wired(var23, -16.0F, 0.0F, "exo", 1.0F, false);
               GL11.glPopMatrix();
            }
         }
      }
   }

   private boolean _criminal(double powder, double var3, Maila var5) {
      return powder > 0.0D && var3 > 0.0D && powder < (double)Alondra._charger() && var3 < (double)Alondra._bunch();
   }

   private float _place(double blues, double seekers, double var5, double var7) {
      return (float)Math.toDegrees(Math.atan2(var7 - var5, seekers - blues));
   }
}
