public class Shanetra extends Fanny {
   private Ellena theaters$;
   private Tashenna muslim$;
   private boolean actively$;

   public Shanetra() {
      super("NoSlowdown", 14828276, Ayonna.lyrics$, "Prevents slowing down when\nblocking or using items.");
      umilidoy.theaters$ = Ellena._designs(umilidoy, "Limit Items", false, "Limits to whitelisted items only.");
      umilidoy.muslim$ = Tashenna._party(umilidoy, "noslowdown-whitelist", "Whitelisted", Tashenna.nifurine$, new Artemus("swords"));
      umilidoy.theaters$._heated(umilidoy.muslim$);
      umilidoy._actions(new Albert[]{umilidoy.theaters$, umilidoy.muslim$});
   }

   public boolean _industry() {
      return true;
   }

   public void _breeds(Rhema dofayiva) {
      Object obapedad = dofayiva._gonna();
      if (obapedad._gotta(Akeia.politics$)) {
         yurozidi.actively$ = true;
      }

      if (obapedad._gotta(Akeia.numbers$)) {
         Object buvepuca = new Nakia(obapedad);
         Object focipida = Alondra._inserted();
         if (buvepuca._adverse() == focipida._declare()) {
            yurozidi.actively$ = true;
         }
      }

   }

   public void _retailer(Chikita alitizac) {
      Object uvozulod = Alondra._inserted();
      if (luzilozo.actively$) {
         if (uvozulod._series()) {
            luzilozo.actively$ = false;
         }

      } else if (!uvozulod._shannon()) {
         if (alitizac._latin() == Desirre.barrier$) {
            Object ozibapin = (double)uvozulod._instance()._recall();
            Object luzemico = (double)uvozulod._instance()._chains();
            float var7 = uvozulod._armed();
            if (uvozulod._statute() && (!luzilozo.theaters$._sounds().booleanValue() || luzilozo.muslim$._please(uvozulod._remains())) && (Math.abs(luzemico) == 0.20000000298023224D || Math.abs(ozibapin) == 0.20000000298023224D)) {
               if (Dyesha.banodage$._provider()._smooth(Giana.class)) {
                  uvozulod._plaza(true);
               }

               if (Math.abs(luzemico) == 0.20000000298023224D) {
                  if (luzemico > 0.0D) {
                     uvozulod._instance()._stripes(1.0F);
                  } else if (luzemico < 0.0D) {
                     uvozulod._instance()._stripes(-1.0F);
                  }
               }

               if (Math.abs(ozibapin) == 0.20000000298023224D) {
                  if (ozibapin > 0.0D) {
                     uvozulod._instance()._benjamin(1.0F);
                  } else if (ozibapin < 0.0D) {
                     uvozulod._instance()._benjamin(-1.0F);
                  }
               }

               if (Math.abs(uvozulod._instance()._chains()) != 1.0F && ozibapin > 0.0D) {
                  ozibapin *= 1.2999999523162842D;
               }

               if (ozibapin != 0.0D) {
                  luzemico *= 0.5D;
               } else {
                  luzemico *= 0.85D;
               }

               uvozulod._obtained(ozibapin * Math.cos(Math.toRadians((double)(var7 + 90.0F))) + luzemico * Math.sin(Math.toRadians((double)(var7 + 90.0F))));
               uvozulod._lotus(ozibapin * Math.sin(Math.toRadians((double)(var7 + 90.0F))) - luzemico * Math.cos(Math.toRadians((double)(var7 + 90.0F))));
            }
         }

      }
   }
}
