public class Stephany extends Fanny {
   private double sugegate$;
   private double epazizud$;
   private Sachin pigoneyu$;
   private Evertt ogiralar$;

   public Stephany() {
      super("KeepSprint", 14828276, Ayonna.lyrics$, "Prevents you from losing sprint when attacking.");
   }

   public void _refine(Crawford fodimida) {
      Object vebozipa = Alondra._inserted();
      if (miyaduci.pigoneyu$ == null) {
         miyaduci.pigoneyu$ = (Sachin)Dyesha.banodage$._provider()._dynamic(Sachin.class);
      }

      if (!miyaduci.pigoneyu$._brisbane()) {
         if (fodimida._latin() == Desirre.barrier$) {
            miyaduci.sugegate$ = vebozipa._protocol();
            miyaduci.epazizud$ = vebozipa._blend();
         }

         if (fodimida._latin() == Desirre.harley$ && vebozipa._protocol() == (miyaduci.sugegate$ *= 0.6D) && vebozipa._blend() == (miyaduci.epazizud$ *= 0.6D) && !vebozipa._malawi()) {
            vebozipa._obtained(vebozipa._protocol() / 0.6D);
            vebozipa._lotus(vebozipa._blend() / 0.6D);
            vebozipa._plaza(true);
         }

      }
   }

   public void _strings(Neill cufemafe) {
      if (gumucazi.pigoneyu$ == null) {
         gumucazi.pigoneyu$ = (Sachin)Dyesha.banodage$._provider()._dynamic(Sachin.class);
      }

      if (!gumucazi.pigoneyu$._brisbane()) {
         Farzad var2 = Alondra._inserted()._moldova(Dewanda._formats());
         if (Alondra._inserted()._airports() && var2._session(Quenna._played()._tables())._warner()) {
            var2._shirts(Quenna._played());
         }

      }
   }

   public void _theater(Latoya intend) {
      if (writing.pigoneyu$ == null) {
         writing.pigoneyu$ = (Sachin)Dyesha.banodage$._provider()._dynamic(Sachin.class);
      }

      if (!writing.pigoneyu$._brisbane()) {
         if (intend._label().equals(Alondra._inserted())) {
            if (!intend._chile()) {
               if (writing._civil(Alondra._inserted())) {
                  intend._angeles(true);
               }

            }
         }
      }
   }

   public boolean _industry() {
      return true;
   }

   private boolean _civil(Tempess jones) {
      return !flashing.pigoneyu$._brisbane() && jones._trouble() > 0.0F && !jones._notice() && jones._kansas()._enzyme() > 6 && !jones._malawi();
   }
}
