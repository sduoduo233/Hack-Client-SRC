public class Shamaria extends Fanny {
   private Ellena vendors$;
   private boolean fotos$;

   public Shamaria() {
      super("SafeWalk", -9176515, Ayonna.lyrics$, "Helps you from falling off the edge.");
      egatibal.vendors$ = Ellena._designs(egatibal, "Direction Check", true, "Checks if you're walking forwards and it'll allow you to walk off the edge");
      egatibal._blocked().add(egatibal.vendors$);
   }

   public boolean _industry() {
      return true;
   }

   public void _earliest(Quanesha camadila) {
      Object udisenad = Alondra._inserted();
      if (camadila._adaptor()) {
         peveboya.fotos$ = udisenad._instance()._hilton();
         Object betenale = true;
         if (peveboya.vendors$._sounds().booleanValue() && !udisenad._notice() && udisenad._trouble() > 0.0F && udisenad._employer() == 0.0F) {
            betenale = false;
         }

         udisenad._instance()._leslie(true);
      } else {
         udisenad._instance()._leslie(peveboya.fotos$);
      }

   }
}
