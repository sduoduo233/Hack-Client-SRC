import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import org.lwjgl.input.Mouse;

public class Latisa extends Fanny {
   private final Ashley giyafiva$;
   private int bulanaba$;
   private Ellena ugomufad$;
   private Ellena osovibuc$;
   private Ellena timelazi$;
   private Ellena dugoyoda$;
   private Tashenna yisirafe$;
   private Ashley olenebeb$;
   private Ellena yuzinezo$;
   private Ellena ugitebin$;
   private Tashenna omulunob$;
   private boolean oyatepol$;
   private Tahisha cunucubi$;
   private Tahisha yozemala$;
   private boolean eneceduz$;
   private Queue urarocig$;

   public Latisa() {
      super("AutoClicker", -62703, Ayonna.resource$, "Hold attack button to automatically click");
      kills.giyafiva$ = Ashley._laptop(kills, "CPS", "#.#", "", 1.0D, 6.0D, 13.0D, 20.0D);
      kills.ugomufad$ = Ellena._designs(kills, "Inventory Fill", false, "AutoClicker functions while in inventory for refilling items");
      kills.osovibuc$ = Ellena._fitted(kills, "Blockhit", false);
      kills.timelazi$ = Ellena._fitted(kills, "Right Click Mode", false);
      kills.dugoyoda$ = Ellena._designs(kills, "Break Blocks", false, "Allows you to break blocks");
      kills.yisirafe$ = Tashenna._party(kills, "autoclicker-alloweditems", "Allowed Items", Tashenna.nifurine$, new Artemus("swords"));
      kills.olenebeb$ = Ashley._laptop(kills, "Right CPS", "#.#", "", 1.0D, 6.0D, 13.0D, 20.0D);
      kills.yuzinezo$ = Ellena._designs(kills, "Limit to items", false, "AutoClicker functions only while holding selected items");
      kills.ugitebin$ = Ellena._designs(kills, "Limit to items", false, "AutoClicker functions only while holding selected items");
      kills.omulunob$ = Tashenna._party(kills, "autoclicker-alloweditems-right", "Allowed Items", Tashenna.nifurine$, new Artemus("blocks"));
      kills.cunucubi$ = new Tahisha(kills, 0, true, true);
      kills.yozemala$ = new Tahisha(kills, 1, false, false);
      kills.eneceduz$ = false;
      kills.urarocig$ = new ConcurrentLinkedQueue();
      kills.yuzinezo$._heated(kills.omulunob$);
      kills.ugitebin$._heated(kills.yisirafe$);
      kills.timelazi$._heated(kills.olenebeb$, kills.yuzinezo$);
      kills._actions(new Albert[]{kills.ugomufad$, kills.osovibuc$, kills.dugoyoda$, kills.giyafiva$, kills.timelazi$, kills.olenebeb$, kills.yuzinezo$, kills.omulunob$, kills.ugitebin$, kills.yisirafe$});
   }

   private List _councils() {
      Object tosolomi = new ArrayList();
      Object vinecifa = Alondra._inserted()._ordering()._rotary();
      int dumoride = 0;

      while(true) {
         boolean var10001 = true;
         Object udivemet = new Trinette(vinecifa[dumoride]);
         if (udivemet._warner()) {
            tosolomi.add(dumoride);
         }

         ++dumoride;
      }
   }

   private boolean _split() {
      if (leisure.dugoyoda$._sounds().booleanValue() && Alondra._ranges()._trustees() && Alondra._ranges()._laugh().equals(Danial._midwest())) {
         if (Tamirra._preserve()) {
            Object rejected = Alondra._surfaces()._utility();
            Micholas._lingerie(rejected._performs(), true);
         }

         return true;
      } else {
         return false;
      }
   }

   public void _niger() {
      if (!parking.oyatepol$) {
         parking.oyatepol$ = true;
         (new Dawud(parking)).start();
         (new Quintina(parking)).start();
      }

   }

   private boolean _jason() {
      if (Alondra._position()._trustees()) {
         return true;
      } else if (!uvenunid._circuit()) {
         return true;
      } else {
         Object eficunav = Alondra._inserted()._remains();
         return uvenunid.yisirafe$._cultures(eficunav, true);
      }
   }

   private boolean _circuit() {
      return remolobo.ugitebin$._sounds().booleanValue();
   }

   public boolean _charms() {
      return Alondra._inserted()._warner() ? false : piciyodi._jason();
   }

   private boolean _topic() {
      if (Alondra._inserted()._warner()) {
         return false;
      } else if (!pugaloyo.yuzinezo$._sounds().booleanValue()) {
         return true;
      } else {
         Object atisoyec = Alondra._inserted()._remains();
         return pugaloyo.omulunob$._cultures(atisoyec, true);
      }
   }

   private void _warming(Syble walks) {
      Object adipex = Mouse.getEventX() * walks._deals() / Alondra._charger();
      Object climate = walks._mysql() - Mouse.getEventY() * walks._mysql() / Alondra._bunch() - 1;
      scoring.urarocig$.add(new Gorje(adipex, climate, (Dawud)null));
   }

   public void _strings(Neill taken) {
      Object netscape = Alondra._position();
      if (netscape._gotta(Akeia.hotel$)) {
         if (!devices.urarocig$.isEmpty()) {
            Object diane = (Gorje)devices.urarocig$.poll();
            Syble var4 = new Syble(netscape);
            devices._ellis(var4, diane._mouth(), diane._option());
         }

      }
   }

   private void _ellis(Syble entered, int viewer, int queen) {
      Object english = entered._delaware(viewer, queen);
      Object cabinets = Alondra._restored();
      entered._thorough(false);
      entered._sized(false);
      Object released = 0;
      Object egypt = entered._robin();
      Object upgrades = entered._comic();
      boolean var10000;
      if (viewer >= egypt && queen >= upgrades && viewer < egypt + entered._kingston() && queen < upgrades + entered._exist()) {
         var10000 = false;
      } else {
         var10000 = true;
      }

      boolean var11 = true;
      if (!english._warner()) {
         int var15 = english._stopped();
      }

      var11 = true;
      boolean var10001 = true;
      entered._gently(english);
      entered._hydrogen(cabinets);
      entered._nuclear(released);
   }

   static boolean _corners(Latisa azerefas) {
      return azerefas._circuit();
   }

   static boolean _known(Latisa ulamusar) {
      return ulamusar._jason();
   }

   static boolean _resort(Latisa ipagefog) {
      return ipagefog._split();
   }

   static boolean _stone(Latisa yerabumo) {
      return yerabumo.eneceduz$;
   }

   static boolean _sudden(Latisa taledime, boolean duyareda) {
      return taledime.eneceduz$ = duyareda;
   }

   static Ellena _medal(Latisa fiscal) {
      return fiscal.ugomufad$;
   }

   static Tahisha _beliefs(Latisa cudofati) {
      return cudofati.cunucubi$;
   }

   static Ellena _vocal(Latisa padecame) {
      return padecame.timelazi$;
   }

   static Tahisha _current(Latisa insight) {
      return insight.yozemala$;
   }

   static boolean _modify(Latisa muvemeyo) {
      return muvemeyo._topic();
   }

   static List _fairy(Latisa affected) {
      return affected._councils();
   }

   static void _locally(Latisa nibupalo, Syble gabelubo) {
      nibupalo._warming(gabelubo);
   }

   static Ellena _diverse(Latisa asedenag) {
      return asedenag.osovibuc$;
   }

   static Ashley _inter(Latisa civic) {
      return civic.giyafiva$;
   }

   static Ashley _flesh(Latisa udirizug) {
      return udirizug.olenebeb$;
   }
}
