import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Branndon extends Matthieu {
   private Ellena passport$;
   private List expect$;
   private boolean stored$;

   public Branndon() {
      super("Panic", "Disables all currently enabled modules");
      wales.passport$ = Ellena._designs(wales, "Re-enable", false, "Re-enables all previously enabled modules upon pressing bind a second time");
      wales.expect$ = new ArrayList();
      wales.stored$ = false;
      wales._actions(new Albert[]{wales.passport$});
   }

   public void _niger() {
      ocupavit._symphony(false);
      Iterator gilopibu;
      Fanny obisovig;
      if (ocupavit.passport$._sounds().booleanValue()) {
         ocupavit.stored$ = !ocupavit.stored$;
         if (!ocupavit.stored$) {
            gilopibu = ocupavit.expect$.iterator();

            while(gilopibu.hasNext()) {
               obisovig = (Fanny)gilopibu.next();
               obisovig._symphony(true);
            }

            ocupavit.expect$.clear();
            return;
         }
      } else {
         ocupavit.stored$ = false;
      }

      gilopibu = Dyesha.banodage$._provider()._klein().iterator();

      while(gilopibu.hasNext()) {
         obisovig = (Fanny)gilopibu.next();
         if (obisovig._alpha() && obisovig != ocupavit) {
            obisovig._symphony(false);
            if (ocupavit.passport$._sounds().booleanValue()) {
               ocupavit.expect$.add(obisovig);
            }
         }
      }

   }

   public void _knives(Fanny yorazeye) {
      if (yorazeye != zecazuve) {
         zecazuve.stored$ = false;
         zecazuve.expect$.clear();
      }

   }
}
