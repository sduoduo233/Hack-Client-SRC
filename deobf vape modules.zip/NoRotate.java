public class Zia extends Fanny {
   private int etiyazod$;
   private Verne odazomep$ = new Verne();
   private Verne usobigit$ = new Verne();
   private Ellena paducode$;

   public Zia() {
      super("NoRotate", -2420426, Ayonna.lyrics$, "Prevents the server from\nsetting your view angles.");
      engaged.paducode$ = Ellena._designs(engaged, "Disable Speed", false, "Disable Speed when flagging.");
      engaged._actions(new Albert[]{engaged.paducode$});
   }

   public boolean _industry() {
      return true;
   }

   public void _breeds(Rhema besogiso) {
      if (besogiso._gonna()._gotta(Akeia.magnetic$)) {
         Object agupomoy = (Davien)Dyesha.banodage$._provider()._dynamic(Davien.class);
         agupomoy._snapshot(-5);
         if (dugazafe.usobigit$._basename(2000L)) {
            ++dugazafe.etiyazod$;
            Object idivaven = new Alfredrick(besogiso._gonna());
            Object livusefe = Alondra._inserted();
            if (livusefe._trustees()) {
               idivaven._florence(livusefe._armed());
               idivaven._perry(livusefe._glasses());
            }
         }
      }

   }

   public void _strings(Neill aluyoziy) {
      if (ogegacog.odazomep$._basename(750L) && ogegacog.etiyazod$ > 3 && ogegacog.usobigit$._basename(2000L)) {
         ogegacog.usobigit$._cards();
         ogegacog.odazomep$._cards();
         ogegacog.etiyazod$ = 0;
         Davien var2 = (Davien)Dyesha.banodage$._provider()._dynamic(Davien.class);
         if (ogegacog.paducode$._novelty().booleanValue() && var2._alpha()) {
            var2._adult();
         }
      }

   }
}
