import org.lwjgl.input.Keyboard;

public class Brynn extends Fanny {
   private Deshana paduzece$;
   private boolean yizefare$;
   private Dustun niyumovi$;
   private Dustun aziferan$;
   private Dustun abofivey$;
   private Dustun zugovumo$;

   public Brynn() {
      super("Strafe", -256, Ayonna.lyrics$);
      analyzes.niyumovi$ = Dustun._gentle(analyzes, "Distance", "#.#", "", 0.1D, 3.3D, 6.0D, 1.0D);
      analyzes.aziferan$ = Dustun._bright(analyzes, "Speed", "#.#", "", 0.1D, 0.5D, 1.0D);
      analyzes.abofivey$ = Dustun._bright(analyzes, "Target minimum angle", "#", "", 1.0D, 120.0D, 360.0D);
      analyzes.zugovumo$ = Dustun._bright(analyzes, "Your minimum angle", "#", "", 1.0D, 90.0D, 360.0D);
      analyzes._actions(new Albert[]{analyzes.niyumovi$, analyzes.aziferan$, analyzes.abofivey$, analyzes.zugovumo$});
      analyzes._recorder(10L, true);
   }

   public void _madonna() {
      papizuci.paduzece$ = (Deshana)Dyesha.banodage$._provider()._dynamic(Deshana.class);
   }

   public void _strings(Neill cizucura) {
      Tempess var2 = Alondra._inserted();
      if (ibilipob.yizefare$) {
         var2._plaza(false);
         ibilipob.yizefare$ = false;
      }

   }

   public void _ruled() {
      if (!Alondra._position()._trustees()) {
         Object ebiduyac = Alondra._inserted();
         Object atomigig = Alondra._surfaces()._swingers()._performs();
         Object acaleroz = Keyboard.isKeyDown(atomigig);
         Micholas._lingerie(atomigig, acaleroz);
         Object fenucizo = asoruvog.niyumovi$._cingular().doubleValue();
         Object ogunitac = asoruvog.aziferan$._cingular().doubleValue() / 5.0D;
         ogunitac *= 0.1D;
         boolean var8 = asoruvog.paduzece$._alpha() && asoruvog.paduzece$._valium() != null;
         Quenna var9 = new Quenna(asoruvog.paduzece$._valium());
         if (!var9._warner()) {
            Gared._youth(ebiduyac, var9, asoruvog.abofivey$._cingular().doubleValue() / 2.0D);
            Gared._youth(var9, ebiduyac, asoruvog.zugovumo$._cingular().doubleValue() / 2.0D);
         }
      }
   }
}
