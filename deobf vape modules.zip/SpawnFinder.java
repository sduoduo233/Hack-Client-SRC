import java.awt.Color;
import java.util.Iterator;
import org.lwjgl.opengl.GL11;

public class Cortnee extends Fanny {
   private Deepak depetovo$;
   private Color lavalebe$ = new Color(20, 20, 20, 128);
   private Dustun umilutez$;
   private Ellena egudunun$;
   private Shonetta lipabepo$;

   public Cortnee() {
      super("SpawnerFinder", 9976573, Ayonna.weather$);
      vuzotivi.umilutez$ = Dustun._gentle(vuzotivi, "Scale", "#.#", "", 0.1D, 1.0D, 1.5D, 0.1D);
      vuzotivi.egudunun$ = Ellena._fitted(vuzotivi, "Show distance", true);
      vuzotivi.lipabepo$ = Shonetta._making(vuzotivi, "Spawner names-whitelist", "Spawners", Tashenna.nifurine$, "Zombie", "Skeleton", "Creeper", "Spider");
      vuzotivi.depetovo$ = Alondra._slide();
      vuzotivi._actions(new Albert[]{vuzotivi.umilutez$, vuzotivi.egudunun$, vuzotivi.lipabepo$});
   }

   public void _football(Angelicia keeping) {
      Object weights = GL11.glIsEnabled(3042);
      Alondra._bearing()._couples(1.0D);
      GL11.glPushMatrix();
      if (!weights) {
         GL11.glEnable(3042);
      }

      GL11.glBlendFunc(770, 771);
      GL11.glLineWidth(1.5F);
      GL11.glDisable(3553);
      GL11.glEnable(2848);
      GL11.glDisable(2929);
      GL11.glDepthMask(false);
      Object heavily = steven.depetovo$._shared();
      Object magnet = steven.depetovo$._cement();
      Object sense = steven.depetovo$._explore();
      Object monroe = Alondra._inserted();
      Iterator scotia = Alondra._right()._weekend().iterator();

      while(scotia.hasNext()) {
         Object three = scotia.next();
         if (Akeia.disabled$.isInstance(three)) {
            Ajene var12 = new Ajene(three);
            String var13 = var12._slovakia()._cemetery();
            if (steven.lipabepo$._chair(var13)) {
               String var14 = "";
               if (steven.egudunun$._sounds().booleanValue()) {
                  String var15 = Tamirra.wallace$ + "a[" + Tamirra.wallace$ + "f" + (int)monroe._teach((double)var12._peeing(), (double)var12._issued(), (double)var12._painful()) + Tamirra.wallace$ + "a]" + Tamirra.wallace$ + "r";
                  var14 = var14 + var15 + " ";
               }

               var14 = var14 + var13 + " spawner";
               Taci._fighter(var14, (double)var12._peeing() - heavily + 0.5D, (double)var12._issued() - magnet - 1.0D, (double)var12._painful() - sense + 0.5D, steven.umilutez$._cingular().doubleValue(), Gared._sleep(monroe, (double)var12._peeing(), (double)var12._issued(), (double)var12._painful()), -1, steven.lavalebe$, 1.4D);
            }
         }
      }

      GL11.glDepthMask(true);
      GL11.glEnable(2929);
      GL11.glEnable(3553);
      GL11.glDisable(2848);
      if (!weights) {
         GL11.glDisable(3042);
      }

      GL11.glPopMatrix();
      Alondra._bearing()._derek(1.0D);
   }
}
