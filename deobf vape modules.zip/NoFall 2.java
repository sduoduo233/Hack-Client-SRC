public class Donelle extends Fanny {
   private Dusti france$ = new Dusti("Normal");
   private Dusti palmer$ = new Dusti("Hypixel");
   private Franciso mcdonald$;

   public Donelle() {
      super("NoFall", 8919359, Ayonna.lyrics$, "Prevents taking fall damage.\nThis may not bypass AntiCheats.\n(Bypasses Hypixel)");
      refers.mcdonald$ = Franciso._capitol(refers, "Mode", "NoFall method to prevent you from taking fall damage.\nNormal - Works on vanilla/some anti-cheats (Does not Bypass Hypixel)\nHypixel - Bypasses Watchdog, may work on other anti-cheats", refers.france$, refers.france$, refers.palmer$);
      ((Jinny)refers.mcdonald$._columbus())._fancy(new Nimisha(refers));
      refers._actions(new Albert[]{refers.mcdonald$});
   }

   public boolean _industry() {
      return true;
   }

   public void _retailer(Chikita beyabaye) {
      Object puzipupo = Alondra._inserted();
      oporemic._roster(oporemic.mcdonald$._young()._nations());
      if (!puzipupo._warner() && !puzipupo._cream()._warner() && !puzipupo._himself() && !puzipupo._worker()._doors() && !puzipupo._worker()._print() && !Dyesha.banodage$._provider()._smooth(Timeka.class)) {
         boolean var10000;
         if ((double)puzipupo._ralph() > 2.224D && puzipupo._themes() < 0.0D) {
            var10000 = true;
         } else {
            var10000 = false;
         }

         if (oporemic.mcdonald$._young() == oporemic.france$) {
            if (beyabaye._latin() != Desirre.barrier$) {
               ;
            }
         }

         if (oporemic.mcdonald$._young() == oporemic.palmer$ && beyabaye._latin() == Desirre.barrier$ && (double)puzipupo._ralph() > 2.224D && puzipupo._themes() < 0.0D) {
            puzipupo._witch()._teddy(Kieron._wines(true));
         }

      }
   }

   static Franciso _sally(Donelle elubivup) {
      return elubivup.mcdonald$;
   }
}
