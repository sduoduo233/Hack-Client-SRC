import java.util.HashMap;
import java.util.Map;

public class Kash extends Matthieu {
   private HashMap clarke$ = new HashMap();
   private Franciso fixed$;
   private Franciso colombia$;
   private Dustun clearly$;
   private boolean baghdad$;
   private boolean calgary$;
   private boolean validity$;
   private Alanna phillips$;
   private Verne growth$;
   private int bullet$;
   private int improved$;
   private Map posts$;

   public Kash() {
      super("ArmorSwitch", "Switches between armor sets");
      islamic.clearly$ = Dustun._bright(islamic, "Delay", "#", "", 0.0D, 100.0D, 200.0D);
      islamic.growth$ = new Verne();
      islamic.posts$ = new HashMap();
      Object builds = new Dusti("Diamond");
      Object jeremy = new Dusti("Gold");
      Object mexico = new Dusti("Iron");
      Object settled = new Dusti("Leather");
      Object panic = new Dusti("Chain");
      islamic.clarke$.put(builds, Alanna._faces());
      islamic.clarke$.put(jeremy, Alanna._hostel());
      islamic.clarke$.put(mexico, Alanna._minority());
      islamic.clarke$.put(settled, Alanna._harrison());
      islamic.clarke$.put(panic, Alanna._italian());
      islamic.fixed$ = Franciso._polar(islamic, "Set 1", builds, (iReSqtkUVgzAciReSqtkUVg[])islamic.clarke$.keySet().toArray(new Dusti[islamic.clarke$.size()]));
      islamic.colombia$ = Franciso._polar(islamic, "Set 2", jeremy, (iReSqtkUVgzAciReSqtkUVg[])islamic.clarke$.keySet().toArray(new Dusti[islamic.clarke$.size()]));
      islamic._actions(new Albert[]{islamic.fixed$, islamic.colombia$, islamic.clearly$});
   }

   public void _strings(Neill lalabega) {
      if (abiniyep.baghdad$) {
         abiniyep._symphony(false);
      } else {
         int ulomuyal;
         if (!Alondra._position()._gotta(Akeia.baptist$)) {
            ulomuyal = Alondra._surfaces()._genres()._performs();
            Micholas._lingerie(ulomuyal, true);
            Micholas._trace(ulomuyal);
            Micholas._lingerie(ulomuyal, false);
            abiniyep.calgary$ = true;
         } else if (abiniyep.validity$ && abiniyep.growth$._basename(abiniyep.clearly$._cingular().longValue())) {
            abiniyep.growth$._cards();
            ulomuyal = ((Integer)abiniyep.posts$.get(abiniyep.bullet$)).intValue();
            abiniyep._carry(abiniyep.bullet$, ulomuyal);
            if (abiniyep.bullet$ > 8) {
               abiniyep.baghdad$ = true;
            }

         } else {
            Object ulomuyal = abiniyep._lawrence();
            if (abiniyep.calgary$ && ulomuyal && !abiniyep.validity$) {
               boolean var3 = abiniyep.phillips$.equals(abiniyep.clarke$.get(abiniyep.fixed$._young()));
               if (abiniyep._rachel(var3 ? (Alanna)abiniyep.clarke$.get(abiniyep.colombia$._young()) : (Alanna)abiniyep.clarke$.get(abiniyep.fixed$._young()))) {
                  abiniyep.validity$ = true;
               } else {
                  abiniyep._symphony(false);
               }
            }

            if (!ulomuyal) {
               abiniyep._symphony(false);
            }

         }
      }
   }

   private void _carry(int nancy, int parallel) {
      Object solely = parallel;
      if (recovery.improved$ == 1) {
         solely = nancy;
      }

      Alondra._emacs()._worst(Alondra._inserted()._discs()._spoken(), solely, 1, 0, Alondra._inserted());
      ++recovery.improved$;
      if (recovery.improved$ >= 3) {
         recovery.improved$ = 0;
         ++recovery.bullet$;
      }

   }

   private boolean _lawrence() {
      Object ufacezor = Alondra._inserted();
      Object budomuca = ufacezor._discs();
      Object ginabifu = budomuca._eastern();
      int itemofut = 5;

      while(true) {
         boolean var10001 = true;
         Object agalemer = (Cari)ginabifu.get(itemofut);
         if (agalemer._ports() && agalemer._monthly()._educated()._gotta(Akeia.tattoo$)) {
            Object ucanamud = new Kieran(agalemer._monthly()._educated());
            rolifuse.phillips$ = ucanamud._murphy();
            return true;
         }

         ++itemofut;
      }
   }

   private boolean _rachel(Alanna utuvabey) {
      Object vosafito = false;
      Object tovapevi = false;
      Object gufosagu = false;
      Object donogera = false;
      Object familala = Alondra._inserted();
      Object acitonir = familala._discs();
      Object afobusic = acitonir._eastern();
      int var9 = 9;

      while(true) {
         boolean var10001 = true;
         Cari var10 = (Cari)afobusic.get(var9);
         if (var10._ports()) {
            Gianfranco var11 = var10._monthly()._educated();
            if (var11._gotta(Akeia.tattoo$)) {
               Kieran var12 = new Kieran(var11);
               if (var12._murphy().equals(utuvabey)) {
                  switch(var12._uniform()) {
                  case 0:
                  case 1:
                  case 2:
                  case 3:
                  }
               }
            }
         }

         ++var9;
      }
   }

   public void _niger() {
      launch.bullet$ = 5;
      launch.improved$ = 0;
      launch.validity$ = false;
      launch.baghdad$ = false;
      launch.calgary$ = false;
   }

   public void _ghana() {
      if (Alondra._position()._gotta(Akeia.baptist$)) {
         Alondra._inserted()._lighting();
      }

   }
}
