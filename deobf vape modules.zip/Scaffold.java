import java.awt.Color;
import java.util.Arrays;
import java.util.List;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

public class Sachin extends Fanny {
   private Dusti erevodaf$ = new Dusti("Legit");
   private Dusti pebugibi$ = new Dusti("Blatant");
   private Ellena rusoyeze$;
   private Ellena afovomar$;
   private Ellena emopafoz$;
   private Ellena ipazalom$;
   private Dustun igafacuf$;
   private Franciso urupilop$;
   private Verne ibucobey$;
   private Verne bebupaze$;
   private List oricubim$;
   private boolean ilegumal$;

   public Sachin() {
      super("Scaffold", 49630, Ayonna.lyrics$, "Helps you make bridges/scaffold walk.");
      bryant.rusoyeze$ = Ellena._designs(bryant, "Tower", false, "Builds a tower upwards when you're standing still.");
      bryant.afovomar$ = Ellena._designs(bryant, "Block Count", false, "Renders your block count on\nthe center of your screen.\n(Blatant Only)");
      bryant.emopafoz$ = Ellena._designs(bryant, "Stop Motion", false, "Force stops your motion to tower.");
      bryant.ipazalom$ = Ellena._designs(bryant, "Stop Sprinting", false, "Stops you from sprinting when scaffolding\nThis is required to bypass AAC/GWEN");
      bryant.igafacuf$ = Dustun._minimal(bryant, "Delay", "#", "ms", 0.0D, 50.0D, 500.0D, 50.0D, "Blatant scaffold place delay.");
      bryant.urupilop$ = Franciso._capitol(bryant, "Mode", "Legit - Automatically shifts at edge of block when backwards (fastbridge)\nBlatant - Automatically place blocks under you (Designed for Hypixel)", bryant.erevodaf$, bryant.erevodaf$, bryant.pebugibi$);
      bryant.ibucobey$ = new Verne();
      bryant.bebupaze$ = new Verne();
      bryant.oricubim$ = Arrays.asList(Integer.valueOf(0), Integer.valueOf(6), Integer.valueOf(8), Integer.valueOf(9), Integer.valueOf(10), Integer.valueOf(11), Integer.valueOf(23), Integer.valueOf(25), Integer.valueOf(26), Integer.valueOf(27), Integer.valueOf(28), Integer.valueOf(30), Integer.valueOf(31), Integer.valueOf(32), Integer.valueOf(37), Integer.valueOf(38), Integer.valueOf(39), Integer.valueOf(40), Integer.valueOf(46), Integer.valueOf(51), Integer.valueOf(52), Integer.valueOf(65), Integer.valueOf(66), Integer.valueOf(116), Integer.valueOf(83), Integer.valueOf(85), Integer.valueOf(84), Integer.valueOf(92), Integer.valueOf(96), Integer.valueOf(103), Integer.valueOf(120), Integer.valueOf(131), Integer.valueOf(132), Integer.valueOf(137), Integer.valueOf(145), Integer.valueOf(171), Integer.valueOf(102), Integer.valueOf(160), Integer.valueOf(101), Integer.valueOf(78), Integer.valueOf(79), Integer.valueOf(174), Integer.valueOf(145), Integer.valueOf(146), Integer.valueOf(147), Integer.valueOf(148), Integer.valueOf(149), Integer.valueOf(150), Integer.valueOf(151), Integer.valueOf(152), Integer.valueOf(154), Integer.valueOf(54), Integer.valueOf(50), Integer.valueOf(14), Integer.valueOf(15), Integer.valueOf(16), Integer.valueOf(21), Integer.valueOf(73), Integer.valueOf(74), Integer.valueOf(163), Integer.valueOf(72), Integer.valueOf(70), Integer.valueOf(71), Integer.valueOf(64), Integer.valueOf(63), Integer.valueOf(69), Integer.valueOf(75), Integer.valueOf(76), Integer.valueOf(77), Integer.valueOf(143), Integer.valueOf(138));
      bryant.rusoyeze$._heated(bryant.emopafoz$);
      bryant._actions(new Albert[]{bryant.urupilop$, bryant.rusoyeze$, bryant.emopafoz$, bryant.ipazalom$, bryant.igafacuf$, bryant.afovomar$});
   }

   public boolean _brisbane() {
      return murray._alpha() && murray.ipazalom$._sounds().booleanValue();
   }

   public boolean _gregory() {
      return icons.urupilop$._young().equals(icons.erevodaf$);
   }

   public boolean _industry() {
      return true;
   }

   public void _evidence(Loma utacisep) {
      if (umaceboc.afovomar$._sounds().booleanValue() && umaceboc.urupilop$._young().equals(umaceboc.pebugibi$)) {
         Object nezatolo = Maila._tiffany(new Alondra(), Alondra._charger(), Alondra._bunch());
         Object acivezaz = (float)nezatolo._leisure();
         Object avafudib = (float)nezatolo._obvious();
         Object zecipule = Alondra._examined();
         Object recoyeda = String.valueOf(umaceboc._sunny());
         int var7 = (new Color(255, 0, 0)).getRGB();
         if (umaceboc._sunny() >= 64 && 128 > umaceboc._sunny()) {
            var7 = (new Color(255, 255, 0)).getRGB();
         } else if (umaceboc._sunny() >= 128) {
            var7 = (new Color(0, 255, 0)).getRGB();
         }

         zecipule._aging(recoyeda, (double)(acivezaz / 2.0F - (float)(zecipule._enabling(recoyeda) / 2)), (double)(avafudib / 2.0F - 12.0F), var7);
      }
   }

   public void _niger() {
      Dyesha.banodage$._bookmark()._colony(upidiyev);
      upidiyev.ibucobey$._cards();
   }

   public void _ghana() {
      Object balloon = Alondra._surfaces();
      if (launches._gregory() && balloon._guilty()._autos()) {
         Micholas._lingerie(balloon._guilty()._performs(), false);
         Micholas._trace(balloon._guilty()._performs());
      }

   }

   public void _earliest(Quanesha sasuteri) {
      Object emefucog = Alondra._inserted();
      if (emefucog._series()) {
         if (uzulubul.urupilop$._young().equals(uzulubul.erevodaf$)) {
            if (sasuteri._adaptor()) {
               uzulubul.ilegumal$ = emefucog._instance()._hilton();
               Object egapirun = false;
               Object fivoyini = true;
               if (emefucog._trouble() > 0.0F && emefucog._employer() == 0.0F) {
                  fivoyini = false;
               }

               emefucog._instance()._leslie(true);
               Lekeisha upelosod;
               if (Benji._orlando() >= 15) {
                  upelosod = emefucog._breath();
               } else {
                  upelosod = emefucog._breath()._million();
               }

               if (emefucog._cream()._graphic(emefucog, upelosod._traffic(-0.2D, 0.0D, -0.2D)._careers(emefucog._protocol(), -1.0D, emefucog._blend())).isEmpty()) {
                  egapirun = true;
               }

               Object upelosod = Alondra._surfaces();
               Object yapagudo = upelosod._guilty()._performs();
               Object upevudut = yapagudo > 0 ? Keyboard.isKeyDown(yapagudo) : Mouse.isButtonDown(100 + yapagudo);
               if (uzulubul.ilegumal$ && !upevudut) {
                  Micholas._lingerie(yapagudo, false);
                  Micholas._trace(yapagudo);
               }
            } else {
               emefucog._instance()._leslie(uzulubul.ilegumal$);
            }

         }
      }
   }

   public void _retailer(Chikita pemuraru) {
      Object acenopic = Alondra._inserted();
      Object yibaguso = Alondra._surfaces();
      bemezeva._roster(bemezeva.urupilop$._young()._nations());
      if (bemezeva.urupilop$._young().equals(bemezeva.pebugibi$)) {
         Object ecaputod = new Tylor(acenopic._defining(), acenopic._opens() - 1.0D, acenopic._dealt());
         boolean var10001;
         if (pemuraru._adaptor()) {
            if (bemezeva._brisbane() && acenopic._airports()) {
               Micholas._lingerie(Alondra._surfaces()._finder()._performs(), false);
               acenopic._plaza(false);
            }

            Object dededati = bemezeva._holdings(ecaputod);
            if (dededati != null) {
               Object dorovutu = bemezeva._raised(dededati);
               pemuraru._desktop(dorovutu[0]);
               pemuraru._proposal(dorovutu[1]);
            }

            if (bemezeva._charm()) {
               int dorovutu = 9;

               while(true) {
                  var10001 = true;
                  if (acenopic._discs()._compact(dorovutu)._ports()) {
                     Object icesigot = acenopic._discs()._compact(dorovutu)._monthly();
                     if (icesigot._educated()._gotta(Akeia.cocktail$) && !bemezeva.oricubim$.contains(icesigot._educated()._factors()) && !_chester(icesigot)) {
                        bemezeva._trees(dorovutu, 7);
                        break;
                     }
                  }

                  ++dorovutu;
               }
            }

         } else {
            boolean var10000;
            if (acenopic._instance()._recall() == 0.0F && acenopic._instance()._chains() == 0.0F) {
               var10000 = true;
            } else {
               var10000 = false;
            }

            if (yibaguso._valued()._autos() && bemezeva._sunny() > 0 && bemezeva.rusoyeze$._sounds().booleanValue() && bemezeva.emopafoz$._sounds().booleanValue()) {
               acenopic._airlines(acenopic._defining());
               acenopic._prepare(acenopic._dealt());
               acenopic._valves(acenopic._defining());
               acenopic._targeted(acenopic._dealt());
               acenopic._obtained(0.0D);
               acenopic._lotus(0.0D);
            }

            bemezeva.ibucobey$._cards();
            if (bemezeva._patrick(ecaputod)._naked()) {
               Object dorovutu = true;
               int icesigot = 0;

               while(true) {
                  var10001 = true;
                  Object ifedudut = acenopic._ordering()._company(icesigot);
                  if (_highways(ifedudut) && !_chester(ifedudut) && ifedudut._educated()._gotta(Akeia.cocktail$) && !bemezeva.oricubim$.contains(ifedudut._educated()._factors())) {
                     ;
                  }

                  ++icesigot;
               }
            }

         }
      }
   }

   private void _trees(int ubunepup, int medezifu) {
      Object ibulebus = Alondra._inserted();
      Alondra._emacs()._worst(ibulebus._discs()._spoken(), ubunepup, medezifu, 2, ibulebus);
   }

   private boolean _charm() {
      Object grown = Alondra._inserted();
      int promised = 36;

      while(true) {
         boolean var10001 = true;
         if (grown._discs()._compact(promised)._ports()) {
            Object venue = grown._discs()._compact(promised)._monthly();
            Object hundred = venue._educated();
            if (hundred._gotta(Akeia.cocktail$) && !gender.oricubim$.contains(hundred._factors()) && !_chester(venue)) {
               return false;
            }
         }

         ++promised;
      }
   }

   private boolean _layers(Tylor extended) {
      Object internal = Alondra._inserted();
      Object breaks = Alondra._right();
      Object heard = Tricha._speeds(internal._defining(), internal._opens() + (double)internal._rolling(), internal._dealt());
      Object vessels = Clifford._computer();
      int pensions;
      if (Benji._orlando() > 13) {
         Object trends = Tyre._scheme(extended._printers(), extended._startup(), extended._regions());
         Object worship = vessels;
         pensions = vessels.length;

         for(int through = 0; through < pensions; ++through) {
            Object eagle = worship[through];
            Object cheers = trends._period(eagle);
            Object lease = eagle._cotton();
            if (heard._rapid(Tricha._speeds((double)trends._rankings(), (double)trends._bronze(), (double)trends._buffalo())._drink(0.5D, 0.5D, 0.5D)) < heard._rapid(Tricha._speeds((double)cheers._rankings(), (double)cheers._bronze(), (double)cheers._buffalo())._drink(0.5D, 0.5D, 0.5D)) && fairy._plate(new Tylor(cheers._rankings(), cheers._bronze(), cheers._buffalo()))._highway(fairy._knowing(cheers), false).booleanValue()) {
               Object fruits = Tricha._speeds((double)cheers._rankings(), (double)cheers._bronze(), (double)cheers._buffalo())._drink(0.5D, 0.5D, 0.5D)._ultimate(Tricha._speeds((double)lease._latter()._rankings(), (double)lease._latter()._bronze(), (double)lease._latter()._buffalo())._daily(0.5D));
               if (heard._rapid(fruits) <= 18.0D) {
                  if (Alondra._emacs()._teeth(internal, breaks, internal._remains(), Tylor._marsh(cheers), lease, fruits)) {
                     internal._witch()._teddy(Michaeljohn._lloyd());
                     fairy.bebupaze$._cards();
                  }

                  return true;
               }
            }
         }
      } else {
         Object trends = vessels;
         Object worship = vessels.length;

         for(pensions = 0; pensions < worship; ++pensions) {
            Object through = trends[pensions];
            Object eagle = extended._refund(through);
            Object cheers = through._cotton();
            Object lease = heard._rapid(Tricha._speeds((double)extended._printers(), (double)extended._startup(), (double)extended._regions())._drink(0.5D, 0.5D, 0.5D));
            Object cable = heard._rapid(Tricha._speeds((double)eagle._printers(), (double)eagle._startup(), (double)eagle._regions())._drink(0.5D, 0.5D, 0.5D));
            if (lease < cable) {
               Tricha var16 = Tricha._speeds((double)eagle._printers(), (double)eagle._startup(), (double)eagle._regions())._drink(0.5D, 0.5D, 0.5D)._ultimate(Tricha._speeds((double)cheers._prozac(), (double)cheers._pillow(), (double)cheers._younger())._daily(0.5D));
               if (heard._rapid(var16) <= 18.0D) {
                  if (Alondra._emacs()._teeth(internal, breaks, internal._remains(), eagle, cheers, var16)) {
                     internal._witch()._teddy(Michaeljohn._lloyd());
                     fairy.bebupaze$._cards();
                  }

                  return true;
               }
            }
         }
      }

      return false;
   }

   private Tricha _compiler(Tylor eyumelen) {
      Object bodemabo = Alondra._inserted();
      Object famayipu = Tricha._speeds(bodemabo._defining(), bodemabo._opens() + (double)bodemabo._rolling(), bodemabo._dealt());
      Object pededade = Clifford._computer();
      int etesanot;
      if (Benji._orlando() > 13) {
         Object dovivoza = Tyre._scheme(eyumelen._printers(), eyumelen._startup(), eyumelen._regions());
         Object gotivale = pededade;
         etesanot = pededade.length;

         for(int umoyevud = 0; umoyevud < etesanot; ++umoyevud) {
            Object sumeredu = gotivale[umoyevud];
            Object masaboli = dovivoza._period(sumeredu);
            Object polozode = sumeredu._cotton();
            if (famayipu._rapid(Tricha._speeds((double)dovivoza._rankings(), (double)dovivoza._bronze(), (double)dovivoza._buffalo())._drink(0.5D, 0.5D, 0.5D)) < famayipu._rapid(Tricha._speeds((double)masaboli._rankings(), (double)masaboli._bronze(), (double)masaboli._buffalo())._drink(0.5D, 0.5D, 0.5D)) && etaciziy._plate(new Tylor(masaboli._rankings(), masaboli._bronze(), masaboli._buffalo()))._highway(etaciziy._knowing(masaboli), false).booleanValue()) {
               Object izibedac = Tricha._speeds((double)masaboli._rankings(), (double)masaboli._bronze(), (double)masaboli._buffalo())._drink(0.5D, 0.5D, 0.5D)._ultimate(Tricha._speeds((double)polozode._latter()._rankings(), (double)polozode._latter()._bronze(), (double)polozode._latter()._buffalo())._daily(0.5D));
               if (famayipu._rapid(izibedac) <= 18.0D) {
                  return izibedac;
               }
            }
         }
      } else {
         Object dovivoza = pededade;
         Object gotivale = pededade.length;

         for(etesanot = 0; etesanot < gotivale; ++etesanot) {
            Object umoyevud = dovivoza[etesanot];
            Object sumeredu = eyumelen._refund(umoyevud);
            Object masaboli = umoyevud._cotton();
            Object polozode = famayipu._rapid(Tricha._speeds((double)eyumelen._printers(), (double)eyumelen._startup(), (double)eyumelen._regions())._drink(0.5D, 0.5D, 0.5D));
            Object vizifiro = famayipu._rapid(Tricha._speeds((double)sumeredu._printers(), (double)sumeredu._startup(), (double)sumeredu._regions())._drink(0.5D, 0.5D, 0.5D));
            if (polozode < vizifiro) {
               Tricha var15 = Tricha._speeds((double)sumeredu._printers(), (double)sumeredu._startup(), (double)sumeredu._regions())._drink(0.5D, 0.5D, 0.5D)._ultimate(Tricha._speeds((double)masaboli._prozac(), (double)masaboli._pillow(), (double)masaboli._younger())._daily(0.5D));
               if (famayipu._rapid(var15) <= 18.0D) {
                  return var15;
               }
            }
         }
      }

      return null;
   }

   private Tricha _holdings(Tylor devimimu) {
      Tricha vuzosune;
      if ((vuzosune = yigugimo._compiler(devimimu)) == null && (vuzosune = yigugimo._compiler(devimimu._novel(1, 0, 0))) == null && (vuzosune = yigugimo._compiler(devimimu._novel(0, 0, 1))) == null && (vuzosune = yigugimo._compiler(devimimu._novel(-1, 0, 0))) == null) {
         vuzosune = yigugimo._compiler(devimimu._novel(0, 0, -1));
      }

      return vuzosune;
   }

   private float[] _raised(Tricha index) {
      Object spouse = Alondra._inserted();
      Object harder = index._fired() - spouse._defining();
      Object register = index._looking() - (spouse._opens() + (double)spouse._rolling());
      Object fixes = index._larry() - spouse._dealt();
      Object scores = (double)Arnita._donor(harder * harder + fixes * fixes);
      float var11 = (float)Math.toDegrees(Math.atan2(fixes, harder)) - 90.0F;
      float var12 = (float)(-Math.toDegrees(Math.atan2(register, scores)));
      float var13 = spouse._armed() + Arnita._germany(var11 - spouse._armed());
      float var14 = spouse._glasses() + Arnita._germany(var12 - spouse._glasses());
      return new float[]{var13, var14};
   }

   public static boolean _highways(Trinette interval) {
      if (!interval._warner() && !interval._educated()._warner()) {
         return interval._aberdeen().equalsIgnoreCase("tile.cactus") ? false : interval._educated()._gotta(Akeia.cocktail$);
      } else {
         return false;
      }
   }

   private Zavion _knowing(Tyre dogubano) {
      return Alondra._right()._ellen(dogubano);
   }

   public Tang _plate(Tylor davorepu) {
      return Alondra._right()._plant(davorepu._printers(), davorepu._startup(), davorepu._regions());
   }

   public Antoin _patrick(Tylor vendor) {
      return healing._plate(vendor)._folding();
   }

   public static boolean _chester(Trinette iteziton) {
      return iteziton._warner();
   }

   private int _sunny() {
      Object percent = Alondra._inserted();
      Object wines = 0;
      int pressing = 0;

      while(true) {
         boolean var10001 = true;
         if (percent._discs()._compact(pressing)._ports()) {
            Object adequate = percent._discs()._compact(pressing)._monthly();
            Object quarters = adequate._educated();
            if (adequate._educated()._gotta(Akeia.cocktail$) && !worried.oricubim$.contains(quarters._factors())) {
               wines += adequate._targets();
            }
         }

         ++pressing;
      }
   }
}
