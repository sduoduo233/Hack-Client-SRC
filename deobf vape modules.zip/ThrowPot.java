import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class Orrin extends Matthieu {
   private Dusti kodak$ = new Dusti("Both");
   private Dusti rental$ = new Dusti("Pots");
   private Dusti vessels$ = new Dusti("Soup");
   private Franciso cylinder$;
   private Dusti browsing$;
   private Dusti scott$;
   private Franciso flowers$;
   private Dustun tennis$;
   private Ashley annoying$;
   private Ellena requests$;
   private Ellena corner$;
   private Ellena planet$;
   private int hartford$;
   private CopyOnWriteArrayList showers$;
   private boolean postings$;

   public Orrin() {
      super("Throwpot", "Throws or consumes healing items upon pressing keybind");
      montreal.cylinder$ = Franciso._polar(montreal, "Type", montreal.kodak$, montreal.kodak$, montreal.rental$, montreal.vessels$);
      montreal.browsing$ = new Dusti("Dynamic");
      montreal.scott$ = new Dusti("Single");
      montreal.flowers$ = Franciso._capitol(montreal, "Mode", "Dynamic - uses only as many items as needed to heal as much as possible without over-healing\nSingle - Always uses one item, regardless of health", montreal.browsing$, montreal.browsing$, montreal.scott$);
      montreal.tennis$ = Dustun._bright(montreal, "Scroll delay", "#", "ms", 0.0D, 100.0D, 200.0D);
      montreal.annoying$ = Ashley._laptop(montreal, "Delay", "#", "ms", 0.0D, 80.0D, 115.0D, 200.0D);
      montreal.requests$ = Ellena._fitted(montreal, "Scroll", false);
      montreal.corner$ = Ellena._fitted(montreal, "Random", false);
      montreal.planet$ = Ellena._designs(montreal, "Throw bowls", true, "Throws soup bowls after consuming");
      montreal.showers$ = new CopyOnWriteArrayList();
      montreal.requests$._heated(montreal.tennis$);
      montreal._actions(new Albert[]{montreal.cylinder$, montreal.flowers$, montreal.annoying$, montreal.requests$, montreal.tennis$, montreal.corner$, montreal.planet$});
   }

   public void _niger() {
      if (ugadefog.postings$) {
         ugadefog._symphony(false);
      } else {
         Object ipabadir = Alondra._inserted()._ordering();
         ugadefog.hartford$ = ipabadir._products();
         if (ugadefog._johnny()) {
            ugadefog.postings$ = true;
            ugadefog._recorder(0L, false);
         } else {
            ugadefog._symphony(false);
         }

      }
   }

   public void _ghana() {
      ayuyetal.showers$.clear();
   }

   private void _problems(int retailer) {
      if (!carroll.requests$._sounds().booleanValue()) {
         Alondra._inserted()._ordering()._steal(retailer);
      } else {
         int customer = Alondra._inserted()._ordering()._products();

         while(true) {
            Alondra._inserted()._ordering()._steal(customer);

            try {
               Thread.sleep(carroll.tennis$._cingular().longValue());
            } catch (InterruptedException var4) {
               ;
            }

            if (retailer > customer) {
               ++customer;
            } else {
               if (retailer >= customer) {
                  return;
               }

               --customer;
            }
         }
      }
   }

   public void _ruled() {
      if (omabevoc.postings$) {
         Object yonigabi = Alondra._surfaces()._teenage()._performs();
         int nogumere = Alondra._surfaces()._creating()._performs();

         try {
            omabevoc.showers$.sort(new Cindia(omabevoc.hartford$));
            Iterator mepedago = omabevoc.showers$.iterator();

            while(mepedago.hasNext()) {
               Object gelegite = (Tristy)mepedago.next();
               omabevoc._problems(gelegite._mentor());
               Thread.sleep(10L);
               Micholas._lingerie(yonigabi, true);
               Micholas._trace(yonigabi);
               Thread.sleep((long)omabevoc.annoying$._kinds());
               Micholas._lingerie(yonigabi, false);
               if (omabevoc.planet$._sounds().booleanValue() && gelegite._builders()._educated()._gotta(Akeia.david$)) {
                  Micholas._lingerie(nogumere, true);
                  Micholas._trace(nogumere);
                  Thread.sleep((long)omabevoc.annoying$._kinds());
                  Micholas._lingerie(nogumere, false);
               }
            }
         } catch (Exception var5) {
            var5.printStackTrace();
         }

         omabevoc._problems(omabevoc.hartford$);
         omabevoc.postings$ = false;
      }
   }

   public void _tribe(Stormey var1) {
      if (!sipupezu.postings$ && sipupezu._alpha()) {
         sipupezu._symphony(false);
      }

   }

   private boolean _johnny() {
      Object ocelutuz = new ArrayList();
      int erudacac = 0;

      while(true) {
         boolean var10001 = true;
         ocelutuz.add(erudacac);
         ++erudacac;
      }
   }
}
