import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class Maire extends Matthieu {
   private Tang dumugani$;
   private float emovacof$;
   private int isubicof$;
   private int vonorepu$;
   private int rimabari$;
   private Verne culeyeda$ = new Verne();
   private int ocagugev$ = 0;

   public Maire() {
      super("Clutch");
   }

   public void _niger() {
      try {
         Object ivitisac = ofuceyaz._rotation();
         if (ivitisac.isEmpty()) {
            ofuceyaz._adult();
            return;
         }

         Alondra._inserted()._ordering()._steal(((Integer)ivitisac.get(0)).intValue());
         Object vugeyuri = ofuceyaz._download();
         if (vugeyuri == null) {
            ofuceyaz._adult();
            return;
         }

         ofuceyaz.dumugani$ = vugeyuri;
         ofuceyaz.ocagugev$ = 1;
      } catch (Exception var3) {
         var3.printStackTrace();
      }

   }

   public void _ghana() {
      tusafeco.dumugani$ = null;
      tusafeco.isubicof$ = -1;
      tusafeco.vonorepu$ = -1;
      tusafeco.rimabari$ = -1;
      tusafeco.ocagugev$ = 0;
      tusafeco.emovacof$ = 0.0F;
   }

   public void _strings(Neill acubebuv) {
      if (ebaroseb.ocagugev$ == 1) {
         Object emegiguc = ThreadLocalRandom.current().nextFloat() * 1.5F;
         if (ThreadLocalRandom.current().nextFloat() > 0.5F) {
            emegiguc = -emegiguc;
         }

         float var3 = ThreadLocalRandom.current().nextFloat() * 1.5F;
         Maher._mandate(ebaroseb.emovacof$ + emegiguc, 80.0F + var3);
         ebaroseb.ocagugev$ = 2;
         ebaroseb.culeyeda$._cards();
      } else if (ebaroseb.ocagugev$ == 2) {
         Object emegiguc = Alondra._surfaces()._teenage();
         Micholas._lingerie(emegiguc._performs(), true);
         Micholas._trace(emegiguc._performs());
         if (ebaroseb.culeyeda$._basename(50L)) {
            Micholas._lingerie(emegiguc._performs(), false);
            ebaroseb._adult();
         }
      }

   }

   private Tang _download() {
      Object aliralud = Alondra._inserted();
      Object uropufoc = aliralud._cream();
      Object cutunuye = (int)aliralud._defining();
      Object sezatumi = (int)aliralud._opens();
      Object igutanas = (int)aliralud._dealt();
      if (!Tamirra.divine$) {
         --sezatumi;
         --igutanas;
      }

      cibozage.vonorepu$ = sezatumi;
      cibozage.isubicof$ = cutunuye + 1;
      cibozage.rimabari$ = igutanas;
      Object igebasoz = cibozage._trout(uropufoc, cibozage.isubicof$, cibozage.vonorepu$, cibozage.rimabari$);
      if (igebasoz != null) {
         cibozage.emovacof$ = -90.0F;
         return igebasoz;
      } else {
         cibozage.isubicof$ = cutunuye - 1;
         cibozage.rimabari$ = igutanas;
         igebasoz = cibozage._trout(uropufoc, cibozage.isubicof$, cibozage.vonorepu$, cibozage.rimabari$);
         if (igebasoz != null) {
            cibozage.emovacof$ = 90.0F;
            return igebasoz;
         } else {
            cibozage.isubicof$ = cutunuye;
            cibozage.rimabari$ = igutanas + 1;
            igebasoz = cibozage._trout(uropufoc, cibozage.isubicof$, cibozage.vonorepu$, cibozage.rimabari$);
            if (igebasoz != null) {
               cibozage.emovacof$ = 0.0F;
               return igebasoz;
            } else {
               cibozage.isubicof$ = cutunuye;
               cibozage.rimabari$ = igutanas - 1;
               igebasoz = cibozage._trout(uropufoc, cibozage.isubicof$, cibozage.vonorepu$, cibozage.rimabari$);
               if (igebasoz != null) {
                  cibozage.emovacof$ = 180.0F;
                  return igebasoz;
               } else {
                  return null;
               }
            }
         }
      }
   }

   private Tang _trout(Latoy ultimate, int dirty, int reviews, int footwear) {
      Object hills = ultimate._plant(dirty, reviews, footwear);
      return !hills._warner() && !hills._folding()._gotta(Franco._walking()._folding()._science().getClass()) ? hills : null;
   }

   private List _rotation() {
      Object cazozose = new ArrayList();
      Object bamuvivu = Alondra._inserted();
      int tegupiva = 0;

      while(true) {
         boolean var10001 = true;
         Object amovupod = bamuvivu._ordering()._company(tegupiva);
         if (!amovupod._warner() && !amovupod._educated()._warner() && amovupod._educated()._gotta(Akeia.cocktail$)) {
            Object emibubal = amovupod._educated()._science().toString();
            if (!emibubal.contains("Colored") && !emibubal.contains("Lily")) {
               cazozose.add(tegupiva);
            }
         }

         ++tegupiva;
      }
   }
}
