import java.awt.Color;
import java.util.Iterator;
import org.lwjgl.opengl.GL11;

public class Sheronica extends Fanny {
   private Color creative$ = new Color(20, 20, 20, 64);
   private Color accepted$ = new Color(115, 0, 4, 128);
   private Ellena during$;
   private Ellena triumph$;
   private Ellena yourself$;
   private Ellena eminem$;
   private Ellena cialis$;
   private Ellena ambien$;
   private Ellena recipes$;
   private Ellena related$;
   private Ellena everyday$;
   private Ellena create$;
   private Ellena middle$;
   private Ellena leonard$;
   private Dustun fonts$;
   private Nashea general$;
   private Bri[] interact$;
   private Bri[] scanned$;

   public Sheronica() {
      super("NameTags", -16711936, Ayonna.weather$, "Renders nametags on entities through walls.");
      pulisama.during$ = Ellena._designs(pulisama, "Ignore Invisibles", false, "Determines if we draw a nametag\nfor invisible entities");
      pulisama.triumph$ = Ellena._fitted(pulisama, "Render Players", true);
      pulisama.yourself$ = Ellena._fitted(pulisama, "Health", false);
      pulisama.eminem$ = Ellena._fitted(pulisama, "Distance", false);
      pulisama.cialis$ = Ellena._fitted(pulisama, "Equipment", false);
      pulisama.ambien$ = Ellena._fitted(pulisama, "Render Animals", false);
      pulisama.recipes$ = Ellena._fitted(pulisama, "Health", false);
      pulisama.related$ = Ellena._fitted(pulisama, "Distance", false);
      pulisama.everyday$ = Ellena._fitted(pulisama, "Render Mobs", false);
      pulisama.create$ = Ellena._fitted(pulisama, "Health", false);
      pulisama.middle$ = Ellena._fitted(pulisama, "Distance", false);
      pulisama.leonard$ = Ellena._designs(pulisama, "Hide bots", true, "Hides bots if you're using antibot");
      pulisama.fonts$ = Dustun._gentle(pulisama, "Scale", "#.#", "", 0.1D, 1.0D, 1.5D, 0.1D);
      pulisama.general$ = new Nashea(1);
      pulisama.interact$ = new Bri[]{Bri._baths(), Bri._feeds(), Bri._nigeria(), Bri._drawn(), Bri._radius(), Bri._complete(), Bri._dragon(), Bri._managers(), Bri._castle(), Bri._drums(), Bri._charming(), Bri._serve(), Bri._deferred()};
      pulisama.scanned$ = Bri._coupons();
      pulisama.triumph$._heated(pulisama.yourself$, pulisama.eminem$, pulisama.cialis$);
      pulisama.ambien$._heated(pulisama.recipes$, pulisama.related$);
      pulisama.everyday$._heated(pulisama.create$, pulisama.middle$);
      pulisama._actions(new Albert[]{pulisama.during$, pulisama.fonts$, pulisama.leonard$, pulisama.triumph$, pulisama.yourself$, pulisama.eminem$, pulisama.cialis$, pulisama.ambien$, pulisama.recipes$, pulisama.related$, pulisama.everyday$, pulisama.create$, pulisama.middle$});
   }

   public void _senate(Antwan doyizegi) {
      if (!Alondra._right()._warner()) {
         Alondra._inserted();
         Lavetta var3 = doyizegi._lined();
         if (omadobis._winner(var3)) {
            doyizegi._indoor()._walls(true);
         }
      }
   }

   private boolean _winner(Lavetta alevurug) {
      if (Alondra._right()._warner()) {
         return false;
      } else {
         Object inucavuy = Alondra._inserted();
         if (Akeia.whats$ != null && alevurug._gotta(Akeia.whats$)) {
            return false;
         } else if (inucavuy._science().equals(alevurug._science())) {
            return false;
         } else if (Dyesha.banodage$._bookmark()._pacific(alevurug) && epivizan.leonard$._sounds().booleanValue()) {
            return false;
         } else if (!Alondra._right()._lambda().contains(alevurug._science())) {
            return false;
         } else if (alevurug._warner()) {
            return false;
         } else if (!alevurug._gotta(Akeia.shore$)) {
            return false;
         } else if (epivizan.during$._sounds().booleanValue() && alevurug._debian()) {
            return false;
         } else {
            return !alevurug._gotta(Akeia.shipping$) || epivizan.triumph$._sounds().booleanValue();
         }
      }
   }

   void _signup(String nodavate, int obanilif, int enuyenis, double igufebev) {
      Object yicefava = 1.0D / igufebev;
      GL11.glPushMatrix();
      boolean var8 = GL11.glIsEnabled(2896);
      if (var8) {
         GL11.glDisable(2896);
      }

      GL11.glScaled(igufebev, igufebev, igufebev);
      Alondra._examined()._aging(nodavate, (double)obanilif, (double)enuyenis, -1);
      GL11.glScaled(yicefava, yicefava, yicefava);
      if (var8) {
         GL11.glEnable(2896);
      }

      GL11.glPopMatrix();
   }

   private void _katrina(Trinette joshua, int trailers, int dicke) {
      Object theatre = joshua._reminder();
      if (!theatre._warner()) {
         try {
            Object emerging = 0;

            for(int offline = 0; offline < theatre._somerset(); ++offline) {
               Object faces = theatre._state(offline)._support("id");
               Object passion = theatre._state(offline)._support("lvl");
               if (faces < italic.scanned$.length - 1) {
                  Object epinions = italic.scanned$[faces];
                  if (!epinions._warner()) {
                     Object kelly = italic.interact$;
                     Object pools = kelly.length;

                     for(int carter = 0; carter < pools; ++carter) {
                        Object pottery = kelly[carter];
                        if (epinions.equals(pottery)) {
                           Object valid = epinions._forest(passion).substring(0, 1).toLowerCase();
                           if (passion > 99) {
                              valid = valid + "99+";
                           } else {
                              valid = valid + passion;
                           }

                           Object ultram = 0.7D;
                           double var17 = 1.0D / ultram;
                           italic._signup(valid, (int)((double)trailers * var17), (int)((double)(-2 + dicke + emerging) * var17), ultram);
                           emerging += 6;
                           break;
                        }
                     }
                  }
               }
            }
         } catch (Exception var19) {
            ;
         }

      }
   }

   public void _football(Angelicia tarecoyo) {
      Object ubaberog = Alondra._slide()._shared();
      Object moyozipu = Alondra._slide()._cement();
      Object osozezut = Alondra._slide()._explore();
      GL11.glIsEnabled(3042);
      Object efifufiz = Alondra._inserted();
      Iterator oponesim = Alondra._right()._lambda().iterator();

      while(true) {
         Lavetta evuyagob;
         do {
            do {
               if (!oponesim.hasNext()) {
                  return;
               }

               Object esacogis = oponesim.next();
               evuyagob = new Lavetta(esacogis);
            } while(!enaforan._winner(evuyagob));
         } while(!evuyagob._gotta(Akeia.shore$));

         GL11.glPushMatrix();
         Quenna var13 = new Quenna(evuyagob);
         double var14 = var13._bouquet() + (var13._defining() - var13._bouquet()) * (double)tarecoyo._bureau() - ubaberog;
         double var16 = var13._proved() + (var13._opens() - var13._proved()) * (double)tarecoyo._bureau() - moyozipu;
         double var18 = var13._eagle() + (var13._dealt() - var13._eagle()) * (double)tarecoyo._bureau() - osozezut;
         if (evuyagob._gotta(Akeia.shipping$) && enaforan.triumph$._sounds().booleanValue()) {
            enaforan._comments(efifufiz, var13, var14, var16, var18, enaforan.yourself$._sounds().booleanValue(), enaforan.eminem$._sounds().booleanValue(), enaforan.cialis$._sounds().booleanValue());
         } else if (Gared._client(evuyagob) && enaforan.ambien$._sounds().booleanValue()) {
            enaforan._comments(efifufiz, var13, var14, var16, var18, enaforan.recipes$._sounds().booleanValue(), enaforan.related$._sounds().booleanValue(), false);
         } else if (Gared._tickets(evuyagob) && enaforan.everyday$._sounds().booleanValue()) {
            enaforan._comments(efifufiz, var13, var14, var16, var18, enaforan.create$._sounds().booleanValue(), enaforan.middle$._sounds().booleanValue(), false);
         }

         GL11.glPopMatrix();
      }
   }

   public void _reaction(Maxamillion tosiredo, boolean yudociyo, int utomonam) {
      Alondra._bearing()._couples(1.0D);
      Object zufocuta = 1.1D;
      Object yuyomode = 1.0D / zufocuta;
      GL11.glPushMatrix();
      GL11.glScaled(zufocuta, zufocuta, zufocuta);
      Object afafavuv = -5;
      Object bucizofo = -26;
      Object cumogapa = tosiredo._ordering()._salary();
      Object cedofoya = cumogapa;
      int var12 = cumogapa.length;

      for(int var13 = 0; var13 < var12; ++var13) {
         Object var14 = cedofoya[var13];
         if (var14 != null) {
            afafavuv -= 10;
         }
      }

      Marlea._thunder();
      if (!tosiredo._handled()._warner()) {
         afafavuv += 5;
         if (!tosiredo._handled()._educated()._warner()) {
            if (!yudociyo) {
               Alondra._annex()._tested(Alondra._examined(), Alondra._portrait(), Trinette._monetary(tosiredo._handled()._educated()), afafavuv, bucizofo);
            } else {
               Alondra._annex()._woods(Alondra._examined(), Alondra._portrait(), tosiredo._handled(), afafavuv, bucizofo);
               supugeru._katrina(tosiredo._handled(), afafavuv, bucizofo);
            }

            GL11.glEnable(3008);
         }
      }

      afafavuv += 5;

      for(int cedofoya = cumogapa.length - 1; cedofoya > -1; --cedofoya) {
         Trinette var16 = new Trinette(cumogapa[cedofoya]);
         if (!var16._warner()) {
            afafavuv += 15;
            if (!yudociyo) {
               Alondra._annex()._tested(Alondra._examined(), Alondra._portrait(), Trinette._monetary(var16._educated()), afafavuv, bucizofo);
            } else {
               Alondra._annex()._woods(Alondra._examined(), Alondra._portrait(), var16, afafavuv, bucizofo);
               supugeru._katrina(var16, afafavuv, bucizofo);
            }

            GL11.glEnable(3008);
         }
      }

      GL11.glScaled(yuyomode, yuyomode, yuyomode);
      GL11.glPopMatrix();
      Alondra._bearing()._derek(1.0D);
   }

   private void _comments(Maxamillion utucotog, Quenna vatofeve, double tusebore, double seneguto, double nusuzipu, boolean icapifoy, boolean ibucivag, boolean fanuzime) {
      Object fobugula = vatofeve._yemen()._master();
      Object cagegofu = Tamirra.wallace$ + "a" + Tamirra.wallace$ + "r" + fobugula;
      Object iyaviyin = Alondra._examined();
      Alondra._bearing()._couples(1.0D);
      Object ofapapen = vatofeve._gotta(Akeia.shipping$);
      Object uduyeniy = 16777215;
      if (Dyesha.banodage$._bookmark()._queue(vatofeve) && Dyesha.banodage$._assigned().medical$._sounds().booleanValue()) {
         uduyeniy = -12417292;
      }

      if (vatofeve._debian()) {
         uduyeniy = 65530;
      }

      if (ofapapen) {
         Object lirofelu = Dyesha.banodage$._assigned()._church(vatofeve._powder());
         if (lirofelu != null) {
            cagegofu = lirofelu._hidden();
            if (Dyesha.banodage$._assigned().medical$._sounds().booleanValue()) {
               uduyeniy = Dyesha.banodage$._assigned().census$._programs();
            } else {
               Object buvelare = fobugula.toCharArray();
               Object edadivur = fobugula.indexOf(cagegofu);

               for(int goyaduzu = edadivur; goyaduzu > 0; --goyaduzu) {
                  Object yonimiya = buvelare[goyaduzu];
                  if (yonimiya == 167) {
                     yonimiya = buvelare[goyaduzu + 1];
                     Object zegigedo = new String(new char[]{yonimiya});
                     cagegofu = '§' + zegigedo + cagegofu;
                     break;
                  }
               }
            }
         }
      }

      if (ibucivag) {
         cagegofu = Tamirra.wallace$ + "a[" + Tamirra.wallace$ + "f" + (int)utucotog._header(vatofeve) + Tamirra.wallace$ + "a]" + Tamirra.wallace$ + "r " + cagegofu;
      }

      Object lirofelu = vatofeve._notice() ? musosacu.accepted$ : musosacu.creative$;
      if (vatofeve._gotta(Akeia.shipping$)) {
         Object buvelare = new Maxamillion(vatofeve);
         if (buvelare._worker()._doors()) {
            cagegofu = Tamirra.wallace$ + "a[C] " + Tamirra.wallace$ + "r" + cagegofu;
         }
      }

      Object buvelare = (double)(vatofeve._hosted() / 2.0F);
      Object goyaduzu = (double)(vatofeve._clinics() / 2.0F);
      Object zegigedo = 100.0D * (buvelare / goyaduzu);
      String pinirusi;
      if (zegigedo > 75.0D) {
         pinirusi = "2";
      } else if (zegigedo > 50.0D) {
         pinirusi = "e";
      } else if (zegigedo > 25.0D) {
         pinirusi = "6";
      } else {
         pinirusi = "4";
      }

      Object idovofez = musosacu.general$._indiana(Math.floor((buvelare + 0.25D) / 0.5D) * 0.5D);
      if (icapifoy) {
         cagegofu = String.format("%s %s%s%s", cagegofu, Tamirra.wallace$, pinirusi, idovofez);
      }

      Object ozoyolet = utucotog._header(vatofeve);
      Object senumeco = ozoyolet / 5.0F <= 2.0F ? 2.0F : ozoyolet / 5.0F;
      Object oyacemol = (float)(0.01666666753590107D * (double)senumeco * musosacu.fonts$._cingular().doubleValue());
      GL11.glPushMatrix();
      Kriste._leads();
      GL11.glTranslated(tusebore + 0.0D, seneguto + (double)vatofeve._detect() + 0.5D, nusuzipu);
      GL11.glNormal3f(0.0F, 1.0F, 0.0F);
      if (Alondra._surfaces()._neither() == 2) {
         GL11.glRotatef(-Alondra._slide()._gamecube(), 0.0F, 1.0F, 0.0F);
         GL11.glRotatef(Alondra._slide()._finnish(), -1.0F, 0.0F, 0.0F);
      } else {
         GL11.glRotatef(-Alondra._slide()._gamecube(), 0.0F, 1.0F, 0.0F);
         GL11.glRotatef(Alondra._slide()._finnish(), 1.0F, 0.0F, 0.0F);
      }

      GL11.glScalef(-oyacemol, -oyacemol, oyacemol);
      Marlea._thunder();
      Marlea._entry(false);
      Marlea._franklin();
      Marlea._linda();
      Marlea._planners(770, 771, 1, 0);
      Object delagove = iyaviyin._enabling(cagegofu) / 2;
      int var30 = -(iyaviyin._pursue(cagegofu) - 1);
      Marlea._thunder();
      Shakeema._defence((double)(-delagove) - 2.0D, (double)var30, (double)delagove + 2.0D, 2.0D, lirofelu);
      Marlea._lycos();
      iyaviyin._firmware(cagegofu, (double)(-delagove), (double)(var30 + 2), uduyeniy);
      if (fanuzime) {
         GL11.glPushMatrix();
         if (vatofeve._gotta(Akeia.shipping$)) {
            Maxamillion var31 = new Maxamillion(vatofeve);
            GL11.glPushMatrix();
            if (Benji._orlando() > 13) {
               float var32 = -110.0F;
               float var33 = Alondra._annex()._shorts();
               if (var33 != 0.0F) {
                  var32 -= var33 + 20.0F;
               }

               GL11.glTranslated(0.0D, 0.0D, (double)var32);
            }

            musosacu._reaction(var31, false, (int)senumeco);
            GL11.glPopMatrix();
            musosacu._reaction(var31, true, (int)senumeco);
         }

         GL11.glPopMatrix();
      }

      Marlea._maker();
      Marlea._villa();
      Marlea._entry(true);
      Marlea._maker();
      Marlea._bedding();
      Marlea._lance(1.0F, 1.0F, 1.0F, 1.0F);
      Kriste._amend();
      GL11.glPopMatrix();
      Alondra._bearing()._derek(1.0D);
   }
}
