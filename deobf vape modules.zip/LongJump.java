public class Sareena extends Fanny {
   private double doconola$;
   private double tufataye$;
   private boolean egabomom$;
   private boolean ecalerac$;
   private Dustun itevodiv$;
   private Ellena sovesoyo$;

   public Sareena() {
      super("LongJump", 16028225, Ayonna.lyrics$, "Do a jump that's long.");
      ragesoro.itevodiv$ = Dustun._bright(ragesoro, "Boost", "#.#", "", 3.0D, 4.1D, 5.0D);
      ragesoro.sovesoyo$ = Ellena._designs(ragesoro, "Toggle", true, "Toggles off after touching the ground.");
      ragesoro._actions(new Albert[]{ragesoro.itevodiv$, ragesoro.sovesoyo$});
      ragesoro.doconola$ = 0.27999999999999997D;
      ragesoro.ecalerac$ = false;
      ragesoro.tufataye$ = 0.0D;
   }

   public void _niger() {
      Dyesha.banodage$._bookmark()._colony(obesity);
      obesity.doconola$ = 0.27999999999999997D;
      obesity.ecalerac$ = false;
      obesity.tufataye$ = 0.0D;
      obesity.egabomom$ = false;
   }

   public void _earliest(Quanesha types) {
      if (types._adaptor()) {
         Object spare = Alondra._inserted();
         if ((spare._trouble() != 0.0F || spare._employer() != 0.0F) && !spare._cream()._warner() && !spare._shannon()) {
            if (spare._cases()) {
               if (!stupid.ecalerac$ && spare._themes() >= -0.3D) {
                  stupid.doconola$ = stupid.itevodiv$._cingular().doubleValue() * 0.27999999999999997D;
               } else {
                  stupid.doconola$ *= 2.15D - 1.0D / Math.pow(10.0D, 5.0D);
                  spare._problem(0.4128938479875198D);
                  types._battery(0.4128938479875198D);
                  spare._normal(true);
               }
            } else if (stupid.ecalerac$) {
               if (stupid.tufataye$ < 2.147D) {
                  stupid.tufataye$ = 2.147D;
               }

               stupid.doconola$ = stupid.tufataye$ - 0.66D * (stupid.tufataye$ - 0.27999999999999997D);
            } else {
               stupid.doconola$ = stupid.tufataye$ - stupid.tufataye$ / 155.0D;
            }

            stupid.ecalerac$ = spare._cases();
            stupid.doconola$ = Math.max(stupid.doconola$, 0.27999999999999997D);
            types._serves(-(Math.sin((double)stupid._stones(spare)) * stupid.doconola$));
            types._deposits(Math.cos((double)stupid._stones(spare)) * stupid.doconola$);
         } else {
            stupid.doconola$ = 0.27999999999999997D;
         }
      }
   }

   public void _retailer(Chikita autumn) {
      if (autumn._latin() == Desirre.barrier$) {
         Object lawyer = Alondra._inserted();
         crops.tufataye$ = Math.hypot(lawyer._defining() - lawyer._moral(), lawyer._dealt() - lawyer._routines());
         if (crops.sovesoyo$._sounds().booleanValue()) {
            if (!crops.ecalerac$ && lawyer._cases() && crops.egabomom$) {
               crops._adult();
            }

            if (!crops.egabomom$ && crops._formula(lawyer)) {
               crops.egabomom$ = true;
            }
         }
      }

   }

   private float _stones(Tempess gedapedi) {
      Object lovelola = gedapedi._armed();
      if (gedapedi._trouble() < 0.0F) {
         lovelola += 180.0F;
      }

      float atitotis;
      if (gedapedi._trouble() < 0.0F) {
         atitotis = -0.5F;
      } else if (gedapedi._trouble() > 0.0F) {
         atitotis = 0.5F;
      } else {
         atitotis = 1.0F;
      }

      if (gedapedi._employer() > 0.0F) {
         lovelola -= 90.0F * atitotis;
      }

      if (gedapedi._employer() < 0.0F) {
         lovelola += 90.0F * atitotis;
      }

      lovelola *= 0.017453292F;
      return lovelola;
   }

   private boolean _formula(Tempess plain) {
      Object victor = Alondra._surfaces();
      return victor._emission()._autos() || victor._swingers()._autos() || victor._stars()._autos() || victor._interval()._autos() || plain._instance()._recall() != 0.0F || plain._instance()._chains() != 0.0F;
   }
}
