public class Giana extends Fanny {
   private Sachin bufigena$;

   public Giana() {
      super("Sprint", -16711796, Ayonna.resource$, "Sets your sprinting to true.");
   }

   public void _realtor(Thorn var1) {
      if (michigan.bufigena$ == null) {
         michigan.bufigena$ = (Sachin)Dyesha.banodage$._provider()._dynamic(Sachin.class);
      }

      if (Alondra._position()._warner()) {
         if (!michigan.bufigena$._brisbane() && !Alondra._surfaces()._finder()._workshop() && !Alondra._inserted()._airports() && !Alondra._inserted()._malawi()) {
            Micholas._lingerie(Alondra._surfaces()._finder()._performs(), true);
         } else {
            Micholas._lingerie(Alondra._surfaces()._finder()._performs(), false);
         }

      }
   }

   public void _ghana() {
      Micholas._lingerie(Alondra._surfaces()._finder()._performs(), false);
   }
}
