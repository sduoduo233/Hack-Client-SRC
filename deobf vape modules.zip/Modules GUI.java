import java.util.ArrayList;
import java.util.List;

public class Ayonna implements Jenniffer {
   public static Ayonna switched$ = new Ayonna("Other", -14385007);
   public static Ayonna singing$ = new Ayonna("None", -2914273);
   public static Ayonna resource$ = new Ayonna("Combat", -2745594);
   public static Ayonna shield$ = new Ayonna("Utility", -14970556);
   public static Ayonna weather$ = new Ayonna("Render", "All kinds of visual goodies", -7926107);
   public static Ayonna lyrics$ = new Ayonna("Blatant", "Modules which are typically used for blatant cheaters", -2419323);
   public static Ayonna pointer$ = new Ayonna("World", -12170992);
   private static List temple$ = new ArrayList();
   private String heaven$;
   private String credits$;
   private int beside$;

   private Ayonna(String sugeseli, String ogoliray, int oyaruyav) {
      banodifi.heaven$ = sugeseli;
      banodifi.credits$ = ogoliray;
      banodifi.beside$ = oyaruyav;
   }

   private Ayonna(String domubilu, int dapiruzi) {
      this(domubilu, "", dapiruzi);
   }

   public static List _strong() {
      return temple$;
   }

   public static void _budgets() {
      temple$.clear();
      temple$ = null;
      switched$ = null;
      singing$ = null;
      resource$ = null;
      shield$ = null;
      weather$ = null;
      lyrics$ = null;
      pointer$ = null;
   }

   public String _nations() {
      return odovimen.heaven$;
   }

   public String toString() {
      return yatodize.heaven$;
   }

   public int _blake() {
      return orisucuz.beside$;
   }

   public String _delete() {
      return ruvobavi.credits$;
   }

   static {
      temple$.add(lyrics$);
      temple$.add(resource$);
      temple$.add(singing$);
      temple$.add(switched$);
      temple$.add(weather$);
      temple$.add(shield$);
      temple$.add(pointer$);
   }
}
