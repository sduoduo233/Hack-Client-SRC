import java.util.ArrayList;
import java.util.Collections;

public class Umair extends Fanny {
   private Ellena etiruvot$;
   private Ellena gopomupi$;
   private Ellena picotadi$;
   private Ashley relozime$;
   private Tashenna icoyoyip$;
   private Verne acileyop$;

   public Umair() {
      super("ChestSteal", -208, Ayonna.pointer$, "Take items upon opening a chest");
      vofatada.etiruvot$ = Ellena._designs(vofatada, "Check in Menu", false, "This will attempt to ignore Menus such as\nServer selectors, and settings inventory menus\nThis may not work 100% on all servers");
      vofatada.gopomupi$ = Ellena._designs(vofatada, "Keep open", false, "Keep chest open after clearing");
      vofatada.picotadi$ = Ellena._designs(vofatada, "Shuffle", false, "Take items in a random order");
      vofatada.relozime$ = Ashley._laptop(vofatada, "Click Delay", "#", "", 0.0D, 75.0D, 125.0D, 300.0D);
      vofatada.icoyoyip$ = Tashenna._mother(vofatada, "cheatsteal-blacklisted", "Blacklisted", Tashenna.botizide$, Collections.emptyList());
      vofatada.acileyop$ = new Verne();
      vofatada._actions(new Albert[]{vofatada.etiruvot$, vofatada.gopomupi$, vofatada.picotadi$, vofatada.relozime$, vofatada.icoyoyip$});
   }

   public void _strings(Neill nalezevu) {
      if (Alondra._position()._gotta(Akeia.combine$)) {
         Object afivalil = new Carri(Alondra._position());
         if (puvofimo.etiruvot$._sounds().booleanValue() && !puvofimo._water(afivalil)) {
            return;
         }

         if (!puvofimo.gopomupi$._sounds().booleanValue() && puvofimo._needle()) {
            Alondra._inserted()._lighting();
            return;
         }

         Object yecidovi = new ArrayList();
         Object lefonele = afivalil._carnival();

         for(int eyuneled = 0; eyuneled < lefonele._finish(); ++eyuneled) {
            Trinette var6 = lefonele._reaches(eyuneled);
            if (!var6._warner() && !var6.toString().contains("tile.air") && !puvofimo.icoyoyip$._cultures(var6, true)) {
               yecidovi.add(eyuneled);
            }
         }

         if (!yecidovi.isEmpty()) {
            if (puvofimo.picotadi$._sounds().booleanValue()) {
               Collections.shuffle(yecidovi);
            }

            if (puvofimo.acileyop$._basename((long)Nazario._delivers(puvofimo.relozime$))) {
               Alondra._emacs()._worst(afivalil._sector()._spoken(), ((Integer)yecidovi.get(0)).intValue(), 0, 1, Alondra._inserted());
               Alondra._emacs()._worst(afivalil._sector()._spoken(), ((Integer)yecidovi.get(0)).intValue(), 0, 1, Alondra._inserted());
               puvofimo.acileyop$._cards();
            }
         } else if (!puvofimo.gopomupi$._sounds().booleanValue()) {
            Alondra._inserted()._lighting();
         }
      }

   }

   private boolean _water(Carri motion) {
      Object latino = motion._carnival();
      Object develop = motion._carnival()._wants();
      return !latino._restrict() || develop.equalsIgnoreCase(Juana._austria("container.chest")._governor().toLowerCase());
   }

   private boolean _handles(Carri resident) {
      Object maximize = resident._carnival();

      for(int portugal = 0; portugal <= maximize._finish(); ++portugal) {
         Object poster = maximize._reaches(portugal);
         if (!poster._warner() && !country.icoyoyip$._please(poster)) {
            return false;
         }
      }

      return true;
   }

   private boolean _needle() {
      Object engage = Alondra._inserted()._discs();
      int jeans = 9;

      while(true) {
         boolean var10001 = true;
         Object viewers = engage._compact(jeans)._monthly();
         if (viewers._warner() || viewers.toString().contains("tile.air")) {
            return false;
         }

         ++jeans;
      }
   }
}
