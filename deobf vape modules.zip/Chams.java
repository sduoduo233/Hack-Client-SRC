import com.google.common.collect.Lists;
import java.awt.Color;
import java.util.ArrayList;
import org.lwjgl.opengl.GL11;

public class Jordache extends Fanny {
   private Ellena specify$;
   private Ellena blond$;
   private Ricahrd generous$;
   private Ellena among$;
   private Ricahrd directly$;
   private boolean arrive$;
   private Quenna hebrew$;
   private int cradle$;

   public Jordache() {
      super("Chams", -16711936, Ayonna.weather$, "Render players through walls.");
      measure.specify$ = Ellena._designs(measure, "Hide Bots", false, "Doesn't apply chams on bots.");
      measure.blond$ = Ellena._designs(measure, "Colored", false, "Colors entities.");
      measure.generous$ = Ricahrd._strike(measure, "Visible Color", new Color(255, 0, 0));
      measure.among$ = Ellena._designs(measure, "Color Behind Walls", true, "Renders a different color when\nplayers are behind walls.");
      measure.directly$ = Ricahrd._strike(measure, "Invisible Color", new Color(255, 255, 0));
      measure._actions(new Albert[]{measure.specify$, measure.blond$._heated(measure.generous$, measure.among$._heated(measure.directly$)), measure.generous$, measure.among$, measure.directly$});
   }

   public void _aware(Cathern micayege) {
      if (!micayege._hence()._gotta(Akeia.yearly$)) {
         Object ebalapod = (Marki)micayege._indoor();
         if (cobuvutu.arrive$) {
            if (!Alondra._right()._warner()) {
               micayege._indoor()._walls(true);
               ebalapod._hardware(false);
               ebalapod._bufing(false);
               ebalapod._urgent(false);
            }
         }
      }
   }

   public void _senate(Antwan udofibeb) {
      if (podalada.arrive$) {
         if (!Alondra._right()._warner()) {
            Object utucagon = Alondra._inserted();
            Object idusitov = udofibeb._lined();
            if (!idusitov.equals(utucagon)) {
               udofibeb._indoor()._walls(true);
            }
         }
      }
   }

   public void _nitrogen(Mecaela relate) {
      if (humidity.arrive$) {
         if (Alondra._right()._warner()) {
            return;
         }

         Object gallery = (Geovanny)relate._indoor();
         gallery._spies(0);
      }

   }

   public void _bacon(Ceasar cycle) {
      if (cycle._expedia()._gotta(Akeia.shipping$) && !cycle._expedia()._gotta(Akeia.yearly$) && courses.blond$._sounds().booleanValue() && courses.arrive$) {
         if (courses.cradle$ == 1) {
            Shakeema._google(courses.among$._sounds().booleanValue() ? courses.directly$._depends() : courses.generous$._depends());
         }

         if (courses.cradle$ == 2) {
            Shakeema._google(courses.generous$._depends());
         }
      }

   }

   public void _ascii(Calin affairs) {
      if (!Dyesha.banodage$._bookmark()._pacific(affairs._holders()) || !smoke.specify$._sounds().booleanValue()) {
         Object occur = (Tamario)Dyesha.banodage$._provider()._dynamic(Tamario.class);
         if (!smoke.arrive$ && smoke.cradle$ != 3 && (!occur._alpha() || !occur._shopping())) {
            if (!smoke.blond$._sounds().booleanValue()) {
               if (affairs._holders()._gotta(Akeia.shipping$) && !affairs._holders()._gotta(Akeia.yearly$)) {
                  GL11.glEnable(32823);
                  GL11.glPolygonOffset(1.0F, -1100000.0F);
               }
            } else if (affairs._holders()._trustees() && affairs._stage()._trustees() && !affairs._holders()._gotta(Akeia.yearly$)) {
               if (Benji._orlando() == 13) {
                  affairs._indoor()._walls(true);
               }

               Object israel = affairs._holders();
               Object merry = israel._bouquet() + (israel._defining() - israel._bouquet()) * (double)affairs._engaged() - Alondra._slide()._shared();
               Object bryan = israel._proved() + (israel._opens() - israel._proved()) * (double)affairs._engaged() - Alondra._slide()._cement();
               Object instance = israel._eagle() + (israel._dealt() - israel._eagle()) * (double)affairs._engaged() - Alondra._slide()._explore();
               float var10 = israel._triangle() + (israel._armed() - israel._triangle()) * affairs._engaged();
               GL11.glPushMatrix();
               GL11.glDisable(2929);
               GL11.glDisable(3553);
               Marlea._thunder();
               Shakeema._google(smoke.among$._sounds().booleanValue() ? smoke.directly$._depends() : smoke.generous$._depends());
               ArrayList var11 = null;
               if (Benji._orlando() > 13) {
                  var11 = Lists.newArrayList(affairs._stage()._closest());
                  affairs._stage()._closest().clear();
               }

               try {
                  smoke.arrive$ = true;
                  smoke.cradle$ = 1;
                  affairs._stage()._spectrum(israel, merry, bryan, instance, var10, affairs._engaged());
               } catch (Exception var14) {
                  ;
               }

               smoke.arrive$ = false;
               GL11.glEnable(2929);
               GL11.glEnable(3553);
               if (Benji._orlando() == 13) {
                  smoke.cradle$ = 3;
                  GL11.glPushMatrix();
                  GL11.glEnable(2896);
                  affairs._stage()._spectrum(israel, merry, bryan, instance, var10, affairs._engaged());
                  GL11.glDepthMask(false);
                  GL11.glDisable(2896);
                  GL11.glPopMatrix();
               }

               smoke.arrive$ = true;
               Shakeema._google(smoke.generous$._depends());
               GL11.glDisable(3553);

               try {
                  smoke.cradle$ = 2;
                  affairs._stage()._spectrum(israel, merry, bryan, instance, var10, affairs._engaged());
                  smoke.arrive$ = false;
               } catch (Exception var13) {
                  ;
               }

               if (Benji._orlando() > 13) {
                  affairs._stage()._carlos(var11);
               }

               GL11.glEnable(3553);
               GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
               Marlea._maker();
               GL11.glPopMatrix();
               smoke.cradle$ = -1;
               if (!israel._debian()) {
                  smoke.hebrew$ = israel;
                  israel._logical(true);
               }
            }

         }
      }
   }

   public void _supreme(Porshe yirumasi) {
      if (!Dyesha.banodage$._bookmark()._pacific(yirumasi._handmade()) || !topofese.specify$._sounds().booleanValue()) {
         if (topofese.blond$._sounds().booleanValue()) {
            if (topofese.hebrew$ != null) {
               Object ocugufay = yirumasi._handmade();
               ocugufay._logical(false);
               topofese.hebrew$ = null;
            }

         } else {
            if (yirumasi._handmade()._gotta(Akeia.shipping$) && !yirumasi._handmade()._gotta(Akeia.yearly$)) {
               GL11.glDisable(32823);
               GL11.glPolygonOffset(1.0F, 1100000.0F);
            }

         }
      }
   }
}
