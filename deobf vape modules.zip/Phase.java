import java.awt.Color;

public class Dorene extends Fanny {
   private Devonte asigudoy$;
   private Franciso cegividi$;

   public Dorene() {
      super("Phase", (new Color(73, 208, 176)).getRGB(), Ayonna.lyrics$, "Phase/Clip through walls.");
      tegamuva.asigudoy$ = new Devonte("Hypixel", new Sigourney(tegamuva, "Hypixel"));
      tegamuva.cegividi$ = Franciso._polar(tegamuva, "Phase Mode", tegamuva.asigudoy$, tegamuva.asigudoy$);
      tegamuva._actions(new Albert[]{tegamuva.cegividi$});
   }

   public boolean _industry() {
      return true;
   }

   public void _evidence(Loma var1) {
   }

   public void _retailer(Chikita udapubut) {
      ogizayur._roster(ogizayur.cegividi$._young()._nations());
      ogizayur.asigudoy$._knife()._retailer(udapubut);
   }

   public void _cabinets(Alesia izusegum) {
      if (izusegum._weblog().toString().toUpperCase().equals("BLOCK")) {
         izusegum._server()._walls(true);
      }

   }
}
