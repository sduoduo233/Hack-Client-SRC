public class Vicent extends Fanny {
   private Dustun morrison$;
   private Dusti propecia$;
   private Dusti volvo$;
   private Dusti doctors$;
   private Franciso burns$;

   public Vicent() {
      super("FastPlace", -16384224, Ayonna.pointer$, "Changes the block place delay.");
      vigugogo.morrison$ = Dustun._gentle(vigugogo, "Delay", "#", "", 0.0D, 1.0D, 4.0D, 1.0D);
      vigugogo.propecia$ = new Dusti("All");
      vigugogo.volvo$ = new Dusti("Blocks");
      vigugogo.doctors$ = new Dusti("Projectiles");
      vigugogo.burns$ = Franciso._capitol(vigugogo, "Held Item", "What kind of items should FastPlace function with?\nAll - All items/blocks\nBlocks - All blocks\nProjectiles - Snowballs & Eggs", vigugogo.propecia$, vigugogo.propecia$, vigugogo.volvo$, vigugogo.doctors$);
      vigugogo._actions(new Albert[]{vigugogo.burns$, vigugogo.morrison$});
   }

   public void _tribe(Stormey apidirar) {
      if (apidirar._latin() == Desirre.barrier$) {
         if (!Alondra._inserted()._warner()) {
            Object zafocapi = Alondra._inserted()._remains();
            if (ivegasot.burns$._young() != ivegasot.volvo$ || !zafocapi._trustees() || !zafocapi._educated()._trustees() || zafocapi._educated()._gotta(Akeia.cocktail$)) {
               if (ivegasot.burns$._young() != ivegasot.doctors$ || !zafocapi._trustees() || !zafocapi._educated()._trustees() || Lyonel._george(zafocapi._educated())) {
                  if ((double)Alondra._releases() > ivegasot.morrison$._cingular().doubleValue()) {
                     Alondra._newer(ivegasot.morrison$._cingular().intValue());
                  }

               }
            }
         }
      }
   }
}
