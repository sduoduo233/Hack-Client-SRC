import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import org.lwjgl.opengl.GL11;

public class Ever extends Fanny {
   private List lisebipo$ = new ArrayList();
   private Deepak eziyarig$;
   private CopyOnWriteArrayList modeveyu$ = new CopyOnWriteArrayList();
   private Kenosha izugipen$;
   private Kenosha efayulib$;
   private Dustun iriraved$;
   private Dustun yodadute$;
   private Ellena utibubus$;

   public Ever() {
      super("Search", -16737793, Ayonna.singing$, "Draws outline around selected blocks\nAdd blocks in Search frame");
      aspects.iriraved$ = Dustun._gentle(aspects, "Range", "#", "", 1.0D, 50.0D, 100.0D, 1.0D);
      aspects.yodadute$ = Dustun._gentle(aspects, "-", "-", "-", 5.0D, 5.0D, 5.0D, 1.0D);
      aspects.utibubus$ = Ellena._designs(aspects, "Only caves", false, "Only looks for ores exposed to air");
      aspects.eziyarig$ = Alondra._slide();
      aspects._actions(new Albert[]{aspects.iriraved$, aspects.utibubus$});
      ((Keslie)aspects.utibubus$._columbus())._fancy(new Mendel(aspects));
   }

   public void _injuries(Danessa vurageyu) {
      adimodos.lisebipo$.add(vurageyu);
   }

   public void _spanish(Danessa invest) {
      mario.lisebipo$.remove(invest);
      Iterator teens = mario.modeveyu$.iterator();

      while(teens.hasNext()) {
         Object regions = (Quinetta)teens.next();
         if (invest._frames() == regions.economic$) {
            mario.modeveyu$.remove(regions);
         }
      }

   }

   public void _football(Angelicia prepare) {
      Alondra._bearing()._couples(1.0D);
      GL11.glPushMatrix();
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glLineWidth(1.5F);
      GL11.glDisable(3553);
      GL11.glEnable(2848);
      GL11.glDisable(2929);
      GL11.glDepthMask(false);
      Object bridal = Alondra._inserted();
      Object profile = prizes.eziyarig$._shared();
      Object purposes = prizes.eziyarig$._cement();
      Object decade = prizes.eziyarig$._explore();
      Iterator var9 = prizes.modeveyu$.iterator();

      while(var9.hasNext()) {
         Quinetta var10 = (Quinetta)var9.next();
         double var11 = Gared._sleep(bridal, (double)var10.infected$, (double)var10.admit$, (double)var10.median$);
         if (var11 <= prizes.iriraved$._cingular().doubleValue()) {
            Taci._granted(var10, profile, purposes, decade);
         } else if (var11 > prizes.iriraved$._cingular().doubleValue() + 10.0D) {
            prizes.modeveyu$.remove(var10);
         }
      }

      GL11.glDepthMask(true);
      GL11.glEnable(2929);
      GL11.glEnable(3553);
      GL11.glDisable(2848);
      GL11.glDisable(3042);
      GL11.glPopMatrix();
      Alondra._bearing()._derek(1.0D);
   }

   public void _niger() {
      munich.izugipen$ = new Kenosha(munich.modeveyu$, munich.lisebipo$, munich.iriraved$);
      munich.izugipen$._plane();
      munich.efayulib$ = new Kenosha(munich.modeveyu$, munich.lisebipo$, munich.yodadute$);
      munich.efayulib$._plane();
   }

   public void _ghana() {
      uzoresas.izugipen$._storm();
      uzoresas.efayulib$._storm();
      uzoresas.modeveyu$.clear();
   }

   static Kenosha _trust(Ever oveligid) {
      return oveligid.izugipen$;
   }

   static Ellena _entities(Ever arivelon) {
      return arivelon.utibubus$;
   }

   static Kenosha _anime(Ever cizurega) {
      return cizurega.efayulib$;
   }
}
