import org.lwjgl.input.Mouse;

public class Mirza extends Fanny {
   public Mirza() {
      super("AutoTool", 6485058, Ayonna.pointer$, "Automatically swaps your hand to the appropriate tool.");
   }

   public void _ruled() {
      if (!Alondra._ranges()._warner() && Mouse.isButtonDown(0) && !Alondra._position()._trustees()) {
         Object benedeto = Alondra._ranges();
         boolean var10001;
         if (benedeto._pensions()._warner() && !benedeto._laugh().equals(Danial._potato())) {
            Object gasunume = benedeto._operator();
            Object ayarusan = 1.0F;
            Object areyemun = true;
            Object oziridiy = Alondra._inserted()._discs();
            int ripelapo = 44;

            while(true) {
               var10001 = true;
               Object ugufizer = oziridiy._compact(ripelapo)._monthly();
               if (!ugufizer._warner()) {
                  Object mamoduga = ugufizer._gardens(benedeto._space(), benedeto._weblogs(), benedeto._trading());
                  Object poramoru = ugufizer._educated();
                  if (poramoru._trustees() && poramoru._gotta(Akeia.titanium$)) {
                     Object uvapemiz = new Liliano(poramoru);
                     if (uvapemiz._probably().equals(Thorin._casino())) {
                        mamoduga = 1.5F;
                     }
                  }

                  if (mamoduga > ayarusan) {
                     ayarusan = mamoduga;
                  }
               }

               --ripelapo;
            }
         }

         if (benedeto._pensions()._trustees()) {
            Object gasunume = 1.0F;
            Object ayarusan = true;
            Object areyemun = Alondra._inserted()._discs();
            int oziridiy = 44;

            while(true) {
               var10001 = true;
               Object ripelapo = areyemun._compact(oziridiy)._monthly();
               if (!ripelapo._warner()) {
                  Object ugufizer = (float)Tamirra._tried(ripelapo);
                  if (ugufizer > gasunume) {
                     gasunume = ugufizer;
                  }
               }

               --oziridiy;
            }
         }

      }
   }

   public void _niger() {
      track._recorder(50L, true);
   }
}
