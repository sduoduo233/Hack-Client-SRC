public class Denyce extends Fanny {
   private boolean princess$;

   public Denyce() {
      super("PotionSaver", -256, Ayonna.lyrics$, "Saves your potion effect(s) duration when standing still");
   }

   public boolean _industry() {
      return true;
   }

   public void _peoples(Lakita afosalib) {
      Object lazosidu = Alondra._inserted();
      if (lazosidu._trustees() && !lazosidu._imagine().isEmpty() && !ulaberid._peace(lazosidu) && (lazosidu._series() || lazosidu._cases())) {
         if (afosalib._seventh()._gotta(Akeia.pubmed$)) {
            ulaberid.princess$ = true;
            afosalib._angeles(true);
         }
      } else {
         ulaberid.princess$ = false;
      }

   }

   private boolean _peace(Tempess mayofida) {
      return mayofida._protocol() != 0.0D || mayofida._blend() != 0.0D;
   }

   public int _finding() {
      return benufesi.princess$ ? -256 : Nida._ozone(160);
   }
}
