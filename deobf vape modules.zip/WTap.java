import java.util.Random;
import org.lwjgl.input.Keyboard;

public class Marcelo extends Fanny {
   private boolean offer$;
   private Dustun shows$;
   private Ashley single$;
   private Random fever$;

   public Marcelo() {
      super("WTap", -5632000, Ayonna.resource$);
      rulatepi.shows$ = Dustun._bright(rulatepi, "Range", "#.#", "", 0.0D, 3.5D, 6.0D);
      rulatepi.single$ = Ashley._laptop(rulatepi, "Delay", "#.#", "", 0.0D, 90.0D, 120.0D, 1000.0D);
      rulatepi.fever$ = new Random();
      rulatepi._actions(new Albert[]{rulatepi.shows$, rulatepi.single$});
   }

   private void _lasting() {
      if (!Alondra._right()._warner()) {
         Object amafevem = Alondra._surfaces()._emission()._performs();
         Object icenatit = Keyboard.isKeyDown(amafevem);
         Object oyovuned = Gared._geneva(egunazol.shows$._cingular().doubleValue(), 0.0F);
         Object zotibatu = Alondra._inserted();
         if (Alondra._position()._warner()) {
            if (zotibatu._similar()) {
               if (oyovuned != null && !oyovuned._warner()) {
                  if (oyovuned._gotta(Akeia.mapping$)) {
                     if (Dyesha.banodage$._bookmark()._write(oyovuned, false)) {
                        if (Gared._youth(zotibatu, oyovuned, 120.0D)) {
                           if (icenatit) {
                              if ((double)zotibatu._header(oyovuned) < egunazol.shows$._cingular().doubleValue()) {
                                 boolean efovuzod = zotibatu._instance()._recall() > 0.0F;

                                 try {
                                    ;
                                 } catch (InterruptedException var7) {
                                    var7.printStackTrace();
                                 }
                              }

                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   public void _niger() {
      if (!micevipe.offer$) {
         micevipe.offer$ = true;
         (new Travonne(micevipe)).start();
      }

   }

   static void _teachers(Marcelo vadodumu) {
      vadodumu._lasting();
   }
}
