import java.awt.Color;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import org.lwjgl.opengl.GL11;

public class Fortunato extends Fanny {
   private List carrying$ = new CopyOnWriteArrayList();
   private List charlie$ = new CopyOnWriteArrayList();
   public Deepak bother$;
   private Ellena rebecca$;
   private int sierra$;

   public Fortunato() {
      super("Blink", 8919359, Ayonna.lyrics$, "Chokes packets until disabled.");
      utomapir.rebecca$ = Ellena._designs(utomapir, "Breadcrumbs", false, "Drops breadcrumbs in case you forgot where you came from.");
      utomapir.bother$ = Alondra._slide();
   }

   public boolean _industry() {
      return true;
   }

   public void _football(Angelicia midlands) {
      if (!roses.charlie$.isEmpty()) {
         Alondra._bearing()._couples(1.0D);
         GL11.glPushMatrix();
         GL11.glEnable(3042);
         GL11.glBlendFunc(770, 771);
         GL11.glLineWidth(1.5F);
         GL11.glDisable(3553);
         GL11.glEnable(2848);
         GL11.glDisable(2929);
         GL11.glDepthMask(false);
         Object wishing = roses.bother$._shared();
         Object glasgow = roses.bother$._cement();
         Object execute = roses.bother$._explore();

         Corrin var9;
         Color var10;
         for(Iterator var8 = roses.charlie$.iterator(); var8.hasNext(); Taci._chess(var9.vutacici$ - 0.025D, var9.nubitecu$ - 0.025D, var9.yomimido$ - 0.025D, 0.05D, 0.05D, 0.05D, 0.0D, Color.WHITE, var10, wishing, glasgow, execute)) {
            var9 = (Corrin)var8.next();
            var10 = Color.WHITE;
            if (var9 == roses.charlie$.get(0)) {
               var10 = Color.GREEN;
            }
         }

         GL11.glDepthMask(true);
         GL11.glEnable(2929);
         GL11.glEnable(3553);
         GL11.glDisable(2848);
         GL11.glDisable(3042);
         GL11.glPopMatrix();
         Alondra._bearing()._derek(1.0D);
      }
   }

   public void _peoples(Lakita hostel) {
      Object teeth = hostel._seventh();
      if (!teeth._science().getClass().toString().contains("play.server") && !teeth._science().toString().contains("SPacket")) {
         if (!teeth._gotta(Akeia.shapes$)) {
            if (teeth._gotta(Akeia.pubmed$) && !tells._animal()) {
               hostel._angeles(true);
            } else {
               if (teeth._gotta(Akeia.pubmed$)) {
                  ++tells.sierra$;
                  if (tells.sierra$ >= 5) {
                     Object point = Alondra._inserted();
                     tells.charlie$.add(new Corrin(point._defining(), point._opens(), point._dealt()));
                     tells.sierra$ = 0;
                  }
               }

               tells.carrying$.add(teeth);
               hostel._angeles(true);
            }

            tells._roster(String.valueOf(tells.carrying$.size()));
         }

      }
   }

   private boolean _animal() {
      Object udegopom = Alondra._inserted();
      return udegopom._protocol() != 0.0D || udegopom._blend() != 0.0D;
   }

   public void _niger() {
      picelonu.sierra$ = 0;
      picelonu.carrying$.clear();
      picelonu.charlie$.clear();
   }

   public void _ghana() {
      Object enupacal = Alondra._inserted();
      Iterator pelayevi = agomifis.carrying$.iterator();

      while(pelayevi.hasNext()) {
         Object vozamafe = (Hailey)pelayevi.next();
         enupacal._witch()._teddy(vozamafe);
         agomifis.carrying$.remove(vozamafe);
      }

      agomifis.sierra$ = 0;
      agomifis.carrying$.clear();
      agomifis.charlie$.clear();
   }
}
