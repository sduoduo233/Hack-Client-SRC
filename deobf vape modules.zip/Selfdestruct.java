import java.util.Iterator;

public class Kaley extends Fanny {
   private Ellena illegal$;

   public Kaley() {
      super("SelfDestruct", 1, Ayonna.switched$, "You can press LEFT CONTROL + HOME on your keyboard to self destruct at any time, including while in a portal, GUI, or menu");
      suburban.illegal$ = Ellena._designs(suburban, "Temp Disable", false, "Temporarily disable account from authentication");
      suburban._blocked().add(suburban.illegal$);
   }

   public void _tribe(Stormey var1) {
   }

   public void _niger() {
      Dyesha.banodage$.itofodol$ = true;
      if (!Alondra._inserted()._warner()) {
         Alondra._touch((Object)null);
         Alondra._vertical();
         Torris._advice(Torris._possible());
      }

      Iterator governor = Dyesha.banodage$._provider()._klein().iterator();

      while(governor.hasNext()) {
         Object would = (Fanny)governor.next();
         if (would._alpha() && !would.getClass().equals(Stevie.class)) {
            would._symphony(false);
         }
      }

      try {
         Thread.sleep(500L);
      } catch (InterruptedException var3) {
         ;
      }

      Dyesha.banodage$._shape(control.illegal$._sounds().booleanValue());
   }
}
