import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Queue;
import java.util.Random;
import java.util.concurrent.ConcurrentLinkedQueue;

public class Malari extends Matthieu {
   private Dusti brands$ = new Dusti("Both");
   private Dusti becoming$ = new Dusti("Pots");
   private Dusti surround$ = new Dusti("Soup");
   private Franciso lines$;
   private Syble chris$;
   private Ellena stephen$;
   private Ellena hyundai$;
   private Ellena reviewer$;
   private Ashley describe$;
   private Queue thoughts$;
   private boolean focuses$;
   private Random matthew$;

   public Malari() {
      super("Refill");
      nasdaq.lines$ = Franciso._polar(nasdaq, "Type", nasdaq.brands$, nasdaq.brands$, nasdaq.becoming$, nasdaq.surround$);
      nasdaq.stephen$ = Ellena._fitted(nasdaq, "Vertical", false);
      nasdaq.hyundai$ = Ellena._fitted(nasdaq, "Scatter", false);
      nasdaq.reviewer$ = Ellena._designs(nasdaq, "Hotbar clear", false, "Clears junk from your hotbar to refill.");
      nasdaq.describe$ = Ashley._laptop(nasdaq, "Delay", "#", "ms", 0.0D, 75.0D, 125.0D, 200.0D);
      nasdaq.thoughts$ = new ConcurrentLinkedQueue();
      nasdaq.matthew$ = new Random();
      nasdaq._actions(new Albert[]{nasdaq.stephen$, nasdaq.hyundai$, nasdaq.reviewer$, nasdaq.describe$, nasdaq.lines$});
   }

   public void _niger() {
      if (sedetenu._receive().size() == 0) {
         sedetenu._symphony(false);
      } else if (!sedetenu._scratch()) {
         sedetenu._symphony(false);
      } else {
         Object uradaden = Alondra._surfaces()._genres()._performs();
         Micholas._lingerie(uradaden, true);
         Micholas._trace(uradaden);
         Micholas._lingerie(uradaden, false);
         sedetenu._recorder(0L, false);
      }
   }

   private void _hottest(int becoming, int created, int spice, int listings) {
      capacity.thoughts$.add(new Kenneth(becoming, created, spice, listings, (iReSqtkUVgazYiReSqtkUVg)null));
   }

   public void _ruled() {
      try {
         int rifupuli = 0;

         while(true) {
            Thread.sleep(10L);
            ++rifupuli;
            if (rifupuli > 5) {
               break;
            }

            if (Alondra._position()._gotta(Akeia.hotel$)) {
               emogabas.chris$ = new Syble(Alondra._position()._science());
               break;
            }
         }

         if (Alondra._position()._gotta(Akeia.hotel$)) {
            Object dopevera = new ArrayList();
            new ArrayList();
            Object betesifo = 0;
            Object imodiney = emogabas._receive();
            int ucifisug = 9;

            while(true) {
               boolean var10001 = true;
               Object fugasuso = (Cari)emogabas.chris$._sector()._eastern().get(ucifisug);
               Trinette var8 = fugasuso._monthly();
               if (!var8._warner()) {
                  Gianfranco var9 = var8._educated();
                  if (!var9._warner() && Lyonel._warranty(var8, emogabas.lines$._young().equals(emogabas.surround$) || emogabas.lines$._young().equals(emogabas.brands$))) {
                     dopevera.add(ucifisug);
                  }
               }

               if (emogabas.stephen$._sounds().booleanValue()) {
                  ucifisug += 9;
                  ++betesifo;
                  if (betesifo == 3) {
                     ++ucifisug;
                     ucifisug -= 27;
                     betesifo = 0;
                  }
               } else {
                  ++ucifisug;
               }
            }
         }

         emogabas.focuses$ = true;
      } catch (Exception var13) {
         ;
      }
   }

   public void _strings(Neill tests) {
      if (travesti.focuses$) {
         if (!Alondra._position()._warner()) {
            Alondra._inserted()._lighting();
         }

         travesti.focuses$ = false;
         travesti._symphony(false);
      } else {
         while(!travesti.thoughts$.isEmpty()) {
            Kenneth var2 = (Kenneth)travesti.thoughts$.poll();
            var2._holding();
         }
      }

   }

   private boolean _scratch() {
      Object evovoroz = false;
      int ogabezer = 9;

      while(true) {
         boolean var10001 = true;
         Object difomuto = Alondra._inserted()._ordering()._company(ogabezer);
         if (!difomuto._warner()) {
            Gianfranco var4 = difomuto._educated();
            if (!var4._warner() && Lyonel._warranty(difomuto, azogicel.lines$._young().equals(azogicel.surround$) || azogicel.lines$._young().equals(azogicel.brands$))) {
               evovoroz = true;
            }
         }

         ++ogabezer;
      }
   }

   private List _receive() {
      Object memeyapa = new ArrayList();
      Object oguzobod = new ArrayList();
      Object nimomeno = Alondra._inserted()._ordering()._rotary();
      int eficamom = 0;

      while(true) {
         boolean var10001 = true;
         Object vatidapo = new Trinette(nimomeno[eficamom]);
         if (vatidapo._warner()) {
            oguzobod.add(eficamom);
         } else if (mupugabi.reviewer$._sounds().booleanValue()) {
            if (mupugabi._insider(vatidapo._educated(), vatidapo, memeyapa)) {
               oguzobod.add(eficamom);
            }
         } else if (vatidapo.toString().contains("tile.air")) {
            oguzobod.add(eficamom);
         }

         ++eficamom;
      }
   }

   private boolean _receipt(Trinette suddenly, List lucas) {
      Iterator salon = lucas.iterator();

      Trinette achieve;
      do {
         if (!salon.hasNext()) {
            return false;
         }

         achieve = (Trinette)salon.next();
      } while(suddenly.equals(achieve) || !suddenly._educated()._science().getClass().isInstance(achieve._educated()._science()));

      return true;
   }

   private boolean _insider(Gianfranco chest, Trinette briefing, List requests) {
      if (Lyonel._warranty(briefing, heating.lines$._young().equals(heating.surround$) || heating.lines$._young().equals(heating.brands$))) {
         return false;
      } else if (Akeia.prison$.isInstance(chest._science())) {
         if (!heating._receipt(briefing, requests)) {
            requests.add(briefing);
            return false;
         } else {
            return true;
         }
      } else if (Akeia.subjects$.isInstance(chest._science())) {
         if (!heating._receipt(briefing, requests)) {
            requests.add(briefing);
            return false;
         } else {
            return true;
         }
      } else if (Akeia.berkeley$.isInstance(chest._science())) {
         if (!heating._receipt(briefing, requests)) {
            requests.add(briefing);
            return false;
         } else {
            return true;
         }
      } else {
         return true;
      }
   }
}
