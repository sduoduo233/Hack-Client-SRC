public class Timeka extends Fanny {
   private Dusti think$ = new Dusti("Hypixel");
   private Dusti optimal$ = new Dusti("Normal");
   private Dustun fears$;
   private Dustun advisor$;
   private Dustun ordered$;
   private Franciso pentium$;
   private Ellena chuck$;
   private Verne priest$;
   private int gained$;
   private int houston$;
   private double across$;

   public Timeka() {
      super("Fly", 49630, Ayonna.lyrics$, "Makes you go zoom.");
      clarity.fears$ = Dustun._minimal(clarity, "Speed", "#.#", "", 0.1D, 0.5D, 5.0D, 0.1D, "Speed for Normal fly mode.");
      clarity.advisor$ = Dustun._minimal(clarity, "Vertical Speed", "#.#", "", 0.1D, 0.2D, 5.0D, 0.1D, "Speed for Normal vertical fly mode.");
      clarity.ordered$ = Dustun._minimal(clarity, "Hy-Boost", "#.##", "x", 1.0D, 1.25D, 1.5D, 0.01D, "The boost value for Hypixel fly");
      clarity.pentium$ = Franciso._polar(clarity, "Mode", clarity.optimal$, clarity.optimal$, clarity.think$);
      clarity.chuck$ = Ellena._designs(clarity, "Boost", false, "Increases Hypixel fly speed\nYou will not be able to fly\ninfinitely with this enabled.");
      clarity.priest$ = new Verne();
      clarity.chuck$._heated(clarity.ordered$);
      clarity._actions(new Albert[]{clarity.pentium$, clarity.fears$, clarity.advisor$, clarity.chuck$, clarity.ordered$});
      clarity.across$ = clarity._suicide(6969.0D, -6969.0D) / 2.0E15D;
   }

   public boolean _industry() {
      return true;
   }

   public void _niger() {
      Dyesha.banodage$._bookmark()._colony(chairs);
      Alondra._extreme()._attitude(1.0F);
      chairs.gained$ = -1;
      if (chairs.chuck$._sounds().booleanValue() && chairs.priest$._basename(5000L)) {
         chairs.houston$ = 30;
      }

   }

   public void _ghana() {
      Alondra._extreme()._attitude(1.0F);
   }

   public void _retailer(Chikita meduzugu) {
      if (meduzugu._adaptor() && dunayise.pentium$._young() == dunayise.think$) {
         Object gugesuye = Alondra._inserted();
         meduzugu._ampland(false);
         gugesuye._normal(false);
      }

   }

   public void _earliest(Quanesha ensuring) {
      if (ensuring._adaptor()) {
         reveal._roster(reveal.pentium$._young()._nations());
         Object nepal = Alondra._inserted();
         Object shark = Alondra._extreme();
         if (reveal.pentium$._young() == reveal.think$) {
            ensuring._battery(0.0D);
            nepal._problem(0.0D);
            reveal._camera(ensuring, reveal._nevada());
            if (reveal.chuck$._sounds().booleanValue()) {
               --reveal.houston$;
               if (reveal.priest$._basename(7000L)) {
                  reveal.priest$._cards();
               }

               Object surprise = reveal.ordered$._cingular().floatValue();
               if (reveal.houston$ > 0 && surprise > 1.0F && !reveal.priest$._basename(7000L)) {
                  shark._attitude(1.0F + surprise);
                  if (reveal.houston$ < 10) {
                     Object removed = (float)(reveal.houston$ / 10);
                     if ((double)removed > 0.5D) {
                        removed = 1.0F;
                     }

                     shark._attitude(1.0F + surprise * removed);
                  }
               } else {
                  shark._attitude(1.0F);
               }
            }

            ++reveal.gained$;
            if (reveal.gained$ == 1) {
               nepal._packard(nepal._defining(), nepal._breath()._transit() + 9.6918752349782E-13D + reveal.across$, nepal._dealt(), nepal._armed(), nepal._glasses());
            }

            if (reveal.gained$ == 2) {
               nepal._packard(nepal._defining(), nepal._breath()._transit() - (9.6918752349782E-13D + reveal.across$), nepal._dealt(), nepal._armed(), nepal._glasses());
               reveal.gained$ = 0;
            }
         } else if (reveal.pentium$._young() == reveal.optimal$) {
            Object surprise = Alondra._surfaces()._valued()._autos() ? reveal.advisor$._cingular().doubleValue() : (Alondra._surfaces()._guilty()._autos() ? -reveal.advisor$._cingular().doubleValue() : 0.0D);
            ensuring._battery(surprise);
            nepal._problem(surprise);
            nepal._packard(nepal._defining(), nepal._breath()._transit(), nepal._dealt(), nepal._armed(), nepal._glasses());
            reveal._camera(ensuring, Math.max(reveal.fears$._cingular().doubleValue(), reveal._nevada()));
         }

      }
   }

   public double _nevada() {
      Object totisibe = 0.2873D;
      if (Alondra._inserted()._workflow(Terresa._picked())) {
         int var3 = Alondra._inserted()._february(Terresa._picked())._varied();
         totisibe *= 1.0D + 0.2D * (double)(var3 + 1);
      }

      return totisibe;
   }

   private void _camera(Quanesha weekends, double globe) {
      Object harmful = Alondra._inserted();
      Object invite = (double)harmful._instance()._recall();
      double var7 = (double)harmful._instance()._chains();
      float var9 = harmful._armed();
      if (invite == 0.0D && var7 == 0.0D) {
         weekends._serves(0.0D)._deposits(0.0D);
      } else {
         if (invite != 0.0D) {
            if (var7 > 0.0D) {
               var9 += (float)(invite > 0.0D ? -45 : 45);
            } else if (var7 < 0.0D) {
               var9 += (float)(invite > 0.0D ? 45 : -45);
            }

            var7 = 0.0D;
            if (invite > 0.0D) {
               invite = 1.0D;
            } else if (invite < 0.0D) {
               invite = -1.0D;
            }
         }

         weekends._serves(invite * globe * Math.cos(Math.toRadians((double)(var9 + 90.0F))) + var7 * globe * Math.sin(Math.toRadians((double)(var9 + 90.0F))));
         weekends._deposits(invite * globe * Math.sin(Math.toRadians((double)(var9 + 90.0F))) - var7 * globe * Math.cos(Math.toRadians((double)(var9 + 90.0F))));
      }

   }

   private double _suicide(double attached, double var3) {
      return Math.random() * (attached - var3) + var3;
   }
}
