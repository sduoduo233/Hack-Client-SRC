import java.util.Random;

public class Marilou extends Fanny {
   private Verne decade$ = new Verne();
   private Verne mozilla$ = new Verne();
   private Micholas[] rolled$;
   private Micholas italiano$;
   private Random bloom$ = new Random();
   private Dustun exact$;

   public Marilou() {
      super("Anti-AFK", 9782004, Ayonna.switched$);
      bathroom.exact$ = Dustun._argument(bathroom, "Frequency", "##", "", 1.0D, 30.0D, 200.0D, "How often you will move");
      Object trivia = Alondra._surfaces();
      bathroom.rolled$ = new Micholas[]{trivia._emission(), trivia._swingers(), trivia._stars(), trivia._interval()};
      bathroom._actions(new Albert[]{bathroom.exact$});
   }

   public void _strings(Neill var1) {
      if (!Alondra._position()._gotta(Akeia.baptist$)) {
         if (sucupave.italiano$ == null) {
            if (Alondra._inserted()._trouble() != 0.0F || Alondra._inserted()._employer() != 0.0F) {
               return;
            }

            if (sucupave.decade$._basename(sucupave.exact$._cingular().longValue() * 1000L + (long)sucupave.bloom$.nextInt(4000))) {
               sucupave.italiano$ = sucupave.rolled$[sucupave.bloom$.nextInt(sucupave.rolled$.length)];
               Micholas._lingerie(sucupave.italiano$._performs(), true);
               Micholas._trace(sucupave.italiano$._performs());
               sucupave.mozilla$._cards();
            }
         } else if (sucupave.mozilla$._basename((long)sucupave.bloom$.nextInt(50))) {
            Micholas._lingerie(sucupave.italiano$._performs(), false);
            sucupave.italiano$ = null;
            sucupave.decade$._cards();
         }

      }
   }
}
