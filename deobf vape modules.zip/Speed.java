public class Davien extends Fanny {
   public double vedetedu$;
   public double ezenufos$;
   public int povopone$;
   private Devonte epesodiy$;
   private Devonte sufelobo$;
   private Devonte afinipab$;
   private Devonte cisibide$;
   private Franciso vodoyuyo$;

   public Davien() {
      super("Speed", 49630, Ayonna.lyrics$, "Increases your movement with various methods.");
      serves.epesodiy$ = new Devonte("Bhop", new Josua(serves, "Bhop"));
      serves.sufelobo$ = new Devonte("Hypixel", new Toi(serves, "Hypixel"));
      serves.afinipab$ = new Devonte("Y-Port", new Herica(serves, "Y-Port"));
      serves.cisibide$ = new Devonte("Mineplex", new Nixon(serves, "Mineplex"));
      serves.vodoyuyo$ = Franciso._capitol(serves, "Mode", "Speed mode to use.\nBhop - Bypasses Old NCP\nY-Port - Bypasses Old NCP\nHypixel - Bhop that bypasses Watchdog", serves.sufelobo$, serves.sufelobo$, serves.cisibide$, serves.epesodiy$, serves.afinipab$);
      ((Jinny)serves.vodoyuyo$._columbus())._fancy(new Kenyatta(serves));
      serves._actions(new Albert[]{serves.vodoyuyo$});
   }

   public boolean _industry() {
      return true;
   }

   public void _snapshot(int ending) {
      mounting.povopone$ = ending;
   }

   public double _bloggers() {
      Object iyamitif = 0.2873D;
      if (Alondra._inserted()._workflow(Terresa._picked())) {
         int var3 = Alondra._inserted()._february(Terresa._picked())._varied();
         iyamitif *= 1.0D + 0.2D * (double)(var3 + 1);
      }

      return iyamitif;
   }

   public void _niger() {
      Dyesha.banodage$._bookmark()._colony(novofuve);
      novofuve.vedetedu$ = novofuve._bloggers();
      novofuve.ezenufos$ = 0.0D;
      novofuve.povopone$ = 2;
   }

   public void _earliest(Quanesha scenario) {
      if (scenario._adaptor()) {
         if (table.vodoyuyo$._young() == table.sufelobo$) {
            table.sufelobo$._knife()._earliest(scenario);
         } else if (table.vodoyuyo$._young() == table.epesodiy$) {
            table.epesodiy$._knife()._earliest(scenario);
         } else if (table.vodoyuyo$._young() == table.afinipab$) {
            table.afinipab$._knife()._earliest(scenario);
         } else if (table.vodoyuyo$._young() == table.cisibide$) {
            table.cisibide$._knife()._earliest(scenario);
         }

      }
   }

   public void _retailer(Chikita dealtime) {
      revenue._roster(revenue.vodoyuyo$._young()._nations());
      if (dealtime._latin() == Desirre.barrier$) {
         Object covers = Alondra._inserted();
         if (revenue.vodoyuyo$._young() == revenue.afinipab$) {
            revenue.afinipab$._knife()._retailer(dealtime);
         }

         Object broad = covers._defining() - covers._moral();
         double var5 = covers._dealt() - covers._routines();
         revenue.ezenufos$ = Math.sqrt(broad * broad + var5 * var5);
      }

   }

   public void _sensors(Quanesha omorapef, double cupayado, Tempess eliyogot) {
      Object vefiyiri = (double)eliyogot._instance()._recall();
      Object dasivevu = (double)eliyogot._instance()._chains();
      float var9 = eliyogot._armed();
      if (vefiyiri == 0.0D && dasivevu == 0.0D) {
         omorapef._serves(0.0D);
         omorapef._deposits(0.0D);
      } else if (vefiyiri != 0.0D) {
         if (dasivevu != 0.0D) {
            if (dasivevu > 0.0D) {
               var9 += vefiyiri > 0.0D ? -45.0F : 45.0F;
               dasivevu = 0.0D;
            } else {
               var9 += vefiyiri > 0.0D ? 45.0F : -45.0F;
               dasivevu = 0.0D;
            }
         }

         if (vefiyiri > 0.0D) {
            vefiyiri = 1.0D;
         } else {
            vefiyiri = -1.0D;
         }
      }

      double var10 = Math.cos(Math.toRadians((double)(var9 + 90.0F)));
      double var12 = Math.sin(Math.toRadians((double)(var9 + 90.0F)));
      omorapef._serves(vefiyiri * cupayado * var10 + dasivevu * cupayado * var12);
      omorapef._deposits(vefiyiri * cupayado * var12 - dasivevu * cupayado * var10);
   }

   static Franciso _karma(Davien olicegog) {
      return olicegog.vodoyuyo$;
   }
}
