import java.awt.Color;
import java.util.Iterator;
import org.lwjgl.opengl.GL11;

public class Dewarren extends Fanny {
   private Deepak umizicor$;
   private Ellena inabiguv$;
   private Ellena yodarobe$;
   private Ellena ayotagav$;
   private Ellena vayotume$;
   private Ellena yazupoyu$;
   private Ellena vegopita$;
   private Ellena pezefuli$;
   private Ricahrd apayarup$;
   private Ricahrd esedinav$;
   private Ricahrd utifoyod$;
   private Ricahrd ugetefif$;
   private Ricahrd meribeta$;
   private Ricahrd cidabufi$;

   public Dewarren() {
      super("StorageESP", 3465010, Ayonna.weather$);
      momicobo.inabiguv$ = Ellena._designs(momicobo, "Outline open", true, "Outlines open chests by contrasting color");
      momicobo.yodarobe$ = Ellena._fitted(momicobo, "Render Chests", true);
      momicobo.ayotagav$ = Ellena._fitted(momicobo, "Render Enderchests", false);
      momicobo.vayotume$ = Ellena._fitted(momicobo, "Render Hopper", false);
      momicobo.yazupoyu$ = Ellena._fitted(momicobo, "Render Furnace", false);
      momicobo.vegopita$ = Ellena._fitted(momicobo, "Render Dispenser", false);
      momicobo.pezefuli$ = Ellena._fitted(momicobo, "Render Dropper", false);
      momicobo.apayarup$ = Ricahrd._strike(momicobo, "Chest Color", new Color(1, 255, 146, 100));
      momicobo.esedinav$ = Ricahrd._strike(momicobo, "Ender Chest Color", new Color(1, 255, 146, 100));
      momicobo.utifoyod$ = Ricahrd._strike(momicobo, "Hopper Color", new Color(1, 255, 146, 100));
      momicobo.ugetefif$ = Ricahrd._strike(momicobo, "Furnace Color", new Color(1, 255, 146, 100));
      momicobo.meribeta$ = Ricahrd._strike(momicobo, "Dispenser Color", new Color(1, 255, 146, 100));
      momicobo.cidabufi$ = Ricahrd._strike(momicobo, "Dropper Color", new Color(1, 255, 146, 100));
      momicobo.yodarobe$._milan().add(momicobo.apayarup$);
      momicobo.ayotagav$._milan().add(momicobo.esedinav$);
      momicobo.vayotume$._milan().add(momicobo.utifoyod$);
      momicobo.yazupoyu$._milan().add(momicobo.ugetefif$);
      momicobo.vegopita$._milan().add(momicobo.meribeta$);
      momicobo.pezefuli$._milan().add(momicobo.cidabufi$);
      momicobo._actions(new Albert[]{momicobo.inabiguv$, momicobo.yodarobe$, momicobo.apayarup$, momicobo.ayotagav$, momicobo.esedinav$, momicobo.vayotume$, momicobo.utifoyod$, momicobo.yazupoyu$, momicobo.ugetefif$, momicobo.vegopita$, momicobo.meribeta$, momicobo.pezefuli$, momicobo.cidabufi$});
      momicobo.umizicor$ = Alondra._slide();
   }

   public void _football(Angelicia nuzuvocu) {
      Alondra._bearing()._couples(1.0D);
      GL11.glPushMatrix();
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glLineWidth(1.5F);
      GL11.glDisable(3553);
      GL11.glEnable(2848);
      GL11.glDisable(2929);
      GL11.glDepthMask(false);
      Object aruniber = elevepuz.umizicor$._shared();
      Object yacunugi = elevepuz.umizicor$._cement();
      Object civovoru = elevepuz.umizicor$._explore();
      Iterator elosidar = Alondra._right()._weekend().iterator();

      while(elosidar.hasNext()) {
         Object vatozabe = elosidar.next();
         Color var10 = null;
         Object var11 = null;
         if (elevepuz.yodarobe$._sounds().booleanValue() && Akeia.grave$.isInstance(vatozabe)) {
            var10 = elevepuz.apayarup$._depends();
            var11 = new Eleasha(vatozabe);
         } else if (elevepuz.ayotagav$._sounds().booleanValue() && Akeia.moves$.isInstance(vatozabe)) {
            var10 = elevepuz.esedinav$._depends();
            var11 = new Glynn(vatozabe);
         } else if (elevepuz.vayotume$._sounds().booleanValue() && Akeia.cheapest$.isInstance(vatozabe)) {
            var10 = elevepuz.utifoyod$._depends();
         } else if (elevepuz.yazupoyu$._sounds().booleanValue() && Akeia.awarded$.isInstance(vatozabe)) {
            var10 = elevepuz.ugetefif$._depends();
         } else if (elevepuz.pezefuli$._sounds().booleanValue() && Akeia.maldives$.isInstance(vatozabe)) {
            var10 = elevepuz.cidabufi$._depends();
         } else if (elevepuz.vegopita$._sounds().booleanValue() && Akeia.largely$.isInstance(vatozabe)) {
            var10 = elevepuz.meribeta$._depends();
         }

         if (var10 != null) {
            if (var11 == null) {
               var11 = new Tisheena(vatozabe);
            }

            var10 = new Color(var10.getRed(), var10.getGreen(), var10.getBlue(), 100);
            Object var12;
            if (var11 instanceof Eleasha) {
               Eleasha var13 = (Eleasha)var11;
               if (elevepuz.inabiguv$._sounds().booleanValue()) {
                  var12 = new Kareem(((Tisheena)var11)._peeing(), ((Tisheena)var11)._issued(), ((Tisheena)var11)._painful(), -1, var10, var13._audience());
               } else {
                  var12 = new Quinetta(((Tisheena)var11)._peeing(), ((Tisheena)var11)._issued(), ((Tisheena)var11)._painful(), -1, var10);
               }
            } else if (var11 instanceof Glynn) {
               Glynn var14 = (Glynn)var11;
               var12 = new Kareem(((Tisheena)var11)._peeing(), ((Tisheena)var11)._issued(), ((Tisheena)var11)._painful(), -1, var10, var14._deadly());
            } else {
               var12 = new Quinetta(((Tisheena)var11)._peeing(), ((Tisheena)var11)._issued(), ((Tisheena)var11)._painful(), -1, var10);
            }

            Taci._willow(aruniber, yacunugi, civovoru, (Quinetta)var12, var10);
         }
      }

      GL11.glDepthMask(true);
      GL11.glEnable(2929);
      GL11.glEnable(3553);
      GL11.glDisable(2848);
      GL11.glDisable(3042);
      GL11.glPopMatrix();
      Alondra._bearing()._derek(1.0D);
   }
}
