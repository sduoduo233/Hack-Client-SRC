import java.awt.Color;

public class Starlyn extends Fanny {
   private Dusti boyotizi$ = new Dusti("Packet");
   private Dusti culayipa$ = new Dusti("Hypixel");
   private Franciso asotavef$;

   public Starlyn() {
      super("Criticals", (new Color(193, 183, 92)).getRGB(), Ayonna.lyrics$, "Forces critical hit every attack\nMay not bypass anti-cheats");
      obuguren.asotavef$ = Franciso._capitol(obuguren, "Mode", "Criticals bypass method\nPacket - May not bypass anti-cheats, watchdog detected.\nHypixel - Watchdog bypassing Criticals mode.\nHypixel mode does not work separate from Killaura.", obuguren.boyotizi$, obuguren.boyotizi$, obuguren.culayipa$);
      obuguren._actions(new Albert[]{obuguren.asotavef$});
      ((Jinny)obuguren.asotavef$._columbus())._fancy(new Stevyn(obuguren));
   }

   public boolean _moses() {
      return older.asotavef$._young() == older.culayipa$ && older._alpha() && Benji._orlando() > 13;
   }

   public boolean _industry() {
      return true;
   }

   public void _refine(Crawford porovure) {
      if (bamanitu.asotavef$._young() == bamanitu.boyotizi$ && porovure._latin() == Desirre.barrier$) {
         Object recefapu = Dyesha.banodage$;
         Object aperirur = Alondra._inserted();
         if (aperirur._cases()) {
            if (recefapu._provider()._smooth(Davien.class) || recefapu._provider()._smooth(Timeka.class) || recefapu._provider()._smooth(Sareena.class)) {
               return;
            }

            if (!porovure._silence()._warner() && porovure._silence()._gotta(Akeia.shore$)) {
               Object sitozoma = new Quenna(porovure._silence()._science());
               if (sitozoma._gotta(Akeia.mapping$) && recefapu._assigned()._dublin(sitozoma)) {
                  return;
               }

               bamanitu._winning(aperirur);
            }
         }
      }

   }

   private void _winning(Tempess salary) {
      Object barely = new double[]{0.0654223451234D, 5.78128675E-4D};
      Object tissue = barely.length;
      int header = 0;

      while(true) {
         Object locator = barely[header];
         if (Benji._orlando() > 13) {
            salary._witch()._teddy(Hinda._attacks(salary._defining(), salary._opens() + locator, salary._dealt(), false));
         } else {
            salary._witch()._teddy(Hinda._thought(salary._defining(), salary._breath()._transit() + locator, salary._opens() + locator, salary._dealt(), false));
         }

         ++header;
      }
   }

   static Franciso _cottage(Starlyn averacic) {
      return averacic.asotavef$;
   }
}
