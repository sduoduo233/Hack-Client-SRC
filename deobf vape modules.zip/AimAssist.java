import java.util.Iterator;
import java.util.Random;

public class Deshana extends Fanny {
   private float merry$ = 0.0F;
   private float division$ = 0.0F;
   private boolean custody$;
   private int catalogs$;
   private int commonly$;
   private float levitra$;
   private float bored$;
   private float either$;
   private float certain$;
   private boolean required$;
   private boolean bachelor$;
   private double fighting$;
   private double absolute$;
   private double afford$;
   private double zealand$;
   private double calvin$;
   private int inner$;
   private int midnight$;
   private int moment$ = 0;
   private Ellena guild$;
   private Ellena locked$;
   private Ellena treasury$;
   private Ellena wider$;
   private Ellena lincoln$;
   private Ellena orange$;
   private Ellena injury$;
   private Ellena amber$;
   private Tashenna bible$;
   private Dustun lands$;
   private Dustun mystery$;
   private Dustun growing$;
   private Dustun volume$;
   private boolean assume$;
   private float history$;
   private float movies$;
   private float increase$;
   private float kelly$;
   private int athletes$;
   private int scoop$;
   private double editions$;
   private boolean about$;
   private Lavetta comedy$;
   private Random bottles$;
   private Random roller$;
   private int adjacent$;
   private int forge$;
   int light$;

   public Deshana() {
      super("AimAssist", -327674, Ayonna.resource$, "Smoothly aims to closest valid target");
      rucisobe.guild$ = Ellena._designs(rucisobe, "Click Aim", true, "Only aim while mouse is down");
      rucisobe.locked$ = Ellena._designs(rucisobe, "Aim Vertically", false, "Aims up and down as well");
      rucisobe.treasury$ = Ellena._designs(rucisobe, "Invisibles", false, "Aim at invisible entities");
      rucisobe.wider$ = Ellena._designs(rucisobe, "Through Blocks", false, "Aim through blocks at entities");
      rucisobe.lincoln$ = Ellena._designs(rucisobe, "Aim while on target", true, "Continue to adjust aim while hovering over target");
      rucisobe.orange$ = Ellena._designs(rucisobe, "Strafe increase", false, "Increase speed whiling strafing away from target");
      rucisobe.injury$ = Ellena._designs(rucisobe, "Check block break", false, "Prevents from aiming while breaking blocks");
      rucisobe.amber$ = Ellena._designs(rucisobe, "Limit to items", false, "AimAssist functions only while holding selected items");
      rucisobe.bible$ = Tashenna._party(rucisobe, "aimassist-alloweditems", "Allowed Items", Tashenna.nifurine$, new Artemus("swords"));
      rucisobe.lands$ = Dustun._bright(rucisobe, "Vertical Speed", "#.#", "", 1.0D, 5.0D, 10.0D);
      rucisobe.mystery$ = Dustun._bright(rucisobe, "Horizontal Speed", "#.#", "", 1.0D, 5.0D, 10.0D);
      rucisobe.growing$ = Dustun._minimal(rucisobe, "Max Angle", "#", "", 1.0D, 180.0D, 360.0D, 1.0D, "Maximum allowed angle to still aim at target");
      rucisobe.volume$ = Dustun._minimal(rucisobe, "Distance", "#.#", "", 1.0D, 5.0D, 8.0D, 0.1D, "Maximum distance allowed to still aim at target");
      rucisobe.comedy$ = null;
      rucisobe.bottles$ = new Random();
      rucisobe.roller$ = new Random();
      rucisobe.light$ = 0;
      rucisobe.locked$._heated(rucisobe.lands$);
      rucisobe.amber$._heated(rucisobe.bible$);
      rucisobe._actions(new Albert[]{rucisobe.guild$, rucisobe.treasury$, rucisobe.wider$, rucisobe.lincoln$, rucisobe.orange$, rucisobe.injury$, rucisobe.locked$, rucisobe.lands$, rucisobe.mystery$, rucisobe.growing$, rucisobe.volume$, rucisobe.amber$, rucisobe.bible$});
   }

   private void _sensor() {
      if (!Alondra._right()._warner() && !Alondra._inserted()._warner()) {
         if (!obutifob._pharmacy()) {
            obutifob._lasting();
         } else if (obutifob.guild$._sounds().booleanValue() && !Tamirra._preserve()) {
            obutifob.comedy$ = null;
            obutifob._lasting();
         } else {
            if (obutifob.comedy$ != null && (Gared._imported(obutifob.comedy$) || (double)Alondra._inserted()._header(obutifob.comedy$) > obutifob.volume$._cingular().doubleValue())) {
               obutifob._lasting();
               obutifob.comedy$ = null;
            }

            if (obutifob.guild$._sounds().booleanValue() && Tamirra._preserve() && obutifob.comedy$ == null || !obutifob.guild$._sounds().booleanValue()) {
               Object ufumodis = obutifob._bradley();
               if (!obutifob.guild$._sounds().booleanValue()) {
                  ++obutifob.scoop$;
                  if (obutifob.scoop$ > 700 || obutifob.comedy$ == null) {
                     obutifob.comedy$ = ufumodis;
                     obutifob.scoop$ = 0;
                  }
               } else {
                  obutifob.comedy$ = ufumodis;
               }
            }

            if (Alondra._right()._science() != null) {
               if (obutifob.comedy$ != null && Alondra._position()._science() == null) {
                  obutifob._banners(obutifob.about$);
                  obutifob._persons();
               } else {
                  obutifob._lasting();
               }

            }
         }
      }
   }

   void _banners(boolean var1) {
      ++butts.athletes$;
      if (butts.athletes$ > 10) {
         butts.movies$ = butts.history$;
         butts.kelly$ = butts.increase$;
         butts.increase$ = 0.0F;
         butts.history$ = 0.0F;
         butts.athletes$ = 0;
      }

   }

   void _lasting() {
      meguzume.levitra$ = 0.0F;
      meguzume.bored$ = 0.0F;
      meguzume.adjacent$ = 0;
      meguzume.forge$ = 0;
      meguzume.catalogs$ = 0;
      meguzume.commonly$ = 0;
      meguzume.either$ = 0.0F;
   }

   void _brussels(float volvo) {
      if (volvo != 0.0F) {
         volvo *= 5.0F;
         Object carlo = absence.lands$._cingular().floatValue();
         Object armed = (float)Gared._disagree(Alondra._inserted(), absence.comedy$);
         if (armed <= 10.0F) {
            absence.division$ = carlo;
         }

         if (absence.division$ > 0.0F) {
            carlo -= absence.division$ / 3.0F;
            absence.division$ -= armed / 200.0F;
         }

         Object believed = 1.0F * carlo * volvo;
         absence.bored$ += believed;
      } else {
         absence.bored$ = 0.0F;
      }

   }

   void _kevin(float vededoze) {
      if (vededoze != 0.0F) {
         vededoze *= 5.0F;
         Object nibitefe = zuponabu.mystery$._cingular().floatValue();
         Object yorazesi = (float)Gared._chosen(Alondra._inserted(), zuponabu.comedy$);
         if (yorazesi <= 10.0F) {
            zuponabu.merry$ = nibitefe;
         }

         if (zuponabu.merry$ > 0.0F) {
            nibitefe -= zuponabu.merry$ / 3.0F;
            zuponabu.merry$ -= yorazesi / 200.0F;
         }

         Object cizivezu = 1.0F * nibitefe * vededoze;
         zuponabu.levitra$ += cizivezu;
      } else {
         zuponabu.levitra$ = 0.0F;
      }

   }

   public void _equality(Adele gabuyenu) {
      if (!Alondra._right()._warner()) {
         Object fuzonuzo = Alondra._surfaces()._lobby();
         cebevesi.levitra$ += (float)cebevesi.catalogs$;
         cebevesi.bored$ += (float)cebevesi.commonly$;
         Object bobidepu = (int)cebevesi.levitra$;
         Object zuvunisa = (int)(-cebevesi.bored$);
         Object zinalase = fuzonuzo * 0.6F + 0.2F;
         Object dasubime = zinalase * zinalase * zinalase * 8.0F;
         Object merigidu = (float)bobidepu * dasubime;
         float var8 = (float)zuvunisa * dasubime;
         cebevesi._heart(merigidu, var8);
         cebevesi.levitra$ = 0.0F;
         cebevesi.bored$ = 0.0F;
         cebevesi.catalogs$ = 0;
         cebevesi.commonly$ = 0;
      }
   }

   private void _persons() {
      esomonod._keyboard();
      esomonod.afford$ = esomonod.fighting$;
      esomonod.zealand$ = esomonod.absolute$;
      esomonod.fighting$ = esomonod.comedy$._bouquet();
      esomonod.absolute$ = esomonod.comedy$._eagle();
      Object tigidele = esomonod.comedy$._defining() - esomonod.fighting$;
      Object omucaved = esomonod.comedy$._dealt() - esomonod.absolute$;
      if (tigidele == 0.0D || omucaved == 0.0D) {
         tigidele = esomonod.comedy$._defining() - esomonod.afford$;
         omucaved = esomonod.comedy$._dealt() - esomonod.zealand$;
      }

      Object licefogu = Alondra._inserted();
      Object anocudav = 1.6D;
      Gared._geneva(esomonod.volume$._cingular().doubleValue(), -0.15F);
      esomonod.custody$ = false;
      Object edalomem = Gared._reaching(licefogu, esomonod.comedy$._defining() + tigidele * anocudav, esomonod.comedy$._dealt() + omucaved * anocudav);
      Object ufucifom = Math.abs(Gared._disagree(licefogu, esomonod.comedy$)) - 10;
      Object izevubis = Gared._dressing(licefogu, esomonod.comedy$._defining() + tigidele * anocudav, esomonod.comedy$._dealt() + omucaved * anocudav);
      Object cutebezi = 1.0F;
      Object itapedec = 1.0F;
      if (esomonod.custody$ && !esomonod.lincoln$._sounds().booleanValue()) {
         esomonod._lasting();
      } else {
         cutebezi = (float)((double)cutebezi + Arnita._cedar(esomonod.bottles$, 0.0D, 2.0D));
         cutebezi = (float)((double)cutebezi + edalomem / 50.0D);
         if (Math.abs(edalomem - esomonod.calvin$) > 6.0D) {
            cutebezi = (float)((double)cutebezi + edalomem / 35.0D);
         }

         Object unizover = (double)((9.0F - licefogu._header(esomonod.comedy$)) / 2.5F - 2.0F);
         unizover = Math.max(0.0D, unizover);
         cutebezi = (float)((double)cutebezi + unizover);
         if (esomonod.orange$._sounds().booleanValue() && (!izevubis && licefogu._instance()._chains() > 0.0F || izevubis && licefogu._instance()._chains() < 0.0F)) {
            cutebezi = (float)((double)cutebezi * 1.3D);
         }

         if (licefogu._header(esomonod.comedy$) < 0.5F) {
            cutebezi /= 5.0F;
         }

         cutebezi /= 90.0F;
         itapedec /= 90.0F;
         float var17 = izevubis ? -cutebezi : cutebezi;
         boolean var18 = Gared._evans(licefogu, esomonod.comedy$);
         float var19 = var18 ? itapedec : -itapedec;
         if (edalomem < 5.0D) {
            esomonod.midnight$ = 0;
            var17 = 0.0F;
            esomonod.kelly$ *= 0.7F;
            if (izevubis && licefogu._instance()._chains() > 0.0F || !izevubis && licefogu._instance()._chains() < 0.0F) {
               esomonod.kelly$ *= 0.5F;
            }

            if (esomonod.custody$) {
               var19 = 0.0F;
               esomonod.movies$ = 0.0F;
            }
         } else {
            ++esomonod.midnight$;
         }

         if (izevubis != esomonod.required$) {
            esomonod.kelly$ = -esomonod.kelly$;
            esomonod.increase$ = -esomonod.increase$;
            esomonod.levitra$ = 0.0F;
         }

         if (var18 != esomonod.bachelor$) {
            esomonod.movies$ = -esomonod.movies$;
            esomonod.history$ = -esomonod.history$;
            esomonod.bored$ = 0.0F;
         }

         if (ufucifom < 5) {
            var19 = 0.0F;
            esomonod.movies$ *= 0.7F;
         }

         esomonod.increase$ += var17;
         esomonod.history$ += var19;
         var17 = esomonod.kelly$;
         var19 = esomonod.movies$;
         if (Math.abs(var17) > 10.0F) {
            esomonod.increase$ = 0.0F;
            esomonod.kelly$ = 0.0F;
         } else {
            float var20 = var17 * 0.15F;
            if (edalomem <= 9.0D) {
               var20 = (float)((double)var20 / (10.0D - edalomem));
            }

            esomonod.about$ = edalomem > 5.0D;
            if (Float.isNaN(var20)) {
               esomonod.increase$ = 0.0F;
               esomonod.kelly$ = 0.0F;
            } else {
               esomonod._kevin(var20);
               if (esomonod.locked$._sounds().booleanValue()) {
                  float var21 = (float)((double)var19 * 0.15D);
                  if (Float.isNaN(var21)) {
                     esomonod.history$ = 0.0F;
                     esomonod.movies$ = 0.0F;
                     return;
                  }

                  esomonod._brussels(var21);
               }

               esomonod.bachelor$ = var18;
               esomonod.required$ = izevubis;
               ++esomonod.inner$;
               if (esomonod.inner$ > 10) {
                  esomonod.calvin$ = edalomem;
                  esomonod.inner$ = 0;
               }

            }
         }
      }
   }

   private void _heart(float sovefito, float afobofum) {
      Object omapebas = Alondra._inserted();
      Object zeretudu = omapebas._glasses();
      Object eyamagef = omapebas._armed();
      omapebas._exciting((float)((double)omapebas._armed() + (double)sovefito * 0.15D));
      omapebas._thick((float)((double)omapebas._glasses() - (double)afobofum * 0.15D));
      if (omapebas._glasses() < -90.0F) {
         omapebas._thick(-90.0F);
      }

      if (omapebas._glasses() > 90.0F) {
         omapebas._thick(90.0F);
      }

      omapebas._chapters(omapebas._divorce() + omapebas._glasses() - zeretudu);
      omapebas._paint(omapebas._triangle() + omapebas._armed() - eyamagef);
   }

   private void _keyboard() {
      ++gepareve.editions$;
      if (gepareve.editions$ >= (double)(250 + gepareve.roller$.nextInt(50))) {
         gepareve.editions$ = (double)Arnita._uganda(gepareve.roller$, -100, -50);
         gepareve.adjacent$ = Arnita._uganda(gepareve.roller$, -1, 2);
         gepareve.forge$ = Arnita._uganda(gepareve.roller$, -1, 2);
      }

      Object ofalenul = gepareve.adjacent$;
      Object zasuvoga = gepareve.forge$;
      if (gepareve.roller$.nextInt(10) < 2) {
         ;
      }

      if (gepareve.roller$.nextInt(10) < 2) {
         ;
      }

      if (gepareve.roller$.nextInt(10) < 2) {
         ofalenul = 0;
      }

      if (gepareve.roller$.nextInt(10) < 2) {
         zasuvoga = 0;
      }

      if (gepareve.editions$ < 0.0D) {
         ofalenul = 0;
         zasuvoga = 0;
      }

      if (gepareve.roller$.nextInt(20) == 1) {
         gepareve.catalogs$ += ofalenul;
         gepareve.commonly$ += zasuvoga;
      }

      if (gepareve.levitra$ > 0.0F && gepareve.catalogs$ < 0 || gepareve.levitra$ < 0.0F && gepareve.catalogs$ > 0) {
         gepareve.catalogs$ = 0;
      }

   }

   private boolean _coupon() {
      if (!rapizizo.amber$._sounds().booleanValue()) {
         return true;
      } else {
         Object zebalema = Alondra._inserted()._remains();
         if (zebalema._warner()) {
            return false;
         } else {
            Object ozosipez = zebalema._educated();
            return ozosipez._warner() ? false : rapizizo.bible$._cultures(zebalema, true);
         }
      }
   }

   private boolean _pharmacy() {
      if (Alondra._inserted()._warner()) {
         return false;
      } else {
         if (inazudev.injury$._sounds().booleanValue()) {
            if (Alondra._emacs()._duncan()) {
               inazudev.light$ = 250;
               return false;
            }

            if (inazudev.light$ > 0) {
               --inazudev.light$;
            }

            if (inazudev.light$ > 0) {
               return false;
            }
         }

         return inazudev._coupon();
      }
   }

   private Quenna _bradley() {
      Object staffing = null;
      Object arising = Alondra._inserted();
      Object deficit = 360.0D;
      Iterator scotland = Alondra._right()._lambda().iterator();

      while(true) {
         Quenna cursor;
         Rusty arabia;
         do {
            do {
               do {
                  Object reform;
                  do {
                     if (!scotland.hasNext()) {
                        return staffing;
                     }

                     reform = scotland.next();
                  } while(!Dyesha.banodage$._bookmark()._write(new Lavetta(reform), !helmet.treasury$._sounds().booleanValue()));

                  cursor = new Quenna(reform);
               } while((double)arising._header(cursor) > helmet.volume$._cingular().doubleValue());
            } while(!arising._broadway(cursor) && !helmet.wider$._sounds().booleanValue());

            arabia = Dyesha.banodage$._assigned()._church(cursor._powder());
         } while(arabia != null && !arabia._buses());

         double var9 = (double)Gared._chosen(arising, cursor);
         if (var9 < deficit && var9 <= helmet.growing$._cingular().doubleValue() / 2.0D) {
            deficit = var9;
            staffing = cursor;
         }
      }
   }

   public Lavetta _valium() {
      return enuyipum.comedy$;
   }

   public void _niger() {
      if (!esefodop.assume$) {
         esefodop.assume$ = true;
         (new Merline(esefodop)).start();
      }

   }

   static void _surface(Deshana esapepad) {
      esapepad._sensor();
   }
}
