public class Vishal extends Fanny {
   private Ellena letter$;
   private Dustun located$;

   public Vishal() {
      super("FastConsume", -256, Ayonna.lyrics$, "Use/Consume items quicker.");
      yonopore.letter$ = Ellena._designs(yonopore, "Fast Bow", false, "Makes you shoot your bow faster.");
      yonopore.located$ = Dustun._minimal(yonopore, "Ticks", "#", "", 1.0D, 14.0D, 20.0D, 1.0D, "The amount of ticks you have to use an item to consume.");
      yonopore._actions(new Albert[]{yonopore.located$, yonopore.letter$});
   }

   public void _strings(Neill ratazuge) {
      Object ufoliyad = Alondra._inserted();
      if ((double)ufoliyad._killer() == otacazoc.located$._cingular().doubleValue() && otacazoc._meaning(ufoliyad._remains()._educated())) {
         int var3 = 0;

         while(true) {
            boolean var10001 = true;
            ufoliyad._witch()._teddy(Kieron._wines(true));
            ++var3;
         }
      }

   }

   private boolean _meaning(Gianfranco mpegs) {
      return !mpegs._gotta(Akeia.berkeley$) && (welcome.letter$._sounds().booleanValue() || !mpegs._gotta(Akeia.holly$));
   }
}
