import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;

public class Tiffane extends Fanny {
   private final Ashley helped$;
   public final Dustun matter$;
   public final Dustun airport$;
   private final Dustun tramadol$;
   private final Dustun wives$;
   public final Dustun earrings$;
   public final Ellena leave$;
   public final Ellena groups$;
   public final Ellena warcraft$;
   public final Ellena instead$;
   public final Ellena mobiles$;
   public final Ellena cable$;
   public final Ellena promoted$;
   public final Ellena tions$;
   public final Ellena saved$;
   public final Ellena internal$;
   private Devonte world$;
   private Franciso event$;
   private Tashenna clicks$;
   public Verne pilot$;
   public Verne tonight$;
   public List suited$;
   public int rogers$;
   private Random deserve$;
   private Random record$;
   private Random jacket$;
   private Random tired$;
   private Color virtue$;
   private Color packets$;
   private long enabled$;
   private int focusing$;
   private boolean glass$;
   private int usual$;

   public Tiffane() {
      super("Killaura", -2420426, Ayonna.lyrics$, "Attack players around you\nwithout aiming at them.");
      ashley.helped$ = Ashley._laptop(ashley, "Attacks per Second", "#.#", "", 1.0D, 6.0D, 13.0D, 20.0D);
      ashley.matter$ = Dustun._bright(ashley, "Swing range", "#.#", "", 0.0D, 4.0D, 6.0D);
      ashley.airport$ = Dustun._bright(ashley, "Attack range", "#.#", "", 0.0D, 3.5D, 6.0D);
      ashley.tramadol$ = Dustun._gentle(ashley, "Max angle", "#", "", 1.0D, 90.0D, 360.0D, 5.0D);
      ashley.wives$ = Dustun._gentle(ashley, "Max targets", "#", "", 1.0D, 1.0D, 6.0D, 1.0D);
      ashley.earrings$ = Dustun._gentle(ashley, "Switch Delay", "#", "", 50.0D, 400.0D, 1000.0D, 50.0D);
      ashley.leave$ = Ellena._fitted(ashley, "Require mouse down", false);
      ashley.groups$ = Ellena._fitted(ashley, "Attack invisibles", false);
      ashley.warcraft$ = Ellena._fitted(ashley, "Attack through walls", false);
      ashley.instead$ = Ellena._fitted(ashley, "Show target", false);
      ashley.mobiles$ = Ellena._designs(ashley, "Limit to items", false, "Killaura functions only while holding selected items");
      ashley.cable$ = Ellena._designs(ashley, "AutoBlock", false, "Automatically blocks")._quantity(true);
      ashley.promoted$ = Ellena._designs(ashley, "GUI Check", true, "Does not attack when inside of a GUI.");
      ashley.tions$ = Ellena._designs(ashley, "Legit Aura", false, "Use Legit Aura instead of Blatant Aura when blatant is enabled.")._quantity(true);
      ashley.saved$ = Ellena._designs(ashley, "No Swing", false, "Prevents you from swinging server side.")._quantity(true);
      ashley.internal$ = Ellena._designs(ashley, "Perfect Swing", false, "Attacks perfectly on 1.9+ combat servers.\n(1.12.2 Only)");
      ashley.world$ = new Devonte("Switch", new Cecille(ashley, "Switch"));
      ashley.event$ = Franciso._polar(ashley, "Blatant Mode", ashley.world$, ashley.world$);
      ashley.clicks$ = Tashenna._mother(ashley, "killaura-alloweditems", "Allowed Items", Tashenna.nifurine$, Collections.emptyList());
      ashley.pilot$ = new Verne();
      ashley.tonight$ = new Verne();
      ashley.suited$ = new CopyOnWriteArrayList();
      ashley.deserve$ = new Random();
      ashley.record$ = new Random();
      ashley.jacket$ = new Random();
      ashley.tired$ = new Random();
      ashley.virtue$ = new Color(255, 0, 0, 100);
      ashley.packets$ = new Color(255, 112, 112, 100);
      ((Jinny)ashley.event$._columbus())._fancy(new Chrystopher(ashley));
      ashley._actions(new Albert[]{ashley.helped$, ashley.earrings$, ashley.matter$, ashley.airport$, ashley.tramadol$, ashley.wives$, ashley.event$});
      if (Benji._orlando() <= 15) {
         ashley._actions(new Albert[]{ashley.cable$});
      } else {
         ashley._actions(new Albert[]{ashley.internal$});
      }

      ashley._actions(new Albert[]{ashley.groups$, ashley.warcraft$, ashley.leave$, ashley.promoted$, ashley.instead$, ashley.tions$, ashley.saved$, ashley.mobiles$._heated(ashley.clicks$), ashley.clicks$});
      ((Marvin)ashley.matter$._columbus())._fancy(new Josefine(ashley));
   }

   public void _niger() {
      super._niger();
      warranty.suited$.clear();
   }

   public void _ghana() {
      super._ghana();
      niyuloso.suited$.clear();
   }

   public void _strings(Neill bovulemo) {
      if (binefogi.tions$._novelty().booleanValue() || true) {
         if (!binefogi.promoted$._sounds().booleanValue() || !Alondra._position()._trustees()) {
            if (!Alondra._right()._warner()) {
               if (binefogi.tonight$._basename(binefogi._ideas())) {
                  if (binefogi.leave$._sounds().booleanValue() && !Tamirra._preserve()) {
                     binefogi.suited$.clear();
                  } else {
                     binefogi._chrome();
                     Object tuyiyabu = Alondra._inserted();
                     Iterator yagitana = binefogi.suited$.iterator();

                     while(yagitana.hasNext()) {
                        Object vituzibe = (Quenna)yagitana.next();
                        if (binefogi._grammar(vituzibe)) {
                           double var5 = (double)tuyiyabu._header(vituzibe);
                           if (var5 <= binefogi.matter$._cingular().doubleValue()) {
                              tuyiyabu._signing();
                              if (var5 <= binefogi.airport$._cingular().doubleValue()) {
                                 Alondra._emacs()._playback(tuyiyabu, vituzibe);
                              }
                           }
                        }
                     }

                     binefogi.tonight$._cards();
                  }
               }
            }
         }
      }
   }

   public void _football(Angelicia india) {
      religion._roster(religion.event$._young()._nations());
      if (religion.instead$._sounds().booleanValue() && !religion.suited$.isEmpty()) {
         Object graphics = Alondra._inserted();
         Iterator sierra = religion.suited$.iterator();

         while(true) {
            while(sierra.hasNext()) {
               Object layout = (Quenna)sierra.next();
               if ((double)graphics._header(layout) <= religion.airport$._cingular().doubleValue() && (true || ((Quenna)religion.suited$.get(religion.rogers$)).equals(layout))) {
                  Taci._library(layout, 0.0D, (Color)null, religion.virtue$, india._bureau());
               } else {
                  Taci._library(layout, 0.0D, (Color)null, religion.packets$, india._bureau());
               }
            }

            return;
         }
      }
   }

   public void _retailer(Chikita letters) {
      ((Devonte)nickel.event$._young())._knife()._retailer(letters);
   }

   public void _peoples(Lakita touched) {
      ((Devonte)problem.event$._young())._knife()._peoples(touched);
   }

   public long _ideas() {
      Object motovoze = fivuyobo.helped$._cowboy()[0].intValue();
      Object uromivop = fivuyobo.helped$._cowboy()[1].intValue();
      Object cidemedo = motovoze - uromivop;
      Object ofomuyuy = cidemedo <= 0 ? uromivop : fivuyobo.deserve$.nextInt(cidemedo) + uromivop + 1;
      if (ofomuyuy == 0) {
         ofomuyuy = 1;
      }

      if (!fivuyobo.glass$) {
         fivuyobo.enabled$ = (long)(1000 / ofomuyuy);
         if (fivuyobo.tired$.nextInt(4) == 1) {
            fivuyobo.glass$ = true;
            fivuyobo.usual$ = 1 + fivuyobo.tired$.nextInt(5);
         } else if (fivuyobo.tired$.nextInt(10) != 1 && fivuyobo.tired$.nextInt(10) == 1) {
            fivuyobo.glass$ = true;
            fivuyobo.usual$ = 5 + fivuyobo.tired$.nextInt(10);
         }
      }

      if (fivuyobo.glass$) {
         ++fivuyobo.focusing$;
         if (fivuyobo.focusing$ >= fivuyobo.usual$) {
            fivuyobo.focusing$ = 0;
            fivuyobo.glass$ = false;
         }
      }

      Object fivonuru = true;
      if (fivuyobo.record$.nextInt(48) % 10 == 0 && !fivuyobo.glass$) {
         Object uromivop = 25;
         Object motovoze = 70;
         cidemedo = motovoze - uromivop;
         fivuyobo.enabled$ += (long)(fivuyobo.jacket$.nextInt(cidemedo) + uromivop);
      }

      return fivuyobo.enabled$;
   }

   public void _chrome() {
      eyagenap.suited$.clear();
      Object tigezose = new ArrayList(Alondra._right()._lambda());
      Iterator gutidigu = tigezose.iterator();

      while(true) {
         Object mozudalo;
         Lavetta demecime;
         do {
            if (!gutidigu.hasNext()) {
               eyagenap.suited$.sort(new Carlissa(eyagenap, (Chrystopher)null));
               eyagenap.suited$.sort(new Angelene(eyagenap, (Chrystopher)null));
               Object gutidigu = new ArrayList(eyagenap.suited$);
               eyagenap.suited$.clear();

               for(int mozudalo = 0; mozudalo < eyagenap.wives$._cingular().intValue() && mozudalo < gutidigu.size(); ++mozudalo) {
                  eyagenap.suited$.add(gutidigu.get(mozudalo));
               }

               return;
            }

            mozudalo = gutidigu.next();
            demecime = new Lavetta(mozudalo);
         } while(Tamirra.divine$ && demecime._gotta(Akeia.whats$));

         if (demecime._gotta(Akeia.shore$)) {
            Object tuduvotu = new Quenna(mozudalo);
            if (eyagenap._grammar(tuduvotu)) {
               eyagenap.suited$.add(tuduvotu);
            }
         }
      }
   }

   private boolean _leaving(Quenna evogorol) {
      if (!atidovot.mobiles$._sounds().booleanValue()) {
         return Dyesha.banodage$._bookmark()._write(evogorol, !atidovot.groups$._sounds().booleanValue());
      } else {
         Object samulota = Alondra._inserted()._remains();
         if (samulota._warner()) {
            return false;
         } else {
            Object idirenop = samulota._educated();
            if (idirenop._warner()) {
               return false;
            } else {
               return atidovot.clicks$._cultures(samulota, true) && Dyesha.banodage$._bookmark()._write(evogorol, !atidovot.groups$._sounds().booleanValue());
            }
         }
      }
   }

   public boolean _grammar(Quenna tapituga) {
      if (tapituga._warner()) {
         return false;
      } else if (tapituga.equals(Alondra._inserted())) {
         return false;
      } else if (!ipavurad._leaving(tapituga)) {
         return false;
      } else if (tapituga._hosted() > 0.0F && !tapituga._himself()) {
         if ((double)Alondra._inserted()._header(tapituga) >= ipavurad.matter$._cingular().doubleValue()) {
            return false;
         } else if (Gared._chosen(Alondra._inserted(), tapituga) > ipavurad.tramadol$._cingular().intValue() / 2) {
            return false;
         } else {
            Object ezacivim = Dyesha.banodage$._assigned()._church(tapituga._powder());
            if (ezacivim != null && !ezacivim._buses()) {
               return false;
            } else {
               return ipavurad.warcraft$._sounds().booleanValue() || Alondra._inserted()._broadway(tapituga);
            }
         }
      } else {
         return false;
      }
   }

   private float[] _ladder(double anocapag, double secudoso, double yigomive) {
      Object iserapap = Alondra._inserted();
      Object lumicuge = anocapag - iserapap._defining();
      Object iluyayem = secudoso - iserapap._dealt();
      double var12 = yigomive - iserapap._opens() - 1.2D;
      double var14 = (double)Arnita._donor(lumicuge * lumicuge + iluyayem * iluyayem);
      float var16 = (float)(Math.atan2(iluyayem, lumicuge) * 180.0D / 3.141592653589793D) - 90.0F;
      float var17 = (float)(-(Math.atan2(var12, var14) * 180.0D / 3.141592653589793D));
      return new float[]{var16, var17};
   }

   public float[] _premier(Quenna pabayiru) {
      Object pacacaco = pabayiru._defining();
      Object vopacace = pabayiru._dealt();
      double var6 = pabayiru._opens() + (double)(pabayiru._rolling() / 2.0F);
      return uloriciv._ladder(pacacaco, vopacace, var6);
   }

   public float _vaccine(double nefefomu, double rimazilo, float zisafisa) {
      Object utunogif = Alondra._inserted();
      Object itotolog = nefefomu - utunogif._defining();
      double var9 = rimazilo - utunogif._dealt();
      double var11;
      if (var9 < 0.0D && itotolog < 0.0D) {
         var11 = 90.0D + Math.toDegrees(Math.atan(var9 / itotolog));
      } else if (var9 < 0.0D && itotolog > 0.0D) {
         var11 = -90.0D + Math.toDegrees(Math.atan(var9 / itotolog));
      } else {
         var11 = Math.toDegrees(-Math.atan(itotolog / var9));
      }

      return Arnita._germany(-(zisafisa - (float)var11));
   }

   static Franciso _software(Tiffane nasibacu) {
      return nasibacu.event$;
   }
}
