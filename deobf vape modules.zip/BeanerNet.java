import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CopyOnWriteArrayList;

public class Bryant extends Fanny {
   private Dustun picofusi$;
   private List simiropo$;
   private Queue zunubezi$;

   public Bryant() {
      super("BeanerNet", 8919359, Ayonna.lyrics$, "Delays packets sent, simulates lag and causes high ping");
      medical.picofusi$ = Dustun._gentle(medical, "Delay", "#", "", 1.0D, 100.0D, 1000.0D, 10.0D);
      medical.simiropo$ = new CopyOnWriteArrayList();
      medical.zunubezi$ = new ConcurrentLinkedQueue();
      medical._actions(new Albert[]{medical.picofusi$});
   }

   public void _niger() {
   }

   public boolean _industry() {
      return true;
   }

   public void _peoples(Lakita unuzirup) {
      if (Alondra._inserted()._science() != null && !Alondra._inserted()._himself()) {
         Object guzerovu = unuzirup._seventh()._science();
         if (binusubu.simiropo$.contains(guzerovu)) {
            binusubu.simiropo$.remove(guzerovu);
         } else {
            while(true) {
               Object icunator = (Jerron)binusubu.zunubezi$.peek();
               if (icunator == null || !icunator._batman(binusubu.picofusi$._cingular().longValue())) {
                  binusubu.zunubezi$.add(new Jerron(guzerovu, (iReSqtkUVgCsxiReSqtkUVg)null));
                  unuzirup._angeles(true);
                  return;
               }

               icunator = (Jerron)binusubu.zunubezi$.poll();
               binusubu.simiropo$.add(icunator._grass());
               Alondra._inserted()._witch()._teddy(new Hailey(icunator._grass()));
            }
         }
      }
   }
}
