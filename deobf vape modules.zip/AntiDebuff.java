import org.lwjgl.opengl.GL11;

public class Dayton extends Fanny {
   private Ellena ucelatul$;
   private Ellena puvogime$;
   private Ellena cefipafo$;
   private Ellena sadimuda$;
   private float fatadasa$;
   private float finobumu$;
   private float fayayumo$;

   public Dayton() {
      super("AntiDebuff", -256, Ayonna.weather$, "Removes negative visual potion effects");
      fasezumu.ucelatul$ = Ellena._fitted(fasezumu, "Remove Nausea", true);
      fasezumu.puvogime$ = Ellena._fitted(fasezumu, "Remove Blindness", true);
      fasezumu.cefipafo$ = Ellena._fitted(fasezumu, "Remove Slowness", true);
      fasezumu.sadimuda$ = Ellena._designs(fasezumu, "Remove Effects", false, "Removes non-visual effects from slowness\nCan be detected by anti-cheat");
      fasezumu._actions(new Albert[]{fasezumu.ucelatul$, fasezumu.puvogime$, fasezumu.cefipafo$, fasezumu.sadimuda$});
   }

   public void _strings(Neill taiwan) {
      if (argued.ucelatul$._sounds().booleanValue()) {
         Alondra._inserted()._lecture(9);
      }

      if (argued.puvogime$._sounds().booleanValue() && argued.sadimuda$._sounds().booleanValue()) {
         Alondra._inserted()._lecture(15);
      }

      if (argued.cefipafo$._sounds().booleanValue()) {
         Object imported = Alondra._inserted();
         if (imported._workflow(Terresa._tours())) {
            if (argued.sadimuda$._sounds().booleanValue()) {
               Object lowest = Alondra._inserted()._february(Terresa._tours());
               Terresa[] var4 = Terresa._learners();
               var4[2]._charity(imported, imported._blonde(), lowest._varied());
            }

            imported._lecture(2);
         }
      }

   }

   public void _quick(Chadley gimugegi) {
      Object anarares = Alondra._inserted();
      if (enozalay.puvogime$._sounds().booleanValue() && anarares._workflow(Terresa._postcard()) && anarares._february(Terresa._postcard())._purposes() > 1) {
         gimugegi._indoor()._walls(true);
         gimugegi._anaheim(0.1F);
      }

   }

   public void _statutes(Graylon futuyidu) {
      Object ozotimey = Alondra._inserted();
      if (guripara.puvogime$._sounds().booleanValue() && ozotimey._workflow(Terresa._postcard()) && ozotimey._february(Terresa._postcard())._purposes() > 1) {
         GL11.glFogf(2915, 990.0F);
         GL11.glFogf(2916, 1000.0F);
         futuyidu._intro()._compound(true);
         if (futuyidu._meeting() == 0.0F) {
            futuyidu._carol(guripara.fatadasa$);
         }

         if (futuyidu._exempt() == 0.0F) {
            futuyidu._careful(guripara.finobumu$);
         }

         if (futuyidu._arcade() == 0.0F) {
            futuyidu._louis(guripara.fayayumo$);
         }
      } else {
         guripara.fatadasa$ = futuyidu._meeting();
         guripara.finobumu$ = futuyidu._exempt();
         guripara.fayayumo$ = futuyidu._arcade();
      }

   }
}
