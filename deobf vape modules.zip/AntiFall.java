public class Rondal extends Fanny {
   private Ellena tomato$;
   private Dustun concerts$;
   private Verne second$;
   private boolean pontiac$;

   public Rondal() {
      super("AntiFall", 16028225, Ayonna.lyrics$, "Helps you with your Parkinson's\nPrevents you from falling into the void.");
      brass.tomato$ = Ellena._designs(brass, "Speed Check", false, "Ignore falling when Speed is enabled.");
      brass.concerts$ = Dustun._argument(brass, "Fall Dist", "#.#", "m", 0.1D, 2.0D, 5.0D, "The amount of blocks to fall before attempting to lag back.");
      brass.second$ = new Verne();
      brass._actions(new Albert[]{brass.tomato$, brass.concerts$});
   }

   public boolean _industry() {
      return true;
   }

   public void _retailer(Chikita fibodize) {
      Object mevobofe = Alondra._inserted();
      Object bizudupa = mevobofe._cream();
      if (!mevobofe._warner() && !bizudupa._warner() && !mevobofe._himself() && !mevobofe._worker()._doors() && !mevobofe._worker()._print() && !Dyesha.banodage$._provider()._smooth(Timeka.class) && (!geyinofi.tomato$._sounds().booleanValue() || !Dyesha.banodage$._provider()._smooth(Davien.class))) {
         if (fibodize._latin() == Desirre.barrier$) {
            if (!geyinofi.pontiac$ && geyinofi._sucking()) {
               return;
            }

            if (geyinofi.pontiac$ && geyinofi.second$._basename(250L) || mevobofe._cases()) {
               geyinofi.pontiac$ = false;
               geyinofi.second$._cards();
               return;
            }

            Object enovopaf = geyinofi.concerts$._cingular().doubleValue();
            if ((double)mevobofe._ralph() >= enovopaf && !((Timeka)Dyesha.banodage$._provider()._dynamic(Timeka.class))._alpha()) {
               Tang var6 = bizudupa._promised(mevobofe._defining(), mevobofe._opens() - 1.0D, mevobofe._dealt());
               if (var6._warner() || var6._folding()._gotta(Franco._walking()._folding()._science().getClass())) {
                  if (!geyinofi.pontiac$) {
                     geyinofi.pontiac$ = true;
                     geyinofi.second$._cards();
                  } else {
                     mevobofe._instance()._benjamin(0.0F);
                     mevobofe._instance()._stripes(0.0F);
                     mevobofe._obtained(0.0D);
                     mevobofe._lotus(0.0D);
                     mevobofe._problem(0.61765834912346D);
                  }
               }
            }
         }

      }
   }

   public void _breeds(Rhema ifutacap) {
      Object omegorul = Alondra._inserted();
      if (!ifutacap._gonna()._warner() && !omegorul._warner() && !omegorul._cream()._warner()) {
         if (ifutacap._gonna()._gotta(Akeia.magnetic$)) {
            omegorul._reward(0.0F);
            omegorul._obtained(0.0D);
            omegorul._lotus(0.0D);
            ufuledar.pontiac$ = false;
            ufuledar.second$._cards();
         }

      }
   }

   private boolean _sucking() {
      Object lalemizu = Alondra._inserted();
      Object satabuvi = lalemizu._cream();

      for(double oritivun = lalemizu._opens() - 1.0D; oritivun > 0.0D; --oritivun) {
         Tang var5 = satabuvi._promised(lalemizu._defining(), oritivun, lalemizu._dealt());
         if (!var5._warner() && !var5._folding()._gotta(Franco._walking()._folding()._science().getClass())) {
            return true;
         }
      }

      return false;
   }
}
