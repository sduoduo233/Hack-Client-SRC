import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class Gina extends Fanny {
   private boolean votatenu$;
   private boolean umitumif$;
   private boolean ezerucod$;
   private Dusti mecayote$ = new Dusti("On bind");
   private Dusti yetayadi$ = new Dusti("Aggro");
   private Franciso caroragu$;
   private Dustun uvuzefup$;
   private Dustun zurudinu$;
   private Dustun yifagosu$;
   private Dustun ofacolom$;
   private Ellena fazeguvu$;
   private Ellena yeleloli$;
   private Jaquita buralobo$;
   private int cabezopo$;
   private boolean dovisepa$;
   private float ozucebor$;
   private float lapovupi$;
   private Verne umufisob$;
   private Ustin agabepeg$;

   public Gina() {
      super("AutoPearl", -16711936, Ayonna.shield$, "Aims and throws a pearl at an enemies pearl trajectory.");
      extreme.caroragu$ = Franciso._capitol(extreme, "Mode", "On bind - searches for thrown pearls and throws upon pressing bind\nAggro - Throws pearl as soon as enemy throws theirs", extreme.mecayote$, extreme.mecayote$, extreme.yetayadi$);
      extreme.uvuzefup$ = Dustun._gentle(extreme, "Angle Limit", "#", "", 30.0D, 180.0D, 360.0D, 5.0D);
      extreme.zurudinu$ = Dustun._minimal(extreme, "Distance Limit", "#.#", "m", 0.0D, 6.0D, 10.0D, 0.1D, "The minimum distance a pearl needs to land away from you\nin order to pearl towards it.");
      extreme.yifagosu$ = Dustun._gentle(extreme, "Horizontal Speed", "#.#", "", 0.1D, 5.0D, 15.0D, 0.5D);
      extreme.ofacolom$ = Dustun._gentle(extreme, "Vertical Speed", "#.#", "", 0.1D, 5.0D, 15.0D, 0.5D);
      extreme.fazeguvu$ = Ellena._designs(extreme, "Silent Throw", false, "Throws the enderpearl without swapping your hand.");
      extreme.yeleloli$ = Ellena._designs(extreme, "Vertical Check", false, "Checks if the pearl landing positions Y is higher a certain amount above you.");
      extreme.umufisob$ = new Verne();
      extreme.agabepeg$ = new Ustin(Collections.singleton(Akeia.charter$), Color.WHITE);
      extreme._actions(new Albert[]{extreme.caroragu$, extreme.yifagosu$, extreme.ofacolom$, extreme.uvuzefup$, extreme.zurudinu$, extreme.yeleloli$, extreme.fazeguvu$});
   }

   public void _niger() {
      Object texture = Alondra._inserted();
      if (texture._trustees()) {
         loose.ozucebor$ = texture._armed();
         loose.lapovupi$ = texture._glasses();
      }

      if (loose.votatenu$ && loose.caroragu$._young().equals(loose.mecayote$)) {
         loose._symphony(false);
      } else {
         if (!loose._larger() && !loose.caroragu$._young().equals(loose.yetayadi$)) {
            loose._symphony(false);
         } else {
            loose.votatenu$ = true;
         }

      }
   }

   public void _ghana() {
      vesiyoyo.votatenu$ = false;
   }

   private void _lemon(Jarin rezagati, Tempess upofesad, int vilocucu) {
      rezagati._steal(vilocucu);
      if (efedapuc.fazeguvu$._sounds().booleanValue()) {
         upofesad._witch()._teddy(Camron._handle(vilocucu));
         Alondra._emacs()._notes();
      }

   }

   private Coree _believed(Jaquita upirerep) {
      if (upirerep._series()) {
         return null;
      } else {
         Iterator udofecag = nololoze._contest().iterator();

         Coree fopoyoga;
         do {
            if (!udofecag.hasNext()) {
               return null;
            }

            fopoyoga = (Coree)udofecag.next();
         } while(!fopoyoga._booth(upirerep));

         return fopoyoga;
      }
   }

   private List _contest() {
      Object oxygen = new ArrayList();
      oxygen.add(record.agabepeg$);
      return oxygen;
   }

   private Tricha _houses(Jaquita yuzegale) {
      if (!yuzegale._gotta(Akeia.talented$)) {
         return null;
      } else {
         Object gireduda = Alondra._right();
         Object panilalu = yuzegale._defining();
         Object voditafe = yuzegale._opens();
         Object moruveri = yuzegale._dealt();
         Object acibevam = yuzegale._protocol();
         Object ilomufet = yuzegale._themes();
         double var13 = yuzegale._blend();

         while(true) {
            Tricha var16 = Tricha._speeds(panilalu, voditafe, moruveri);
            Tricha var17 = Tricha._speeds(panilalu + acibevam, voditafe + ilomufet, moruveri + var13);
            Edelmiro var15 = gireduda._sections(var16, var17, false, yuzegale._gotta(Akeia.pulled$), false);
            panilalu += acibevam;
            voditafe += ilomufet;
            moruveri += var13;
            if (var15._trustees()) {
               panilalu = var15._metallic()._fired();
               voditafe = var15._metallic()._looking();
               moruveri = var15._metallic()._larry();
               Tempess var18 = Alondra._inserted();
               return (double)Math.abs(asoculiv._affects(panilalu, moruveri)) > asoculiv.uvuzefup$._cingular().doubleValue() / 2.0D || var18._teach(panilalu, voditafe, moruveri) <= asoculiv.zurudinu$._cingular().doubleValue() || asoculiv.yeleloli$._sounds().booleanValue() && voditafe - var18._opens() >= 7.0D ? null : Tricha._speeds(panilalu, voditafe, moruveri);
            }

            if (voditafe < -128.0D) {
               return null;
            }

            acibevam *= yuzegale._shannon() ? 0.8D : 0.99D;
            ilomufet *= yuzegale._shannon() ? 0.8D : 0.99D;
            var13 *= yuzegale._shannon() ? 0.8D : 0.99D;
            ilomufet -= 0.05D;
         }
      }
   }

   private float _affects(double yicuyono, double evifoyem) {
      Object opabenom = Alondra._inserted();
      Object guzoliva = yicuyono - opabenom._defining();
      double var8 = evifoyem - opabenom._dealt();
      double var10;
      if (var8 < 0.0D && guzoliva < 0.0D) {
         var10 = 90.0D + Math.toDegrees(Math.atan(var8 / guzoliva));
      } else if (var8 < 0.0D && guzoliva > 0.0D) {
         var10 = -90.0D + Math.toDegrees(Math.atan(var8 / guzoliva));
      } else {
         var10 = Math.toDegrees(-Math.atan(guzoliva / var8));
      }

      return Arnita._germany(-(opabenom._armed() - (float)var10));
   }

   public void _fresh(Waddell feyutigi) {
      if (ufofipep.caroragu$._young().equals(ufofipep.yetayadi$)) {
         Object pafevopi = feyutigi._alerts();
         Object asaderid = Alondra._inserted();
         if (pafevopi._gotta(Akeia.talented$)) {
            Object amacelob = new Marieann(pafevopi._science());
            Object yadeniye = new Jaquita(pafevopi._science());
            Object abucefan = ufofipep._believed(amacelob);
            if (abucefan != null) {
               Object gofolago = ufofipep._strength();
               if (gofolago == null || gofolago._warner()) {
                  return;
               }

               Object ogalipar = asaderid._header(yadeniye);
               Object itimodem = gofolago._header(yadeniye);
               if (itimodem < ogalipar) {
                  Object nizorege = new Corrin(yadeniye._defining(), yadeniye._opens(), pafevopi._dealt());
                  Object dilamotu = German._informal(nizorege, 1.5D);
                  if (!Float.isNaN(dilamotu)) {
                     ufofipep.buralobo$ = yadeniye;
                     ufofipep.umufisob$._cards();
                  }
               }
            }
         }

      }
   }

   private Glynnis _strength() {
      Object adatalec = 999.0F;
      Object vuregeca = false;
      Object papeyuso = Alondra._right();
      Object obitebun = Alondra._inserted();
      Iterator ebudogey = papeyuso._because().iterator();

      while(ebudogey.hasNext()) {
         Object micovoni = ebudogey.next();
         Object ogegifey = new Lavetta(micovoni);
         if (!ogegifey.equals(obitebun) && ogegifey._gotta(Akeia.mapping$)) {
            Object azegonoy = obitebun._header(ogegifey);
            if (azegonoy < adatalec) {
               Object vuregeca = ogegifey._declare();
               adatalec = azegonoy;
            }
         }
      }

      return null;
   }

   public void _strings(Neill realize) {
      Object special = Alondra._inserted();
      if (expedia.ezerucod$) {
         int warcraft = 36;

         while(true) {
            boolean var10001 = true;
            if (special._discs()._compact(warcraft)._ports()) {
               Object lender = special._discs()._compact(warcraft)._monthly()._educated();
               if (lender._gotta(Akeia.prison$)) {
                  Jarin var5 = special._ordering();
                  expedia.cabezopo$ = var5._products();
                  if (var5._products() != warcraft - 36) {
                     expedia._lemon(var5, special, warcraft - 36);
                  }

                  if (Alondra._emacs()._earnings(special, special._cream(), special._discs()._compact(warcraft)._monthly())) {
                     if (expedia.caroragu$._young().equals(expedia.mecayote$)) {
                        if (expedia.fazeguvu$._sounds().booleanValue()) {
                           expedia._lemon(var5, special, expedia.cabezopo$);
                        }

                        expedia._symphony(false);
                     } else {
                        expedia.dovisepa$ = true;
                     }

                     expedia.buralobo$ = null;
                     expedia.umitumif$ = false;
                     expedia.ezerucod$ = false;
                     return;
                  }
               }
            }

            ++warcraft;
         }
      }
   }

   public void _equality(Adele niyeyeta) {
      Object yiloduli = Alondra._inserted();
      if (!yiloduli._warner()) {
         if (cadicoto.umufisob$._basename(1000L) && cadicoto.buralobo$ != null) {
            cadicoto.buralobo$ = null;
         }

         if (cadicoto.dovisepa$) {
            Object gubigusa = yiloduli._ordering();
            cadicoto._lemon(gubigusa, yiloduli, cadicoto.cabezopo$);
            cadicoto.dovisepa$ = false;
            cadicoto.buralobo$ = null;
         }

         Object gubigusa = Alondra._right();
         Object capubile = null;
         if (cadicoto.caroragu$._young().equals(cadicoto.yetayadi$)) {
            if (cadicoto.buralobo$ != null) {
               if (!cadicoto._larger()) {
                  cadicoto.buralobo$ = null;
                  return;
               }

               capubile = cadicoto._houses(cadicoto.buralobo$);
            }
         } else {
            Iterator ayomayip = gubigusa._because().iterator();

            while(ayomayip.hasNext()) {
               Object iyomunip = ayomayip.next();
               Object igemugaz = new Lavetta(iyomunip);
               if (igemugaz._gotta(Akeia.talented$)) {
                  Object olorider = new Marieann(igemugaz._science());
                  Object vupagolo = new Jaquita(igemugaz._science());
                  Coree var10 = cadicoto._believed(olorider);
                  if (var10 != null) {
                     capubile = cadicoto._houses(vupagolo);
                  }
               }
            }
         }

         if (capubile != null && capubile._trustees()) {
            Object ayomayip = cadicoto._affects(capubile._fired(), capubile._larry());
            if (ayomayip > cadicoto.yifagosu$._cingular().floatValue()) {
               ayomayip = cadicoto.yifagosu$._cingular().floatValue();
            } else if (ayomayip < -cadicoto.yifagosu$._cingular().floatValue()) {
               ayomayip = -cadicoto.yifagosu$._cingular().floatValue();
            }

            Object iyomunip = cadicoto.ozucebor$ + ayomayip;
            Object igemugaz = -(cadicoto.lapovupi$ - German._informal(capubile._folks(), 1.5D));
            if (igemugaz > cadicoto.ofacolom$._cingular().floatValue()) {
               igemugaz = cadicoto.ofacolom$._cingular().floatValue();
            } else if (igemugaz < -cadicoto.ofacolom$._cingular().floatValue()) {
               igemugaz = -cadicoto.ofacolom$._cingular().floatValue();
            }

            Object olorider = cadicoto.lapovupi$ + igemugaz;
            yiloduli._exciting(cadicoto.ozucebor$ = iyomunip);
            if (!Float.isNaN(olorider)) {
               yiloduli._thick(cadicoto.lapovupi$ = olorider);
            }

            if (!cadicoto.umitumif$) {
               cadicoto.umitumif$ = (double)Math.abs(cadicoto._affects(capubile._fired(), capubile._larry())) < 0.5D && (double)Math.abs(igemugaz) < 0.5D;
               return;
            }

            if (!cadicoto.ezerucod$) {
               return;
            }
         } else {
            cadicoto.ozucebor$ = yiloduli._armed();
            cadicoto.lapovupi$ = yiloduli._glasses();
         }

         if (cadicoto.caroragu$._young().equals(cadicoto.mecayote$)) {
            cadicoto._symphony(false);
         }

      }
   }

   public void _realtor(Thorn var1) {
      if (foreign.umitumif$ && !foreign.ezerucod$) {
         foreign.ezerucod$ = true;
      }

   }

   private boolean _larger() {
      Object ucigoyom = Alondra._inserted();
      int isegugoc = 36;

      while(true) {
         boolean var10001 = true;
         if (ucigoyom._discs()._compact(isegugoc)._ports()) {
            Object agoyitog = ucigoyom._discs()._compact(isegugoc)._monthly()._educated();
            if (agoyitog._gotta(Akeia.prison$)) {
               return true;
            }
         }

         ++isegugoc;
      }
   }
}
