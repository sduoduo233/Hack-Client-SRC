import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class Jaala extends Matthieu {
   private CopyOnWriteArrayList parent$ = new CopyOnWriteArrayList();
   private Dusti eleven$ = new Dusti("All");
   private Dusti appears$ = new Dusti("One of each");
   private Dusti adopt$ = new Dusti("First");
   private Franciso height$;
   private Ellena[] western$;
   private Ashley travesti$;
   private Ellena excess$;
   private Dustun mpegs$;
   private boolean schedule$;

   public Jaala() {
      super("ThrowDebuff");
      olibufug.height$ = Franciso._capitol(olibufug, "Mode", "All - Throws all debuffs on hotbar\nOne of each - Throws one of each debuff\nFirst - Throws only first debuff on hotbar", olibufug.appears$, olibufug.eleven$, olibufug.appears$, olibufug.adopt$);
      olibufug.western$ = new Ellena[]{Ellena._fitted(olibufug, "Harming", true), Ellena._fitted(olibufug, "Weakness", true), Ellena._fitted(olibufug, "Poison", true), Ellena._fitted(olibufug, "Slowness", true)};
      olibufug.travesti$ = Ashley._laptop(olibufug, "Delay", "#.#", "", 0.0D, 70.0D, 120.0D, 200.0D);
      olibufug.excess$ = Ellena._fitted(olibufug, "Scroll", false);
      olibufug.mpegs$ = Dustun._bright(olibufug, "Scroll delay", "#", "ms", 0.0D, 100.0D, 200.0D);
      olibufug._actions(new Albert[]{olibufug.height$});
      Object sefumiba = olibufug.western$;
      Object asomesaf = sefumiba.length;

      for(int lifobava = 0; lifobava < asomesaf; ++lifobava) {
         Object egupesul = sefumiba[lifobava];
         olibufug._actions(new Albert[]{egupesul});
      }

      olibufug._actions(new Albert[]{olibufug.travesti$});
      olibufug.excess$._heated(olibufug.mpegs$);
      olibufug._actions(new Albert[]{olibufug.excess$});
      olibufug._actions(new Albert[]{olibufug.mpegs$});
   }

   private void _shirt(int possibly) {
      if (!extra.excess$._sounds().booleanValue()) {
         Alondra._inserted()._ordering()._steal(possibly);
      } else {
         int resist = Alondra._inserted()._ordering()._products();

         while(true) {
            Alondra._inserted()._ordering()._steal(resist);

            try {
               Thread.sleep(extra.mpegs$._cingular().longValue());
            } catch (InterruptedException var4) {
               ;
            }

            if (possibly > resist) {
               ++resist;
            } else {
               if (possibly >= resist) {
                  return;
               }

               --resist;
            }
         }
      }
   }

   private boolean _sharing() {
      Object palepani = new ArrayList();
      int ilafenul = 0;

      while(true) {
         boolean var10001 = true;
         palepani.add(ilafenul);
         ++ilafenul;
      }
   }

   public void _ruled() {
      Object aganudar = Alondra._inserted();
      Object ifoyagub = aganudar._ordering();
      Object elocifov = ifoyagub._products();
      Iterator ubusuleb = urupaziy.parent$.iterator();

      while(ubusuleb.hasNext()) {
         Tristy locelago = (Tristy)ubusuleb.next();

         try {
            urupaziy._shirt(locelago._mentor());
            Object avavigol = Alondra._surfaces()._teenage()._performs();
            Micholas._lingerie(avavigol, true);
            Micholas._trace(avavigol);
            Thread.sleep(51L);
            Micholas._lingerie(avavigol, false);
            Thread.sleep((long)urupaziy.travesti$._kinds());
         } catch (Exception var7) {
            ;
         }
      }

      urupaziy._shirt(elocifov);
      urupaziy.schedule$ = false;
   }

   public void _tribe(Stormey var1) {
      if (!leralofa.schedule$ && leralofa._alpha()) {
         leralofa._symphony(false);
      }

   }

   public void _niger() {
      if (yevopoga._sharing()) {
         yevopoga.schedule$ = true;
         yevopoga._recorder(0L, false);
      } else {
         yevopoga._symphony(false);
      }

   }

   public void _ghana() {
      ezulevan.parent$.clear();
   }
}
