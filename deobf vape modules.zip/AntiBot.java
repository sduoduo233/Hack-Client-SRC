import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Ericson extends Fanny {
   private Dusti mostly$ = new Dusti("Hypixel");
   private Dusti bedford$ = new Dusti("Mineplex");
   private Franciso cricket$;
   private Ellena guardian$;
   private Map literacy$;
   private Object pursuit$;

   public Ericson() {
      super("AntiBot", -16711707, Ayonna.lyrics$, "Removes anti-cheat bots");
      tofugota.cricket$ = Franciso._polar(tofugota, "Mode", tofugota.mostly$, tofugota.mostly$, tofugota.bedford$);
      tofugota.guardian$ = Ellena._designs(tofugota, "Remove Bots", true, "Removes guaranteed bots.");
      tofugota.literacy$ = new HashMap();
      tofugota._actions(new Albert[]{tofugota.cricket$, tofugota.guardian$});
   }

   public boolean _decades(Lavetta zesogubi) {
      Maxamillion uniribis;
      if (zofemede.cricket$._young() == zofemede.mostly$) {
         if (!Tamirra.divine$) {
            return false;
         }

         if (zesogubi._gotta(Akeia.shipping$)) {
            uniribis = new Maxamillion(zesogubi);
            Object omusileb = Alondra._inserted();
            if (!uniribis.equals(omusileb) && omusileb._header(uniribis) < 10.0F) {
               Object abegagoy = uniribis._yemen()._master();
               if (((Integer)zofemede.literacy$.getOrDefault(uniribis._declare(), Integer.valueOf(-1))).intValue() < 20 || abegagoy.equalsIgnoreCase(Tamirra.wallace$ + "r" + uniribis._powder() + Tamirra.wallace$ + "r") || abegagoy.contains("NPC") || ((Integer)zofemede.literacy$.getOrDefault(uniribis._declare(), Integer.valueOf(-1))).intValue() < 20 && !zofemede._breach().contains(uniribis._became())) {
                  return true;
               }
            }
         }
      } else if (zofemede.cricket$._young() == zofemede.bedford$ && zesogubi._gotta(Akeia.shipping$)) {
         uniribis = new Maxamillion(zesogubi);
         if (uniribis._hosted() >= 0.0F) {
            return true;
         }
      }

      return false;
   }

   public void _strings(Neill eripagom) {
      siselusa._roster(siselusa.cricket$._young()._nations());
      Jodie ilunorim;
      if (siselusa.cricket$._young() == siselusa.bedford$) {
         if (!siselusa.guardian$._sounds().booleanValue()) {
            return;
         }

         if (siselusa.pursuit$ == null || Alondra._right()._science() != siselusa.pursuit$) {
            siselusa.literacy$.clear();
            siselusa.pursuit$ = Alondra._right()._science();
         }

         ilunorim = Alondra._right();
         Object eyivazal = Alondra._inserted();
         Iterator ifafudaf = ilunorim._kenya().iterator();

         while(ifafudaf.hasNext()) {
            Object afuzoban = ifafudaf.next();
            Object ugotegib = new Maxamillion(afuzoban);
            if (!ugotegib._gotta(Akeia.yearly$) && !Float.isNaN(ugotegib._hosted()) && ugotegib._opens() > eyivazal._opens() && eyivazal._header(ugotegib) < 10.0F) {
               ilunorim._vitamins(ugotegib);
               break;
            }
         }
      }

      if (siselusa.cricket$._young() == siselusa.mostly$) {
         if (siselusa.pursuit$ == null || Alondra._right()._science() != siselusa.pursuit$) {
            siselusa.literacy$.clear();
            siselusa.pursuit$ = Alondra._right()._science();
         }

         ilunorim = Alondra._right();
         Iterator eyivazal = ilunorim._kenya().iterator();

         while(true) {
            Object ifafudaf;
            do {
               if (!eyivazal.hasNext()) {
                  return;
               }

               ifafudaf = eyivazal.next();
            } while(Akeia.yearly$.isAssignableFrom(ifafudaf.getClass()));

            Object afuzoban = new Maxamillion(ifafudaf);
            Object ugotegib = afuzoban._series();
            if ((!ugotegib || !afuzoban._cases()) && afuzoban._opens() - Alondra._inserted()._opens() > 7.0D) {
               siselusa.literacy$.put(afuzoban._declare(), Integer.valueOf(0));
            } else if (Alondra._right()._plant((int)afuzoban._defining(), (int)afuzoban._opens(), (int)afuzoban._dealt())._folding() != Antoin._wright()) {
               siselusa.literacy$.put(afuzoban._declare(), ((Integer)siselusa.literacy$.getOrDefault(afuzoban._declare(), Integer.valueOf(-1))).intValue() + 1);
            }

            Object asuvebav = afuzoban._yemen()._master();
            boolean var10000;
            if (!asuvebav.equalsIgnoreCase(afuzoban._powder() + Tamirra.wallace$ + "r") && !asuvebav.equalsIgnoreCase(Tamirra.wallace$ + "r" + afuzoban._powder() + Tamirra.wallace$ + "r")) {
               var10000 = false;
            } else {
               var10000 = true;
            }

            if (siselusa.guardian$._sounds().booleanValue() && afuzoban._debian() && ((Integer)siselusa.literacy$.get(afuzoban._declare())).intValue() < 5) {
               Alondra._right()._vitamins(afuzoban);
               break;
            }
         }
      }

   }

   public void _ghana() {
      udotevol.literacy$.clear();
   }

   private List _breach() {
      Object nupaneco = new ArrayList();
      Object rodebifo = Alondra._inserted()._witch();
      Object omemegoc = rodebifo._knitting();
      Iterator oyadopan = omemegoc.iterator();

      while(oyadopan.hasNext()) {
         Object ligopela = oyadopan.next();
         Object vavunogo = new Erina(ligopela);
         nupaneco.add(vavunogo._sapphire()._susan());
      }

      return nupaneco;
   }
}
