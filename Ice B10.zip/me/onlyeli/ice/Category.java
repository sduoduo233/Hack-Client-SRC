package me.onlyeli.ice;

public enum Category {
	WORLD, RENDER, MOVEMENT, COMBAT, PLAYER, MISC;
}