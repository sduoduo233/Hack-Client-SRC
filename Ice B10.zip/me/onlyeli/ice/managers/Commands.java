package me.onlyeli.ice.managers;

import org.lwjgl.input.*;
import me.onlyeli.ice.*;

public class Commands extends Module {

	public Commands() {
		super("Commands", Keyboard.KEY_NONE, Category.MISC);
	}

}
