package me.onlyeli.ice.events;

public enum EventType {

	PRE, POST

}
