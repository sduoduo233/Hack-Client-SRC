package me.existdev.exist.module.modules.movement;

import me.existdev.exist.module.Module;

public class WaterSpeed extends Module {
   public WaterSpeed() {
      super("WaterSpeed", 0, Module.Category.Movement);
   }
}
