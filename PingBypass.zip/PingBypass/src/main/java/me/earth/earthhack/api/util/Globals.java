package me.earth.earthhack.api.util;

import net.minecraft.client.Minecraft;

public interface Globals
{

    Minecraft mc = Minecraft.getMinecraft();

}
