package me.earth.pingbypass.client.modules.safety;

public enum UpdateMode
{
    Tick,
    Fast
}
