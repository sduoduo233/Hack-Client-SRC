package me.earth.earthhack.impl.event.events.client;

public class ShutDownEvent
{

}
