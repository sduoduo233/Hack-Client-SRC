package me.earth.earthhack.impl.event.events.misc;

/**
 * An Event called during the runGameLoop
 * method in Minecraft, after all the
 * scheduled executables have been run.
 */
public class GameLoopEvent
{

}
