package me.earth.earthhack.impl.event.events.misc;

public class TickEvent
{

}
