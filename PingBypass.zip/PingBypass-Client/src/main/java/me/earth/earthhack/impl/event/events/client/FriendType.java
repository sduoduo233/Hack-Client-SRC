package me.earth.earthhack.impl.event.events.client;

public enum FriendType
{
    ADD,
    REMOVE
}
