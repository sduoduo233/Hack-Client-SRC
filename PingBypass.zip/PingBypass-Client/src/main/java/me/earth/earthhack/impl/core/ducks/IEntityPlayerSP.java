package me.earth.earthhack.impl.core.ducks;

public interface IEntityPlayerSP
{
    float getLastReportedYaw();

    float getLastReportedPitch();
}
