package me.rigamortis.seppuku.impl.gui.hud.component;

import me.rigamortis.seppuku.api.gui.hud.component.HudComponent;

/**
 * @author noil
 */
public final class ParticlesComponent extends HudComponent {

    public ParticlesComponent() {
        super("Particles");
        this.setVisible(true);
    }
}
