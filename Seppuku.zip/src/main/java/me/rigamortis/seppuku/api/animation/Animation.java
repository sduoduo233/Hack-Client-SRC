package me.rigamortis.seppuku.api.animation;

/**
 * created by noil on 8/17/2019 at 4:18 PM
 */
public interface Animation {

    void update();
}
