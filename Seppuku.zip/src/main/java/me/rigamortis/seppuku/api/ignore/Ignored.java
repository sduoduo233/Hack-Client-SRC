package me.rigamortis.seppuku.api.ignore;

/**
 * Author Seth
 * 6/29/2019 @ 4:49 AM.
 */
public final class Ignored {

    private String name;

    public Ignored(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
