package me.rigamortis.seppuku.api.gui.hud.component;

public interface ComponentListener {
    void onComponentEvent();
}
