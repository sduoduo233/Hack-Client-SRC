package me.rigamortis.seppuku.api.task.rotation;

import me.rigamortis.seppuku.api.task.basic.BasicTask;

public final class RotationTask extends BasicTask {

    public RotationTask(String name, int priority) {
        super(name, priority);
    }
}
