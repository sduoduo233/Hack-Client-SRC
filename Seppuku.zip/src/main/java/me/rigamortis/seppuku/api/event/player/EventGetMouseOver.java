package me.rigamortis.seppuku.api.event.player;

import me.rigamortis.seppuku.api.event.EventCancellable;

/**
 * @author noil
 */
public class EventGetMouseOver extends EventCancellable {
}
