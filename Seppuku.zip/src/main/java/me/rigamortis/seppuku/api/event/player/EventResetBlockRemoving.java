package me.rigamortis.seppuku.api.event.player;

import me.rigamortis.seppuku.api.event.EventCancellable;

/**
 * Author Seth
 * 4/6/2019 @ 6:27 PM.
 */
public class EventResetBlockRemoving extends EventCancellable {
}
