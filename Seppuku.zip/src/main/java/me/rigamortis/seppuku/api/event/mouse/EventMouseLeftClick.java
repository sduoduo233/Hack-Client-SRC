package me.rigamortis.seppuku.api.event.mouse;

import me.rigamortis.seppuku.api.event.EventCancellable;

public class EventMouseLeftClick extends EventCancellable {
}
