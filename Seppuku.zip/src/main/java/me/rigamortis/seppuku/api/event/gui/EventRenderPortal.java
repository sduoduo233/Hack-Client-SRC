package me.rigamortis.seppuku.api.event.gui;

import me.rigamortis.seppuku.api.event.EventCancellable;

/**
 * Author Seth
 * 4/8/2019 @ 8:06 PM.
 */
public class EventRenderPortal extends EventCancellable {
}
