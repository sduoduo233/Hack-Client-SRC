package me.rigamortis.seppuku.api.event.world;

import me.rigamortis.seppuku.api.event.EventCancellable;

/**
 * Author Seth
 * 4/6/2019 @ 1:28 PM.
 */
public class EventLightUpdate extends EventCancellable {

    public EventLightUpdate() {

    }

}
