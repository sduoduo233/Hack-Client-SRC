package me.rigamortis.seppuku.api.event.world;

import me.rigamortis.seppuku.api.event.EventCancellable;

/**
 * Author Seth
 * 4/7/2019 @ 5:03 PM.
 */
public class EventSetOpaqueCube extends EventCancellable {
}
