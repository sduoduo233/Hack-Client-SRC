package me.rigamortis.seppuku.api.event.minecraft;

/**
 * Author Seth
 * 4/4/2019 @ 11:41 PM.
 */
public class EventUpdateFramebufferSize {

}
