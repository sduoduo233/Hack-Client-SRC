package me.rigamortis.seppuku.api.event.client;

/**
 * created by noil on 10/24/2019 at 7:19 PM
 */
public final class EventLoad {
}
