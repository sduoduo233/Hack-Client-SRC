package me.rigamortis.seppuku.api.event.world;

import me.rigamortis.seppuku.api.event.EventCancellable;

/**
 * created by noil on 11/4/19 at 1:27 PM
 */
public class EventRainStrength extends EventCancellable {
}
