package me.rigamortis.seppuku.api.event.render;

import me.rigamortis.seppuku.api.event.EventCancellable;

/**
 * Author Seth
 * 12/16/2019 @ 3:35 AM.
 */
public class EventRenderEntityOutlines extends EventCancellable {
}
