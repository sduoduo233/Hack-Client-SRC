package me.rigamortis.seppuku.api.event.gui;

/**
 * Author Seth
 * 4/8/2019 @ 7:58 PM.
 */
public class EventBookTitle {

    public String title;

    public EventBookTitle(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
