package me.rigamortis.seppuku.api.event.world;

import me.rigamortis.seppuku.api.event.EventCancellable;

/**
 * @author noil
 */
public class EventSpawnParticle extends EventCancellable {
}
