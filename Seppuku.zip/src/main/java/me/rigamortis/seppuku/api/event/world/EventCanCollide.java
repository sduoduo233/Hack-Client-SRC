package me.rigamortis.seppuku.api.event.world;

import me.rigamortis.seppuku.api.event.EventCancellable;

/**
 * Author Seth
 * 6/5/2019 @ 10:52 PM.
 */
public class EventCanCollide extends EventCancellable {
}
