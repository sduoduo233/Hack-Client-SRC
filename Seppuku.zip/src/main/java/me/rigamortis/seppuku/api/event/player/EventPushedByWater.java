package me.rigamortis.seppuku.api.event.player;

import me.rigamortis.seppuku.api.event.EventCancellable;

/**
 * Author Seth
 * 4/8/2019 @ 6:50 PM.
 */
public class EventPushedByWater extends EventCancellable {
}
