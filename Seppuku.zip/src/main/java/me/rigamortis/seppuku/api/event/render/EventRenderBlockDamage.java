package me.rigamortis.seppuku.api.event.render;

import me.rigamortis.seppuku.api.event.EventCancellable;

/**
 * Author Seth
 * 12/17/2019 @ 1:24 AM.
 */
public class EventRenderBlockDamage extends EventCancellable {
}
