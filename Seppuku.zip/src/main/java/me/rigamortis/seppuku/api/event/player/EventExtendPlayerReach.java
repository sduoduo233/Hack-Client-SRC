package me.rigamortis.seppuku.api.event.player;

import me.rigamortis.seppuku.api.event.EventCancellable;

/**
 * @author Seth
 */
public class EventExtendPlayerReach extends EventCancellable {
}