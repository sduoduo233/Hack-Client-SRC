package me.rigamortis.seppuku.api.event.player;

import me.rigamortis.seppuku.api.event.EventCancellable;

/**
 * Author Seth
 * 4/7/2019 @ 3:07 PM.
 */
public class EventExtendedReach extends EventCancellable {
}
