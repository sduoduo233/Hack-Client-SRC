package me.rigamortis.seppuku.api.event.render;

import me.rigamortis.seppuku.api.event.EventCancellable;

/**
 * Author Seth
 * 4/9/2019 @ 12:41 AM.
 */
public class EventHurtCamEffect extends EventCancellable {
}
