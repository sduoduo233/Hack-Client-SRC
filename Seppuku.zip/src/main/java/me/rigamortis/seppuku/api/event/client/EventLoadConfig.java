package me.rigamortis.seppuku.api.event.client;

public class EventLoadConfig {
}
