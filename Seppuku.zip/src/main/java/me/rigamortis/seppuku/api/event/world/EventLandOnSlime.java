package me.rigamortis.seppuku.api.event.world;

import me.rigamortis.seppuku.api.event.EventCancellable;

/**
 * Author Seth
 * 4/16/2019 @ 3:54 AM.
 */
public class EventLandOnSlime extends EventCancellable {
}
