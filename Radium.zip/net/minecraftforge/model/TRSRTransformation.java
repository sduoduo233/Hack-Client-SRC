// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraftforge.model;

import org.apache.commons.lang3.NotImplementedException;
import org.lwjgl.util.vector.Matrix4f;

public class TRSRTransformation
{
    public TRSRTransformation(final Matrix4f matrix) {
        throw new NotImplementedException("Forge dummy class");
    }
    
    public static boolean isInteger(final Matrix4f matrix) {
        return false;
    }
}
