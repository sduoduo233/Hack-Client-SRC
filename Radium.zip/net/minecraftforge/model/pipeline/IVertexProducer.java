// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraftforge.model.pipeline;

public interface IVertexProducer
{
    void pipe(final IVertexConsumer p0);
}
