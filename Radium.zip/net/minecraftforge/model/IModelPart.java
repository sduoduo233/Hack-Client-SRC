// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraftforge.model;

public interface IModelPart
{
}
