// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client;

public class AnvilConverterException extends Exception
{
    public AnvilConverterException(final String exceptionMessage) {
        super(exceptionMessage);
    }
}
