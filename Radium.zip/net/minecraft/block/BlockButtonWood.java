// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.block;

public class BlockButtonWood extends BlockButton
{
    protected BlockButtonWood() {
        super(true);
    }
}
