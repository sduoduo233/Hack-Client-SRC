// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.block;

public class BlockDoubleWoodSlab extends BlockWoodSlab
{
    @Override
    public boolean isDouble() {
        return true;
    }
}
