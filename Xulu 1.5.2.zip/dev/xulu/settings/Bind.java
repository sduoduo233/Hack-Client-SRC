// 
// Decompiled by Procyon v0.5.36
// 

package dev.xulu.settings;

public class Bind
{
    int num;
    
    public Bind(final int num) {
        this.num = num;
    }
    
    public void setNum(final int num) {
        this.num = num;
    }
    
    public int getNum() {
        return this.num;
    }
}
