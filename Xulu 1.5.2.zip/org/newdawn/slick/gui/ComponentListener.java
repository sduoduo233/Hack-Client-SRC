// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.gui;

public interface ComponentListener
{
    void componentActivated(final AbstractComponent p0);
}
