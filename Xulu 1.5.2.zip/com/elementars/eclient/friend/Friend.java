// 
// Decompiled by Procyon v0.5.36
// 

package com.elementars.eclient.friend;

public class Friend
{
    String username;
    
    public Friend(final String username) {
        this.username = username;
    }
    
    public String getUsername() {
        return this.username;
    }
}
