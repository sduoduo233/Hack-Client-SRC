// 
// Decompiled by Procyon v0.5.36
// 

package com.elementars.eclient.module.misc;

import com.elementars.eclient.module.Category;
import com.elementars.eclient.module.Module;

public class FakeVanilla extends Module
{
    public FakeVanilla() {
        super("FakeVanilla", "Fakes Vanilla", 0, Category.MISC, true);
    }
}
