// 
// Decompiled by Procyon v0.5.36
// 

package com.elementars.eclient.module.misc;

import com.elementars.eclient.module.Category;
import com.elementars.eclient.module.Module;

public class PortalChat extends Module
{
    public PortalChat() {
        super("PortalChat", "Allows you to chat in portals", 0, Category.MISC, true);
    }
}
