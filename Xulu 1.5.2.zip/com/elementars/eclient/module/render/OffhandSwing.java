// 
// Decompiled by Procyon v0.5.36
// 

package com.elementars.eclient.module.render;

import com.elementars.eclient.module.Category;
import com.elementars.eclient.module.Module;

public class OffhandSwing extends Module
{
    public OffhandSwing() {
        super("OffhandSwing", "Swings your offhand instead", 0, Category.RENDER, true);
    }
}
