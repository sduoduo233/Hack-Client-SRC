// 
// Decompiled by Procyon v0.5.36
// 

package com.elementars.eclient.module.render;

import com.elementars.eclient.module.Category;
import com.elementars.eclient.module.Module;

public class ShulkerPreview extends Module
{
    public ShulkerPreview() {
        super("ShulkerPreview", "Peeks into shulker boxes in the inventory", 0, Category.RENDER, true);
    }
}
