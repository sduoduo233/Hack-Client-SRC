// 
// Decompiled by Procyon v0.5.36
// 

package com.elementars.eclient.event.events;

public class DisplaySizeChangedEvent
{
}
