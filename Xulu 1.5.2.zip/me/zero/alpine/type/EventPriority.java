// 
// Decompiled by Procyon v0.5.36
// 

package me.zero.alpine.type;

public interface EventPriority
{
    public static final byte HIGHEST = 1;
    public static final byte HIGH = 2;
    public static final byte MEDIUM = 3;
    public static final byte LOW = 4;
    public static final byte LOWEST = 5;
    public static final byte DEFAULT = 3;
}
