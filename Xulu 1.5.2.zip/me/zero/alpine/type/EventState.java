// 
// Decompiled by Procyon v0.5.36
// 

package me.zero.alpine.type;

public enum EventState
{
    PRE, 
    POST;
}
