package splash.client.events.render;

import me.hippo.systems.lwjeb.event.Cancelable;

/**
 * Author: Ice
 * Created: 17:27, 30-May-20
 * Project: Client
 */
public class EventRender2D extends Cancelable {
}
