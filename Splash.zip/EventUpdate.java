package splash.client.events.player;

import me.hippo.systems.lwjeb.event.MultiStage;

/**
 * Author: Ice
 * Created: 17:28, 30-May-20
 * Project: Client
 */
public class EventUpdate extends MultiStage {
}
