SplashTheme.java
