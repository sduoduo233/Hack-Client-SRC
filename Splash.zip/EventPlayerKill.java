package splash.client.events.player;

import me.hippo.systems.lwjeb.event.Cancelable;

/**
 * Author: Ice
 * Created: 22:57, 11-Jun-20
 * Project: Client
 */
public class EventPlayerKill extends Cancelable {
}
