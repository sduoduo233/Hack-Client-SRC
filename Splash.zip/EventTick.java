package splash.client.events.player;

import me.hippo.systems.lwjeb.event.MultiStage;

public class EventTick extends MultiStage {

}
