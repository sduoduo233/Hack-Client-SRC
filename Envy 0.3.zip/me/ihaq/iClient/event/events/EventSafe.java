package me.ihaq.iClient.event.events;

import me.ihaq.iClient.event.Event;

public class EventSafe extends Event{

}
