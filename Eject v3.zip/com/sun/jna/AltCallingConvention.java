package com.sun.jna;

public abstract interface AltCallingConvention {
}




