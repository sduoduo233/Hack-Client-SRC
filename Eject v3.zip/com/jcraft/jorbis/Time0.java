package com.jcraft.jorbis;

import com.jcraft.jogg.Buffer;

class Time0
        extends FuncTime {
    void pack(Object paramObject, Buffer paramBuffer) {
    }

    Object unpack(Info paramInfo, Buffer paramBuffer) {
        return "";
    }

    Object look(DspState paramDspState, InfoMode paramInfoMode, Object paramObject) {
        return "";
    }

    void free_info(Object paramObject) {
    }

    void free_look(Object paramObject) {
    }

    int inverse(Block paramBlock, Object paramObject, float[] paramArrayOfFloat1, float[] paramArrayOfFloat2) {
        return 0;
    }
}




