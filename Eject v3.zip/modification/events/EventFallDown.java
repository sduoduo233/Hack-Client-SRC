package modification.events;

import modification.interfaces.Event;

public final class EventFallDown
        implements Event {
    public boolean canceled;
}




