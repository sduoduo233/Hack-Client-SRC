package io.netty.util.concurrent;

public abstract interface FutureListener<V>
        extends GenericFutureListener<Future<V>> {
}




