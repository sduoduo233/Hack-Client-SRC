package io.netty.channel;

public abstract interface ServerChannel
        extends Channel {
}




